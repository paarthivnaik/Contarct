
To publish the changes from your local instance of the Database with that of the real Development Database, you will need to create a changeset for the updates you have made to the database.

Once you have published your migrations from Web API to your local instance, do the following:

- Right-Click the project "**Default Database**" and select "**Schema Compare**".

-  Switch the Source and Target. (Middle double arrows)

- As your source, point to your local SQL Database. 

- Click **Compare**.

- Confirm the changes are exactly what you want to do.

- Click **Update**.

- Check in your changes.

  

  In some cases, where data loss will happen, you will need to manually make the database changes, in such cases, you will probably need to reach out to Brandon or Rajiv to have the changes published.