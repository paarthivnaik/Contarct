﻿CREATE TABLE [dbo].[Sessions] (
    [TokenId] UNIQUEIDENTIFIER NOT NULL,
    [UserId]  UNIQUEIDENTIFIER NOT NULL,
    [Expires] DATETIME2 (7)    NOT NULL,
    [Created] DATETIME2 (7)    NOT NULL,
    [Revoked] DATETIME2 (7)    NULL,
    CONSTRAINT [PK_Sessions] PRIMARY KEY CLUSTERED ([TokenId] ASC),
    CONSTRAINT [FK_Sessions_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[Users] ([UserId]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_Sessions_UserId]
    ON [dbo].[Sessions]([UserId] ASC);

