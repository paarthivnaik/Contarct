﻿CREATE TABLE [dbo].[Specialties] (
    [SpecialtyId]    UNIQUEIDENTIFIER NOT NULL,
    [SpecialtyName]  NVARCHAR (512)   NOT NULL,
    [Active]         BIT              NOT NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_Specialties] PRIMARY KEY CLUSTERED ([SpecialtyId] ASC),
    CONSTRAINT [FK_Specialties_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_Specialties_OrganizationId]
    ON [dbo].[Specialties]([OrganizationId] ASC);

