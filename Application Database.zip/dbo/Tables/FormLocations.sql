﻿CREATE TABLE [dbo].[FormLocations] (
    [FormId]     UNIQUEIDENTIFIER NOT NULL,
    [LocationId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormLocations] PRIMARY KEY CLUSTERED ([FormId] ASC, [LocationId] ASC),
    CONSTRAINT [FK_FormLocations_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId]),
    CONSTRAINT [FK_FormLocations_Location_LocationId] FOREIGN KEY ([LocationId]) REFERENCES [dbo].[Locations] ([LocationId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FormLocations_LocationId]
    ON [dbo].[FormLocations]([LocationId] ASC);

