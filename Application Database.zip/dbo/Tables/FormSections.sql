﻿CREATE TABLE [dbo].[FormSections] (
    [FormSectionId]   UNIQUEIDENTIFIER NOT NULL,
    [FormSectionName] NVARCHAR (512)   NOT NULL,
    [Active]          BIT              NOT NULL,
    [OrganizationId]  UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormSections] PRIMARY KEY CLUSTERED ([FormSectionId] ASC),
    CONSTRAINT [FK_FormSections_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId])
);






GO
CREATE NONCLUSTERED INDEX [IX_FormSections_OrganizationId]
    ON [dbo].[FormSections]([OrganizationId] ASC);

