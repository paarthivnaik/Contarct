﻿CREATE TABLE [dbo].[Applications] (
    [ApplicationId]   UNIQUEIDENTIFIER NOT NULL,
    [ApplicationName] NVARCHAR (512)   NOT NULL,
    [Description]     NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_Applications] PRIMARY KEY CLUSTERED ([ApplicationId] ASC)
);



