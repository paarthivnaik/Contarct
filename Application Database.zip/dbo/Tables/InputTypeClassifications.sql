﻿CREATE TABLE [dbo].[InputTypeClassifications] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_InputTypeClassifications] PRIMARY KEY CLUSTERED ([Id] ASC)
);

