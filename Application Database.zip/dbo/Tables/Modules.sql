﻿CREATE TABLE [dbo].[Modules] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_Modules] PRIMARY KEY CLUSTERED ([Id] ASC)
);

