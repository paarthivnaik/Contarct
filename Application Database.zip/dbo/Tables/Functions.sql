CREATE TABLE [dbo].[Functions] (
    [FunctionId]    UNIQUEIDENTIFIER NOT NULL,
    [FunctionName]  NVARCHAR (450)   NOT NULL,
    [Action]        NVARCHAR (512)   NOT NULL,
    [ApplicationId] UNIQUEIDENTIFIER NULL,
    [ModuleId]      INT              NOT NULL,
    [CategoryId]    INT              NOT NULL,
    CONSTRAINT [PK_Functions] PRIMARY KEY CLUSTERED ([FunctionId] ASC),
    CONSTRAINT [FK_Functions_Applications_ApplicationId] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[Applications] ([ApplicationId]),
    CONSTRAINT [FK_Functions_FunctionCategories_CategoryId] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[FunctionCategories] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_Functions_Modules_ModuleId] FOREIGN KEY ([ModuleId]) REFERENCES [dbo].[Modules] ([Id]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_Functions_ApplicationId]
    ON [dbo].[Functions]([ApplicationId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Functions_ModuleId]
    ON [dbo].[Functions]([ModuleId] ASC);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Functions_FunctionName]
    ON [dbo].[Functions]([FunctionName] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Functions_CategoryId]
    ON [dbo].[Functions]([CategoryId] ASC);

