﻿CREATE TABLE [dbo].[FormFormSection] (
    [FormSectionsId] UNIQUEIDENTIFIER NOT NULL,
    [FormsId]        UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormFormSection] PRIMARY KEY CLUSTERED ([FormSectionsId] ASC, [FormsId] ASC),
    CONSTRAINT [FK_FormFormSection_Forms_FormsId] FOREIGN KEY ([FormsId]) REFERENCES [dbo].[Forms] ([FormId]) ON DELETE CASCADE,
    CONSTRAINT [FK_FormFormSection_FormSections_FormSectionsId] FOREIGN KEY ([FormSectionsId]) REFERENCES [dbo].[FormSections] ([FormSectionId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FormFormSection_FormsId]
    ON [dbo].[FormFormSection]([FormsId] ASC);

