﻿CREATE TABLE [dbo].[Fields] (
    [FieldId]        UNIQUEIDENTIFIER NOT NULL,
    [FieldName]      NVARCHAR (512)   NOT NULL,
    [Description]    NVARCHAR (2048)  NULL,
    [HelpText]       NVARCHAR (2048)  NULL,
    [Active]         BIT              NOT NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    [IsInputGroup]   BIT              NOT NULL,
    [Row]            INT              NULL,
    [RowsUsed]       INT              NULL,
    [RowWidth]       INT              NULL,
    [Order]          INT              NULL,
    [Size]           INT              NULL,
    CONSTRAINT [PK_Fields] PRIMARY KEY CLUSTERED ([FieldId] ASC),
    CONSTRAINT [FK_Fields_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_Fields_OrganizationId]
    ON [dbo].[Fields]([OrganizationId] ASC);

