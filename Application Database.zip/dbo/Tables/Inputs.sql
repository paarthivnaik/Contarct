﻿CREATE TABLE [dbo].[Inputs] (
    [InputId]            UNIQUEIDENTIFIER NOT NULL,
    [InputName]          NVARCHAR (512)   NOT NULL,
    [Required]           BIT              NOT NULL,
    [Active]             BIT              NOT NULL,
    [OrganizationId]     UNIQUEIDENTIFIER NOT NULL,
    [InputTypeId]        INT              NOT NULL,
    [MinLength]          INT              NULL,
    [MaxLength]          INT              NULL,
    [Masking]            NVARCHAR (MAX)   NULL,
    [DefaultValueString] NVARCHAR (MAX)   NULL,
    [MinValue]           INT              NULL,
    [MaxValue]           INT              NULL,
    [DefaultValueNumber] INT              NULL,
    [MinDate]            DATETIME2 (7)    NULL,
    [MaxDate]            DATETIME2 (7)    NULL,
    [DefaultDate]        DATETIME2 (7)    NULL,
    [MinTime]            TIME (7)         NULL,
    [MaxTime]            TIME (7)         NULL,
    [DefaultValueTime]   TIME (7)         NULL,
    [Options]            NVARCHAR (MAX)   NULL,
    [OptionsList]        NVARCHAR (MAX)   NULL,
    [OptionsListQuery]   NVARCHAR (MAX)   NULL,
    [OptionsListSp]      NVARCHAR (MAX)   NULL,
    [MinSelection]       INT              NULL,
    [MaxSelection]       INT              NULL,
    [DefaultValueOption] NVARCHAR (MAX)   NULL,
    [DisplayFormat]      NVARCHAR (MAX)   NULL,
    [Slug]               NVARCHAR (512)   NOT NULL,
    [PartOfInputGroup]   BIT              NOT NULL,
    [Row]                INT              NULL,
    [RowWidth]           INT              NULL,
    [Order]              INT              NULL,
    [Size]               INT              NOT NULL,
    [FieldId]            UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_Inputs] PRIMARY KEY CLUSTERED ([InputId] ASC),
    CONSTRAINT [FK_Inputs_Fields_FieldId] FOREIGN KEY ([FieldId]) REFERENCES [dbo].[Fields] ([FieldId]),
    CONSTRAINT [FK_Inputs_InputsTypes_InputTypeId] FOREIGN KEY ([InputTypeId]) REFERENCES [dbo].[InputsTypes] ([InputTypeId]) ON DELETE CASCADE,
    CONSTRAINT [FK_Inputs_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_Inputs_FieldId]
    ON [dbo].[Inputs]([FieldId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Inputs_InputTypeId]
    ON [dbo].[Inputs]([InputTypeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Inputs_OrganizationId]
    ON [dbo].[Inputs]([OrganizationId] ASC);

