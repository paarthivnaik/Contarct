﻿CREATE TABLE [dbo].[Users] (
    [UserId]               UNIQUEIDENTIFIER NOT NULL,
    [Password]             VARBINARY (MAX)  NULL,
    [SecurityStamp]        UNIQUEIDENTIFIER NOT NULL,
    [Email]                NVARCHAR (128)   NOT NULL,
    [FirstName]            NVARCHAR (128)   NULL,
    [LastName]             NVARCHAR (128)   NULL,
    [EmailConfirmed]       BIT              NOT NULL,
    [PhoneNumber]          NVARCHAR (MAX)   NULL,
    [PhoneNumberConfirmed] BIT              NOT NULL,
    [LockoutEnabled]       BIT              NOT NULL,
    [AccessFailedCount]    INT              NOT NULL,
    [Active]               BIT              NOT NULL,
    [LastLogin]            DATETIME2 (7)    NULL,
    [PasswordExpiry]       DATETIME2 (7)    NOT NULL,
    CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([UserId] ASC),
    CONSTRAINT [AK_Users_Email] UNIQUE NONCLUSTERED ([Email] ASC)
);












GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Users_Email]
    ON [dbo].[Users]([Email] ASC);



