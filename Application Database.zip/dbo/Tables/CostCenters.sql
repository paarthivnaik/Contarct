﻿CREATE TABLE [dbo].[CostCenters] (
    [CostCenterId]   UNIQUEIDENTIFIER NOT NULL,
    [CostCenterName] NVARCHAR (512)   NOT NULL,
    [Active]         BIT              NOT NULL,
    [LocationId]     UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_CostCenters] PRIMARY KEY CLUSTERED ([CostCenterId] ASC),
    CONSTRAINT [FK_CostCenters_Locations_LocationId] FOREIGN KEY ([LocationId]) REFERENCES [dbo].[Locations] ([LocationId]) ON DELETE CASCADE
);








GO
CREATE NONCLUSTERED INDEX [IX_CostCenters_LocationId]
    ON [dbo].[CostCenters]([LocationId] ASC);

