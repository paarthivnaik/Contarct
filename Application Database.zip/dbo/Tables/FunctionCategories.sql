﻿CREATE TABLE [dbo].[FunctionCategories] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_FunctionCategories] PRIMARY KEY CLUSTERED ([Id] ASC)
);

