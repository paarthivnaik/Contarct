﻿CREATE TABLE [dbo].[FieldFormSection] (
    [FieldsId]       UNIQUEIDENTIFIER NOT NULL,
    [FormSectionsId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FieldFormSection] PRIMARY KEY CLUSTERED ([FieldsId] ASC, [FormSectionsId] ASC),
    CONSTRAINT [FK_FieldFormSection_Fields_FieldsId] FOREIGN KEY ([FieldsId]) REFERENCES [dbo].[Fields] ([FieldId]) ON DELETE CASCADE,
    CONSTRAINT [FK_FieldFormSection_FormSections_FormSectionsId] FOREIGN KEY ([FormSectionsId]) REFERENCES [dbo].[FormSections] ([FormSectionId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FieldFormSection_FormSectionsId]
    ON [dbo].[FieldFormSection]([FormSectionsId] ASC);

