﻿CREATE TABLE [dbo].[FormSpecialties] (
    [FormId]      UNIQUEIDENTIFIER NOT NULL,
    [SpecialtyId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormSpecialties] PRIMARY KEY CLUSTERED ([FormId] ASC, [SpecialtyId] ASC),
    CONSTRAINT [FK_FormSpecialties_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId]),
    CONSTRAINT [FK_FormSpecialties_Specialty_SpecialtyId] FOREIGN KEY ([SpecialtyId]) REFERENCES [dbo].[Specialties] ([SpecialtyId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FormSpecialties_SpecialtyId]
    ON [dbo].[FormSpecialties]([SpecialtyId] ASC);

