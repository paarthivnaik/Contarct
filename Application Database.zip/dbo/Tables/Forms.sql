﻿CREATE TABLE [dbo].[Forms] (
    [FormId]         UNIQUEIDENTIFIER NOT NULL,
    [FormName]       NVARCHAR (512)   NOT NULL,
    [Description]    NVARCHAR (MAX)   NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    [Active]         BIT              NOT NULL,
    CONSTRAINT [PK_Forms] PRIMARY KEY CLUSTERED ([FormId] ASC),
    CONSTRAINT [FK_Forms_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_Forms_OrganizationId]
    ON [dbo].[Forms]([OrganizationId] ASC);

