﻿CREATE TABLE [dbo].[LoginAttempts] (
    [LoginAttemptId]  UNIQUEIDENTIFIER NOT NULL,
    [Email]           NVARCHAR (128)   NOT NULL,
    [UserAgent]       NVARCHAR (512)   NULL,
    [IpAddress]       NVARCHAR (128)   NULL,
    [LoginResultId]   INT              NOT NULL,
    [AttemptDateTime] DATETIME2 (7)    NOT NULL,
    CONSTRAINT [PK_LoginAttempts] PRIMARY KEY CLUSTERED ([LoginAttemptId] ASC),
    CONSTRAINT [FK_LoginAttempts_LoginResults_LoginResultId] FOREIGN KEY ([LoginResultId]) REFERENCES [dbo].[LoginResults] ([Id]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_LoginAttempts_LoginResultId]
    ON [dbo].[LoginAttempts]([LoginResultId] ASC);

