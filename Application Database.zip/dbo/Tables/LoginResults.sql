﻿CREATE TABLE [dbo].[LoginResults] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_LoginResults] PRIMARY KEY CLUSTERED ([Id] ASC)
);

