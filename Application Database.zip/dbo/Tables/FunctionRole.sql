﻿CREATE TABLE [dbo].[FunctionRole] (
    [FunctionsId] UNIQUEIDENTIFIER NOT NULL,
    [RolesId]     UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FunctionRole] PRIMARY KEY CLUSTERED ([FunctionsId] ASC, [RolesId] ASC),
    CONSTRAINT [FK_FunctionRole_Functions_FunctionsId] FOREIGN KEY ([FunctionsId]) REFERENCES [dbo].[Functions] ([FunctionId]) ON DELETE CASCADE,
    CONSTRAINT [FK_FunctionRole_Roles_RolesId] FOREIGN KEY ([RolesId]) REFERENCES [dbo].[Roles] ([RoleId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_FunctionRole_RolesId]
    ON [dbo].[FunctionRole]([RolesId] ASC);

