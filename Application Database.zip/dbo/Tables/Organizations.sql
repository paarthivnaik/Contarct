﻿CREATE TABLE [dbo].[Organizations] (
    [OrganizationId]   UNIQUEIDENTIFIER NOT NULL,
    [OrganizationName] NVARCHAR (512)   NOT NULL,
    [Address1]         NVARCHAR (1024)  NULL,
    [Address2]         NVARCHAR (1024)  NULL,
    [City]             NVARCHAR (MAX)   NULL,
    [State]            NVARCHAR (2)     NULL,
    [Zip]              NVARCHAR (12)    NULL,
    [TennantId]        UNIQUEIDENTIFIER NULL,
    [ContactName]      NVARCHAR (512)   NULL,
    [ContactPhone]     NVARCHAR (128)   NULL,
    [ContactEmail]     NVARCHAR (128)   NULL,
    [CptMissingEmail]  NVARCHAR (128)   NULL,
    [LogoFileName]     NVARCHAR (MAX)   NULL,
    [LogoUrl]          NVARCHAR (MAX)   NULL,
    [Active]           BIT              NOT NULL,
    CONSTRAINT [PK_Organizations] PRIMARY KEY CLUSTERED ([OrganizationId] ASC),
    CONSTRAINT [FK_Organizations_Tennants_TennantId] FOREIGN KEY ([TennantId]) REFERENCES [dbo].[Tennants] ([TennantId])
);










GO



GO
CREATE NONCLUSTERED INDEX [IX_Organizations_TennantId]
    ON [dbo].[Organizations]([TennantId] ASC);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Organizations_OrganizationName]
    ON [dbo].[Organizations]([OrganizationName] ASC);

