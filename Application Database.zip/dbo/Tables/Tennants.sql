﻿CREATE TABLE [dbo].[Tennants] (
    [TennantId]   UNIQUEIDENTIFIER NOT NULL,
    [TennantName] NVARCHAR (512)   NOT NULL,
    CONSTRAINT [PK_Tennants] PRIMARY KEY CLUSTERED ([TennantId] ASC)
);



