﻿CREATE TABLE [dbo].[OrganizationUser] (
    [OrganizationsId] UNIQUEIDENTIFIER NOT NULL,
    [UsersId]         UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_OrganizationUser] PRIMARY KEY CLUSTERED ([OrganizationsId] ASC, [UsersId] ASC),
    CONSTRAINT [FK_OrganizationUser_Organizations_OrganizationsId] FOREIGN KEY ([OrganizationsId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE,
    CONSTRAINT [FK_OrganizationUser_Users_UsersId] FOREIGN KEY ([UsersId]) REFERENCES [dbo].[Users] ([UserId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_OrganizationUser_UsersId]
    ON [dbo].[OrganizationUser]([UsersId] ASC);

