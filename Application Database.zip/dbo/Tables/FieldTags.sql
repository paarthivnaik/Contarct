﻿CREATE TABLE [dbo].[FieldTags] (
    [FormId] UNIQUEIDENTIFIER NOT NULL,
    [TagId]  UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FieldTags] PRIMARY KEY CLUSTERED ([FormId] ASC, [TagId] ASC),
    CONSTRAINT [FK_FieldTags_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Fields] ([FieldId]),
    CONSTRAINT [FK_FieldTags_Tags_TagId] FOREIGN KEY ([TagId]) REFERENCES [dbo].[Tags] ([TagId]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_FieldTags_TagId]
    ON [dbo].[FieldTags]([TagId] ASC);

