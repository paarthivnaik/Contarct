CREATE TABLE [dbo].[Positions] (
    [PositionId]     UNIQUEIDENTIFIER NOT NULL,
    [PositionName]   NVARCHAR (512)   NOT NULL,
    [Active]         BIT              NOT NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_Positions] PRIMARY KEY CLUSTERED ([PositionId] ASC),
    CONSTRAINT [FK_Positions_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_Positions_OrganizationId]
    ON [dbo].[Positions]([OrganizationId] ASC);

