﻿CREATE TABLE [dbo].[PasswordResetReasons] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_PasswordResetReasons] PRIMARY KEY CLUSTERED ([Id] ASC)
);

