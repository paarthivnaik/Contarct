﻿CREATE TABLE [dbo].[Roles] (
    [RoleId]         UNIQUEIDENTIFIER NOT NULL,
    [RoleName]       NVARCHAR (128)   NOT NULL,
    [Hierarchy]      INT              NOT NULL,
    [Active]         BIT              NOT NULL,
    [OrganizationId] UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED ([RoleId] ASC),
    CONSTRAINT [FK_Roles_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId])
);






GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Roles_RoleName]
    ON [dbo].[Roles]([RoleName] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Roles_OrganizationId]
    ON [dbo].[Roles]([OrganizationId] ASC);

