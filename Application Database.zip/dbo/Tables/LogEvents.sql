﻿CREATE TABLE [dbo].[LogEvents] (
    [Id]             INT                IDENTITY (1, 1) NOT NULL,
    [Message]        NVARCHAR (MAX)     NULL,
    [Level]          NVARCHAR (MAX)     NULL,
    [TimeStamp]      DATETIMEOFFSET (7) NULL,
    [Exception]      NVARCHAR (MAX)     NULL,
    [Properties]     NVARCHAR (MAX)     NULL,
    [UserId]         UNIQUEIDENTIFIER   NULL,
    [OrganizationId] UNIQUEIDENTIFIER   NULL,
    CONSTRAINT [PK_LogEvents] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IX1_LogEvents]
    ON [dbo].[LogEvents]([UserId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX2_LogEvents]
    ON [dbo].[LogEvents]([OrganizationId] ASC);

