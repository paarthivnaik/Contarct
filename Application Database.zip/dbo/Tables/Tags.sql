﻿CREATE TABLE [dbo].[Tags] (
    [TagId]          UNIQUEIDENTIFIER NOT NULL,
    [TagName]        NVARCHAR (MAX)   NULL,
    [Type]           INT              NOT NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    [Active]         BIT              NOT NULL,
    CONSTRAINT [PK_Tags] PRIMARY KEY CLUSTERED ([TagId] ASC),
    CONSTRAINT [FK_Tags_Organizations_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organizations] ([OrganizationId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_Tags_OrganizationId]
    ON [dbo].[Tags]([OrganizationId] ASC);

