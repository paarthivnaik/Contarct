﻿CREATE TABLE [dbo].[PasswordTickets] (
    [TicketId]            UNIQUEIDENTIFIER NOT NULL,
    [Token]               NVARCHAR (32)    NOT NULL,
    [ReasonId]            INT              NOT NULL,
    [RequesterIp]         NVARCHAR (128)   NULL,
    [RequesterUserString] NVARCHAR (512)   NULL,
    [RequestedAt]         DATETIME2 (7)    NULL,
    [ConsumerIp]          NVARCHAR (128)   NULL,
    [ConsumerUserString]  NVARCHAR (512)   NULL,
    [ConsumedAt]          DATETIME2 (7)    NULL,
    [UnlockAccountOnUse]  BIT              NOT NULL,
    [Expiry]              DATETIME2 (7)    NOT NULL,
    [Email]               NVARCHAR (128)   NULL,
    CONSTRAINT [PK_PasswordTickets] PRIMARY KEY CLUSTERED ([TicketId] ASC),
    CONSTRAINT [FK_PasswordTickets_PasswordResetReasons_ReasonId] FOREIGN KEY ([ReasonId]) REFERENCES [dbo].[PasswordResetReasons] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_PasswordTickets_Users_Email] FOREIGN KEY ([Email]) REFERENCES [dbo].[Users] ([Email])
);










GO
CREATE NONCLUSTERED INDEX [IX_PasswordTickets_Email]
    ON [dbo].[PasswordTickets]([Email] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_PasswordTickets_ReasonId]
    ON [dbo].[PasswordTickets]([ReasonId] ASC);

