﻿CREATE TABLE [dbo].[FormPositions] (
    [FormId]     UNIQUEIDENTIFIER NOT NULL,
    [PositionId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormPositions] PRIMARY KEY CLUSTERED ([FormId] ASC, [PositionId] ASC),
    CONSTRAINT [FK_FormPositions_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId]),
    CONSTRAINT [FK_FormPositions_Position_PositionId] FOREIGN KEY ([PositionId]) REFERENCES [dbo].[Positions] ([PositionId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FormPositions_PositionId]
    ON [dbo].[FormPositions]([PositionId] ASC);

