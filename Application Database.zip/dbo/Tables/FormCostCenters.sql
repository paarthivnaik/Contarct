﻿CREATE TABLE [dbo].[FormCostCenters] (
    [FormId]   UNIQUEIDENTIFIER NOT NULL,
    [RegionId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormCostCenters] PRIMARY KEY CLUSTERED ([FormId] ASC, [RegionId] ASC),
    CONSTRAINT [FK_FormCostCenters_CostCenter_CostCenterId] FOREIGN KEY ([RegionId]) REFERENCES [dbo].[CostCenters] ([CostCenterId]) ON DELETE CASCADE,
    CONSTRAINT [FK_FormCostCenters_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId])
);


GO
CREATE NONCLUSTERED INDEX [IX_FormCostCenters_RegionId]
    ON [dbo].[FormCostCenters]([RegionId] ASC);

