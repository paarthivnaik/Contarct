﻿CREATE TABLE [dbo].[FormRegions] (
    [FormId]   UNIQUEIDENTIFIER NOT NULL,
    [RegionId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormRegions] PRIMARY KEY CLUSTERED ([FormId] ASC, [RegionId] ASC),
    CONSTRAINT [FK_FormRegions_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId]),
    CONSTRAINT [FK_FormRegions_Region_RegionsId] FOREIGN KEY ([RegionId]) REFERENCES [dbo].[Regions] ([RegionId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_FormRegions_RegionId]
    ON [dbo].[FormRegions]([RegionId] ASC);

