﻿CREATE TABLE [dbo].[FormTags] (
    [FormId] UNIQUEIDENTIFIER NOT NULL,
    [TagId]  UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_FormTags] PRIMARY KEY CLUSTERED ([FormId] ASC, [TagId] ASC),
    CONSTRAINT [FK_FormTags_Form_FormId] FOREIGN KEY ([FormId]) REFERENCES [dbo].[Forms] ([FormId]),
    CONSTRAINT [FK_FormTags_Tags_TagId] FOREIGN KEY ([TagId]) REFERENCES [dbo].[Tags] ([TagId]) ON DELETE CASCADE
);






GO
CREATE NONCLUSTERED INDEX [IX_FormTags_TagId]
    ON [dbo].[FormTags]([TagId] ASC);

