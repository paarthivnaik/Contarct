﻿CREATE TABLE [dbo].[InputsTypes] (
    [InputTypeId]      INT            IDENTITY (1, 1) NOT NULL,
    [InputTypeName]    NVARCHAR (MAX) NULL,
    [Description]      NVARCHAR (MAX) NULL,
    [ClassificationId] INT            NULL,
    CONSTRAINT [PK_InputsTypes] PRIMARY KEY CLUSTERED ([InputTypeId] ASC),
    CONSTRAINT [FK_InputsTypes_InputTypeClassifications_ClassificationId] FOREIGN KEY ([ClassificationId]) REFERENCES [dbo].[InputTypeClassifications] ([Id])
);






GO
CREATE NONCLUSTERED INDEX [IX_InputsTypes_ClassificationId]
    ON [dbo].[InputsTypes]([ClassificationId] ASC);

