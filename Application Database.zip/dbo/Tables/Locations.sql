﻿CREATE TABLE [dbo].[Locations] (
    [LocationId]   UNIQUEIDENTIFIER NOT NULL,
    [LocationName] NVARCHAR (512)   NOT NULL,
    [Active]       BIT              NOT NULL,
    [RegionId]     UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_Locations] PRIMARY KEY CLUSTERED ([LocationId] ASC),
    CONSTRAINT [FK_Locations_Regions_RegionId] FOREIGN KEY ([RegionId]) REFERENCES [dbo].[Regions] ([RegionId]) ON DELETE CASCADE
);








GO
CREATE NONCLUSTERED INDEX [IX_Locations_RegionId]
    ON [dbo].[Locations]([RegionId] ASC);

