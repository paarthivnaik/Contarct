﻿CREATE TABLE [dbo].[RoleUser] (
    [RolesId] UNIQUEIDENTIFIER NOT NULL,
    [UsersId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_RoleUser] PRIMARY KEY CLUSTERED ([RolesId] ASC, [UsersId] ASC),
    CONSTRAINT [FK_RoleUser_Roles_RolesId] FOREIGN KEY ([RolesId]) REFERENCES [dbo].[Roles] ([RoleId]) ON DELETE CASCADE,
    CONSTRAINT [FK_RoleUser_Users_UsersId] FOREIGN KEY ([UsersId]) REFERENCES [dbo].[Users] ([UserId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_RoleUser_UsersId]
    ON [dbo].[RoleUser]([UsersId] ASC);

