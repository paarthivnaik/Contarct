﻿CREATE TABLE [dbo].[ApplicationUser] (
    [ApplicationsId] UNIQUEIDENTIFIER NOT NULL,
    [UsersId]        UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_ApplicationUser] PRIMARY KEY CLUSTERED ([ApplicationsId] ASC, [UsersId] ASC),
    CONSTRAINT [FK_ApplicationUser_Applications_ApplicationsId] FOREIGN KEY ([ApplicationsId]) REFERENCES [dbo].[Applications] ([ApplicationId]) ON DELETE CASCADE,
    CONSTRAINT [FK_ApplicationUser_Users_UsersId] FOREIGN KEY ([UsersId]) REFERENCES [dbo].[Users] ([UserId]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_ApplicationUser_UsersId]
    ON [dbo].[ApplicationUser]([UsersId] ASC);

