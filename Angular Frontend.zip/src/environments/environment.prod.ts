export const environment = {
	production: true,
	endpoints: {
		authorization: 'https://hallmarkauthentication.azurewebsites.net/api/',
		car: 'https://hallmarkcar.azurewebsites.net/api/',
		dataManagement: 'https://hallmarkdatamanagement.azurewebsites.net/api/'
	}
};
