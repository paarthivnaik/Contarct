# Illustration Credits

The illustrations in this directory are sourced
from Stories by Freepik.

Freepik offers hundreds of free, high quality
illustrations you can use in your projects. You
can view them all here:

<https://stories.freepik.com/>

Make sure to view their licensing terms to make
sure you are attributing the image authors
correctly when using their assets.
