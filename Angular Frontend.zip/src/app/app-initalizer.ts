import { empty } from 'rxjs';
import { UserService } from '../modules/auth/services';

export function AppInitializer(userService: UserService) {
	if (userService.isUserValid()) {
		return () =>
			new Promise((resolve) => {
				// attempt to refresh token on app start up to auto authenticate
				userService.refreshToken().subscribe().add(resolve);
			});
	} else {
		return () => console.log();
	}
}
