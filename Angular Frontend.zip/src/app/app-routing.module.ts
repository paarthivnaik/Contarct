import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteData } from '@modules/navigation/models';

import { AppCommonGuard as AuthGuard } from '@common/guards/app-common.guard';

const routes: Routes = [
	// {
	// 	path: '',
	// 	pathMatch: 'full',
	// 	redirectTo: 'dashboard'
	// },
	{
		path: '',
		canActivate: [AuthGuard],
		data: {
			functions: []
		} as RouteData,
		loadChildren: () =>
			import('modules/dashboard/dashboard-routing.module').then(
				(m) => m.DashboardRoutingModule
			)
	},
	{
		path: 'login',
		loadChildren: () =>
			import('modules/auth/auth-routing.module').then(
				(m) => m.AuthRoutingModule
			)
	},
	{
		path: 'admin',
		loadChildren: () =>
			import('modules/admin/admin-routing.module').then(
				(m) => m.AdminRoutingModule
			)
	},
	{
		path: 'car',
		loadChildren: () =>
			import('@modules/car/car-routing.module').then(
				(m) => m.CarRoutingModule
			)
	},
	{
		path: 'documents',
		loadChildren: () =>
			import('@modules/documents/documents-routing.module').then(
				(m) => m.DocumentsRoutingModule
			)
	},
	{
		path: 'error',
		loadChildren: () =>
			import('modules/error/error-routing.module').then(
				(m) => m.ErrorRoutingModule
			)
	},
	{
		path: '**',
		pathMatch: 'full',
		loadChildren: () =>
			import('modules/error/error-routing.module').then(
				(m) => m.ErrorRoutingModule
			)
	}
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, {
			scrollPositionRestoration: 'enabled',
			relativeLinkResolution: 'legacy'
		})
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
