import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BlockUIModule } from 'ng-block-ui';
import { JwtModule } from '@auth0/angular-jwt';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AngularMyDatePickerModule } from 'angular-mydatepicker';

import { NavigationModule } from '@modules/navigation/navigation.module';
import { AppCommonModule } from '@common/app-common.module';

import { JwtInterceptor } from '@common/interceptors/jwt-interceptor.interceptor';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AppInitializer } from './app-initalizer';
import { UserService } from '@modules/auth/services';

@NgModule({
	declarations: [AppComponent],
	imports: [
		JwtModule.forRoot({
			config: {
				tokenGetter: () => {
					return localStorage.getItem('token');
				}
			}
		}),
		BlockUIModule.forRoot(),
		BrowserAnimationsModule,
		CKEditorModule,
		BrowserModule,
		AppRoutingModule,
		HttpClientModule,
		AppCommonModule.forRoot(),
		NavigationModule.forRoot(),
		NgbModule,
		FontAwesomeModule,
		AngularMyDatePickerModule
	],
	providers: [
		{
			provide: APP_INITIALIZER,
			useFactory: AppInitializer,
			multi: true,
			deps: [UserService]
		},
		{
			provide: HTTP_INTERCEPTORS,
			useClass: JwtInterceptor,
			multi: true
		}
		// { provide: LocationStrategy, useClass: HashLocationStrategy }
	],
	bootstrap: [AppComponent]
})
export class AppModule {}
