import { ChartsService } from './charts.service';

export const services = [ChartsService];

export * from './charts.service';
