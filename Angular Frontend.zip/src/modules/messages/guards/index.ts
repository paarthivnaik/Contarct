import { MessagesGuard } from './messages.guard';

export const guards = [MessagesGuard];

export * from './messages.guard';
