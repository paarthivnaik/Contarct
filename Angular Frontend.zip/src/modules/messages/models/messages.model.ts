export interface Message {
    image: string;
    text: string;
    details: string;
}
