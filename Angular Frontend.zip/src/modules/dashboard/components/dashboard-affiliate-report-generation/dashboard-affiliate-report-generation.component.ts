import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard-affiliate-report-generation',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './dashboard-affiliate-report-generation.component.html',
    styleUrls: ['dashboard-affiliate-report-generation.component.scss'],
})
export class DashboardAffiliateReportGenerationComponent implements OnInit {
    constructor() {}
    ngOnInit() {}
}
