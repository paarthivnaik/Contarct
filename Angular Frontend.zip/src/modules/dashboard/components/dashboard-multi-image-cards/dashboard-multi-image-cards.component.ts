import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard-multi-image-cards',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './dashboard-multi-image-cards.component.html',
    styleUrls: ['dashboard-multi-image-cards.component.scss'],
})
export class DashboardMultiImageCardsComponent implements OnInit {
    constructor() {}
    ngOnInit() {}
}
