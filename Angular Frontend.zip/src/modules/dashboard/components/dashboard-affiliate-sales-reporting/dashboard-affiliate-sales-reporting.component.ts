import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard-affiliate-sales-reporting',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './dashboard-affiliate-sales-reporting.component.html',
    styleUrls: ['dashboard-affiliate-sales-reporting.component.scss'],
})
export class DashboardAffiliateSalesReportingComponent implements OnInit {
    constructor() {}
    ngOnInit() {}
}
