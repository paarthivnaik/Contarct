import { Component } from '@angular/core';
import { TimelineData } from '@common/models';

@Component({
	selector: 'app-dashboard-overview',
	host: { class: 'h-100' },
	templateUrl: './dashboard-overview.component.html',
	styleUrls: ['dashboard-overview.component.scss']
})
export class DashboardOverviewComponent {
	timeline: TimelineData[] = [
		{
			markerText: '03/01/21',
			markerFeatherIcon: 'flag',
			markerColor: 'primary-soft',
			markerIndicatorTextColor: 'primary',
			itemContent:
				'Please join me in wishing Ann-Shelly Smith a happy birthday!'
		},
		{
			markerText: '02/28/21',
			markerFeatherIcon: 'flag',
			markerColor: 'warning-soft',
			markerIndicatorTextColor: 'warning',
			itemContent:
				'Just a reminder to please mark contracts as Abandoned if no longer needed.'
		},
		{
			markerText: '02/27/21',
			markerFeatherIcon: 'flag',
			markerColor: 'secondary-soft',
			markerIndicatorTextColor: 'secondary',
			itemContent: '392 Contracts Executed last month! Great Job Team!'
		}
	];
}
