import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RouteData } from '@modules/navigation/models';

/* Module */
import { DashboardModule } from './dashboard.module';

/* Containers */
import * as dashboardContainers from './containers';
import * as adminContainers from '@modules/admin/containers';

import * as documentContainers from '@modules/documents/containers';

import * as carContainers from '@modules/car/containers';

/* Guards */
import { AppCommonGuard as AuthGuard } from '@common/guards/app-common.guard';

/* Routes */
export const ROUTES: Routes = [
	{
		path: '',
		canActivate: [AuthGuard],
		component: dashboardContainers.DashboardComponent,
		children: [
			{
				path: '',
				canActivate: [AuthGuard],
				data: {
					title: 'Dashboard - Contract Management',
					breadcrumbs: [
						{
							text: 'Dashboard',
							active: true
						}
					]
				} as RouteData,
				component: dashboardContainers.DashboardOverviewComponent
			},
			{
				path: 'documents',
				canActivateChild: [AuthGuard],
				children: [
					{
						path: '',
						pathMatch: 'full',
						redirectTo: 'create'
					},
					{
						path: 'library',
						canActivate: [AuthGuard],
						component: documentContainers.LibraryComponent,
						data: {
							title: 'Documents - Contract Management',
							functions: []
						} as RouteData
					}
				]
			},
			{
				path: 'car',
				canActivateChild: [AuthGuard],
				children: [
					{
						path: '',
						pathMatch: 'full',
						redirectTo: 'list'
					},
					{
						path: 'list',
						canActivate: [AuthGuard],
						component: carContainers.ListComponent,
						data: {
							title:
								'Contract Action Requests - Contract Management',
							functions: []
						} as RouteData
					},
					{
						path: 'create',
						canActivate: [AuthGuard],
						component: carContainers.WizardComponent,
						data: {
							title:
								'Create Contract Action Request - Contract Management',
							functions: []
						} as RouteData
					},
					{
						path: 'template',
						canActivate: [AuthGuard],
						data: {
							title: 'View Templates - Contract Management',
							functions: []
						} as RouteData,
						children: [
							{
								path: '',
								component: carContainers.TemplateListComponent
							},
							{
								pathMatch: 'full',
								path: 'edit/:id',
								canActivate: [AuthGuard],
								component: carContainers.TemplateEditComponent,
								data: {
									title:
										'Create Contract Action Request - Edit',
									functions: []
								} as RouteData
							}
						]
					}
				]
			},
			{
				path: 'admin',
				canActivateChild: [AuthGuard],
				children: [
					{
						path: '',
						pathMatch: 'full',
						redirectTo: 'users'
					},
					{
						path: 'users',
						canActivate: [AuthGuard],
						component: adminContainers.UsersComponent,
						data: {
							title: 'Edit Users - Contract Management',
							functions: [
								'Authentication.User.CreateAny',
								'Authentication.User.DeleteAny',
								'Authentication.User.ViewAny',
								'Authentication.User.EditAny'
							]
						} as RouteData
					}
				]
			}
		]
	}
];

@NgModule({
	imports: [DashboardModule, RouterModule.forChild(ROUTES)],
	exports: [RouterModule]
})
export class DashboardRoutingModule {}
