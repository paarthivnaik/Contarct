import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';
import { AuthModule } from '@modules/auth/auth.module';

import { AdminModule } from '@modules/admin/admin.module';
import { DocumentsModule } from '@modules/documents/documents.module';
import { CarModule } from '@modules/car/car.module';
import { ChartsModule } from '@modules/charts/charts.module';

/* Components */
import * as dashboardComponents from './components';

/* Containers */
import * as dashboardContainers from './containers';

/* Guards */
import * as dashboardGuards from './guards';

/* Services */
import * as dashboardServices from './services';

@NgModule({
	imports: [
		CommonModule,
		RouterModule,
		ReactiveFormsModule,
		FormsModule,
		AppCommonModule,
		NavigationModule,
		AuthModule,
		AdminModule,
		DocumentsModule,
		CarModule,
		ChartsModule,

		TableModule
	],
	providers: [...dashboardServices.services, ...dashboardGuards.guards],
	declarations: [
		...dashboardContainers.containers,
		...dashboardComponents.components
	],
	exports: [
		...dashboardContainers.containers,
		...dashboardComponents.components
	]
})
export class DashboardModule {}
