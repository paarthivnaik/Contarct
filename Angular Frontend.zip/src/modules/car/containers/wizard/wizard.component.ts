import {
	TemplateRef,
	Component,
	OnInit,
	ViewChild,
	ChangeDetectorRef
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModalOptions, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TimelineData } from '@common/models';

@Component({
	selector: 'app-wizard',
	templateUrl: './wizard.component.html',
	styleUrls: ['./wizard.component.scss']
})
export class WizardComponent implements OnInit {
	fakeArray = new Array(1);
	fakeArray2 = new Array(4);
	dateTimeValue: Date = new Date();
	step: 'init' | 'template' | 'link' | 'details' | 'approvers' | 'generate' =
		'init';

	value2: any;

	@ViewChild('itemTemplate1') itemTemplate1!: TemplateRef<unknown>;
	@ViewChild('itemTemplate2') itemTemplate2!: TemplateRef<unknown>;
	@ViewChild('itemTemplate3') itemTemplate3!: TemplateRef<unknown>;
	@ViewChild('itemTemplate4') itemTemplate4!: TemplateRef<unknown>;
	@ViewChild('itemTemplate5') itemTemplate5!: TemplateRef<unknown>;
	@ViewChild('itemTemplate6') itemTemplate6!: TemplateRef<unknown>;

	timeline: TimelineData[];
	constructor(
		private route: ActivatedRoute,
		private modalService: NgbModal,
		private cdr: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.route.queryParams.subscribe((params) => {
			if (params.step) {
				this.step = params.step;
			} else {
				this.step = 'init';
			}
		});
	}

	ngAfterViewInit() {
		this.timeline = [
			{
				itemTemplate: this.itemTemplate1,
				markerFeatherIcon: 'flag',
				markerColor: 'red-soft',
				markerIndicatorTextColor: 'red'
			},
			{
				itemTemplate: this.itemTemplate2,
				markerFeatherIcon: 'check',
				markerColor: 'orange-soft',
				markerIndicatorTextColor: 'orange'
			},
			{
				itemTemplate: this.itemTemplate3,
				markerFeatherIcon: 'check',
				markerColor: 'yellow-soft',
				markerIndicatorTextColor: 'yellow'
			},
			{
				itemTemplate: this.itemTemplate4,
				markerFeatherIcon: 'check',
				markerColor: 'green-soft',
				markerIndicatorTextColor: 'green'
			},
			{
				itemTemplate: this.itemTemplate5,
				markerFeatherIcon: 'check',
				markerColor: 'blue-soft',
				markerIndicatorTextColor: 'blue'
			},
			{
				itemTemplate: this.itemTemplate6,
				markerFeatherIcon: 'award',
				markerColor: 'purple-soft',
				markerIndicatorTextColor: 'purple'
			}
		] as TimelineData[];
		this.cdr.detectChanges();
	}

	open(
		content: TemplateRef<string>,
		modalOptions: NgbModalOptions = {}
	): void {
		this.modalService.open(content, modalOptions).result;
	}
}
