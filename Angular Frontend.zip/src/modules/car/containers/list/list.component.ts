import {
	TemplateRef,
	Component,
	OnInit,
	ChangeDetectorRef,
	ViewChild
} from '@angular/core';
import { NgbModalOptions, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
	faTimes,
	faFilter,
	faTimesCircle,
	faCheckCircle,
	faUpload,
	faFileExcel
} from '@fortawesome/free-solid-svg-icons';
import { TimelineData } from '@common/models';

@Component({
	selector: 'app-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
	faTimes = faTimes;
	faFilter = faFilter;
	faTimesCircle = faTimesCircle;
	faCheckCircle = faCheckCircle;
	faFileExcel = faFileExcel;
	faUpload = faUpload;

	@ViewChild('itemTemplate1') itemTemplate1!: TemplateRef<unknown>;
	@ViewChild('itemTemplate2') itemTemplate2!: TemplateRef<unknown>;
	@ViewChild('itemTemplate3') itemTemplate3!: TemplateRef<unknown>;
	@ViewChild('itemTemplate4') itemTemplate4!: TemplateRef<unknown>;
	@ViewChild('itemTemplate5') itemTemplate5!: TemplateRef<unknown>;
	@ViewChild('itemTemplate6') itemTemplate6!: TemplateRef<unknown>;

	selectedRow: car;

	results: string[];
	showAdvanced = false;

	dataCollection: ds[];
	filters: Filters[];
	selectedFilters: Filters[];
	timeline: TimelineData[];
	filterItems: string[];
	loading: boolean;
	cars: car[];
	constructor(
		private cdr: ChangeDetectorRef,
		private modalService: NgbModal
	) {
		this.loading = false;
	}

	ngOnInit(): void {
		this.results = ['John', 'Jane', 'Jack'];
		const firstNames = [
			'John',
			'Evan',
			'Richard',
			'Kevin',
			'Christine',
			'Pamela',
			'Amy',
			'Rachel',
			'Patricia',
			'Jennifer',
			'Linda'
		];
		const lastNames = [
			'Smith',
			'Johnson',
			'Williams',
			'Brown',
			'Jones',
			'Miller',
			'Davis',
			'Garcia'
		];
		this.dataCollection = [
			{
				region: 'NJ',
				locations: ["St. Mary's Hospital", 'Holy Cross Hospital']
			},
			{
				region: 'PA',
				locations: ['Mercy Medical Services', 'Mercy Medical Center']
			},
			{
				region: 'NY',
				locations: ['Boca Raton Health', 'St. Agustine Medical Center']
			}
		];
		const c = new car();
		c.id = 123;
		c.firstName = this.selectRandomly(firstNames);
		c.lastName = this.selectRandomly(lastNames);
		const r = <ds>this.selectRandomly(this.dataCollection);
		c.region = r.region;
		c.location = this.selectRandomly(r.locations);
		c.costCenter = 'All';
		c.specialty = 'Pediatrics';
		c.template = 'New Pediatric GP';
		c.requestType = 'New';
		c.status = 'Approval 2/6';
		c.progress = this.getRandomNumber(0, 100);
		this.cars = [];

		for (let i = 0; i < 100; i++) {
			const clone = { ...c };
			clone.id = i;
			clone.firstName = this.selectRandomly(firstNames);
			clone.lastName = this.selectRandomly(lastNames);

			const r = <ds>this.selectRandomly(this.dataCollection);
			clone.region = r.region;
			clone.location = this.selectRandomly(r.locations);
			clone.progress = this.getRandomNumber(0, 100);
			this.cars.push(clone);
		}

		this.filters = [
			{
				name: 'ID',
				code: 'id'
			},
			{
				name: 'First Name',
				code: 'firstName'
			},
			{
				name: 'Last Name',
				code: 'lastName'
			},
			{
				name: 'Region',
				code: 'region'
			},
			{
				name: 'Location',
				code: 'location'
			},
			{
				name: 'Cost Center',
				code: 'costCenter'
			},
			{
				name: 'Specialty',
				code: 'specialty'
			},
			{
				name: 'Template',
				code: 'template'
			},
			{
				name: 'Request Type',
				code: 'requestType'
			},
			{
				name: 'Status',
				code: 'status'
			}
		];

		this.selectedFilters = [];
		this.filterItems = [];

		this.cdr.detectChanges();
	}

	selectRandomly(items: any[]): any {
		return items[Math.floor(Math.random() * items.length)];
	}

	getRandomNumber(min: number, max: number): number {
		return Math.random() * (max - min) + min;
	}

	ngAfterViewInit() {
		this.timeline = [
			{
				markerText: '02/02/2020 9:00AM',
				itemTemplate: this.itemTemplate1,
				markerFeatherIcon: 'flag',
				markerColor: 'red-soft',
				markerIndicatorTextColor: 'red'
			},
			{
				markerText: '02/02/2020 11:02AM',
				itemTemplate: this.itemTemplate2,
				markerFeatherIcon: 'check',
				markerColor: 'orange-soft',
				markerIndicatorTextColor: 'orange'
			},
			{
				markerText: '02/02/2020 1:32PM',
				itemTemplate: this.itemTemplate3,
				markerFeatherIcon: 'check',
				markerIndicatorTextColor: 'yellow-soft',
				markerColor: 'yellow'
			},
			{
				itemTemplate: this.itemTemplate4
			},
			{
				itemTemplate: this.itemTemplate5
			},
			{
				itemTemplate: this.itemTemplate6
			}
		] as TimelineData[];
		this.cdr.detectChanges();
	}

	showFilter(filterName: string): boolean {
		const selected =
			this.filters.filter((f) => f.code === filterName).length > 0;
		return selected;
	}

	changedFilterSelection(): void {
		this.filterItems = this.selectedFilters.map(({ code }) => code);
		this.cdr.detectChanges();
	}

	removeFilter(filter: string): void {
		this.filterItems = this.filterItems.filter((o) => o !== filter);

		this.selectedFilters = this.selectedFilters.filter(
			(o) => o.code !== filter
		);
	}

	search(event: any): void {
		console.log(event);
		this.results = ['John', 'Jane', 'Jack'];
	}

	open(
		content: TemplateRef<string>,
		modalOptions: NgbModalOptions = {}
	): void {
		this.modalService.open(content, modalOptions).result;
	}
}

export interface Filters {
	name: string;
	code: string;
}

export class ds {
	region: string;
	locations: string[];
}

export class car {
	id: number;
	firstName: string;
	lastName: string;
	region: string;
	location: string;
	costCenter: string;
	specialty: string;
	template: string;
	requestType: string;
	status: string;
	progress: number;
}
