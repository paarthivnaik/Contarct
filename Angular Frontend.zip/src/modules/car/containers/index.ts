import { WizardComponent } from './wizard/wizard.component';
import { ListComponent } from './list/list.component';
import { TemplateEditComponent } from './template-edit/template-edit.component';
import { TemplateListComponent } from './template-list/template-list.component';

export const containers = [
	WizardComponent,
	ListComponent,
	TemplateEditComponent,
	TemplateListComponent
];

export * from './wizard/wizard.component';
export * from './list/list.component';
export * from './template-edit/template-edit.component';
export * from './template-list/template-list.component';
