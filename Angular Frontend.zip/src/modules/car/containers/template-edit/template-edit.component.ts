import {
	Component,
	ElementRef,
	OnInit,
	TemplateRef,
	ViewChild
} from '@angular/core';
import { Panel } from 'primeng/panel';
import {
	faCopy,
	faBars,
	faSave,
	faFont,
	faAlignLeft,
	faGripVertical,
	faEye,
	faCompressAlt,
	faExpandAlt,
	faTimes
} from '@fortawesome/free-solid-svg-icons';
import { CdkDragDrop, CdkDragStart } from '@angular/cdk/drag-drop';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { FormService } from '@modules/car/services';
import { OrganizationDataService } from '@common/services/data-management/organization-data.service';
import { TagService } from '@common/services/data-management/tag.service';
import { Field } from '@modules/car/models/field';
import { Form, InputType } from '@modules/car/models';
import { ActivatedRoute } from '@angular/router';
import {
	CostCenter,
	Region,
	Location,
	Specialty,
	Position
} from '@common/models';
import { Tag, TagTypeEnum } from '@common/models/tag/tag';
import { concat, Observable, of, Subject } from 'rxjs';
import {
	catchError,
	distinctUntilChanged,
	switchMap,
	tap
} from 'rxjs/operators';
import { resolve } from '@angular/compiler-cli/src/ngtsc/file_system';

@Component({
	selector: 'app-template-edit',
	templateUrl: './template-edit.component.html',
	styleUrls: ['./template-edit.component.scss']
})
export class TemplateEditComponent implements OnInit {
	selected = 'Text';
	faBars = faBars;
	faCopy = faCopy;
	faSave = faSave;
	faFont = faFont;
	faEye = faEye;
	faTimes = faTimes;
	display = false;
	faCompressAlt = faCompressAlt;
	faExpandAlt = faExpandAlt;
	faAlignLeft = faAlignLeft;
	faGripVertical = faGripVertical;
	dateTimeValue: Date;
	templateName: string;
	collapsed: boolean;
	showText: string;
	ids: string[];
	destination: InputType[][];
	fields: InputType[];

	manuallToggleState: boolean;
	@ViewChild('container') container!: ElementRef;
	@ViewChild('templateSidebar') templateSidebar!: ElementRef;
	@ViewChild('showMoreSection') showMoreSectionPanel!: Panel;

	loadedForm: Form;
	regions: Region[];
	selectedRegions: Region[];
	locations: Location[];
	selectedLocations: Location[];
	costCenters: CostCenter[];
	selectedCostCenters: CostCenter[];
	specialties: Specialty[];
	selectedSpecialties: Specialty[];
	positions: Position[];
	selectedPositions: Position[];

	tags$: Observable<Tag[]>;
	tagInput$ = new Subject<string>();
	selectedTags: Tag[];
	tagsLoading: boolean;

	constructor(
		private modalService: NgbModal,
		private fs: FormService,
		private os: OrganizationDataService,
		private ts: TagService,
		private route: ActivatedRoute
	) {
		this.destination = [];

		this.route.params.subscribe((params) => {
			fs.getForm(params['id']).subscribe((r) => {
				this.loadedForm = r;
				this.templateName = r.name;
				this.selectedRegions = r.regions;
				this.selectedLocations = r.locations;
				this.selectedCostCenters = r.costCenters;
				this.selectedSpecialties = r.specialties;
				this.selectedPositions = r.postions;
			});
		});
		fs.getInputTypes().subscribe((r) => {
			this.fields = r;
		});

		fs.getFields(1, -1, true).subscribe((s) => console.log(s));

		os.getRegions(1, -1, true).subscribe((r) => {
			this.regions = r.results;

			const thisLocations: Location[] = [];
			const thisCostCenters: CostCenter[] = [];
			r.results.forEach((region) => {
				region.locations.forEach((location) => {
					const tempL = location;
					tempL.regionName = region.name;
					thisLocations.push(tempL);

					location.costCenters.forEach((costCenter) => {
						const tempC = costCenter;
						tempC.locationName = location.name;
						thisCostCenters.push(tempC);
					});
				});
			});
			if (thisLocations != null) {
				this.locations = thisLocations;
				this.costCenters = thisCostCenters;
			}
		});

		os.getSpecialties(1, -1).subscribe((r) => {
			this.specialties = r.results;
		});

		os.getPositions(1, -1).subscribe((p) => {
			this.positions = p.results;
		});

		this.destination = [[]];
		this.recalculateIdArray();
	}

	_currentIndex;
	_currentField;
	dragStart(event: CdkDragStart) {
		//console.log(event.source.data);
	}

	drop(event: CdkDragDrop<Field[]>): void {
		if (event.previousContainer !== event.container) {
			console.log(this.destination);
			console.log(event);
			const destinationIndexer = parseInt(
				event.container.id.split('-')[1]
			);
			this.destination[destinationIndexer] = [event.item.data];
			console.log(this.destination);
		}
	}

	ngOnInit(): void {
		this.templateName = 'Untitled Template 1';
		this.collapsed = false;
		this.showText = 'Show less...';
		const newTag = new Tag();
		newTag.name = 'measdas';
		newTag.type = TagTypeEnum.Form;
		this.ts.addTag(newTag).subscribe();
		this.loadTags();
	}

	saveForm(): void {
		//TODO Validate this
		this.loadedForm.regions = this.selectedRegions;
		this.loadedForm.costCenters = this.selectedCostCenters;
		this.loadedForm.locations = this.selectedLocations;
		this.loadedForm.name = this.templateName;
		this.loadedForm.postions = this.selectedPositions;
		this.loadedForm.specialties = this.selectedSpecialties;
		this.fs.updateForm(this.loadedForm).subscribe((r) => {
			this.loadedForm = r;
		});
	}

	increaseColWidth(): void {
		if (this.destination.length < 6) {
			this.destination.push([]);
			this.recalculateIdArray();
		}
	}

	decreaseColWidth(): void {
		if (this.destination.length != 1) {
			this.destination.splice(-1, 1);
			this.recalculateIdArray();
		}
	}

	addTagPromise(name: string): Promise<Tag> {
		console.log('hit add promise');
		const newTag = new Tag();
		newTag.name = name;
		newTag.type = TagTypeEnum.Form;

		const promise = new Promise<Tag>((resolve, reject) => {
			this.ts
				.addTag(newTag)
				.toPromise()
				.then(
					(res) => {
						console.log(res);
						this.tagsLoading = true;
						resolve(res);
						this.tagsLoading = false;
					},
					(msg) => {
						reject(msg);
					}
				);
		});

		return promise;
	}

	private loadTags() {
		this.tags$ = concat(
			of([]), // default items
			this.tagInput$.pipe(
				distinctUntilChanged(),
				tap(() => (this.tagsLoading = true)),
				switchMap((term) =>
					this.ts.getTags(term, TagTypeEnum.Form).pipe(
						catchError(() => of([])), // empty list on error
						tap(() => (this.tagsLoading = false))
					)
				)
			)
		);
	}

	recalculateIdArray(): void {
		this.ids = [];
		for (let i = 0; i < this.destination.length; i++) {
			this.ids.push(`container-${i}`);
		}
	}

	collapseSidebar(): void {
		this.templateSidebar.nativeElement.classList.add('collapsed');
		this.container.nativeElement.classList.remove('has-sidebar');
	}

	expandSidebar(): void {
		this.templateSidebar.nativeElement.classList.remove('collapsed');
		this.container.nativeElement.classList.add('has-sidebar');
		this.templateSidebar.nativeElement.classList.remove('hidden');
	}

	hideSideBar() {
		this.templateSidebar.nativeElement.classList.add('hidden');
	}

	toggleSidebar(): void {
		this.manuallToggleState = !this.manuallToggleState;
		this.templateSidebar.nativeElement.classList.toggle('collapsed');
		this.container.nativeElement.classList.toggle('has-sidebar');
		this.templateSidebar.nativeElement.classList.remove('hidden');
	}

	toggleShowMoreSection($event) {
		this.collapsed = !this.collapsed;
		this.showMoreSectionPanel.toggle($event);

		if (this.collapsed) {
			this.showText = 'Show more...';
		} else {
			this.showText = 'Show less...';
		}
	}

	open(
		content: TemplateRef<string>,
		modalOptions: NgbModalOptions = {}
	): void {
		this.modalService.open(content, modalOptions).result;
	}
}

// export class Field {
// 	icon: IconDefinition;
// 	text: string;
// 	description: string;
// 	min: number;
// 	max: number;
// 	current? = 0;
// }

// export class Row {
// 	fields: Field[] | null;
// }
