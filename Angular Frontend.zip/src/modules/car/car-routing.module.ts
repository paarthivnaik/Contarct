import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { CarModule } from './car.module';

/* Routes */
export const ROUTES: Routes = [];

@NgModule({
	imports: [CarModule, RouterModule.forChild(ROUTES)],
	exports: [RouterModule]
})
export class CarRoutingModule {}
