import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { TableModule } from 'primeng/table';
import { MultiSelectModule } from 'primeng/multiselect';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputMaskModule } from 'primeng/inputmask';
import { AccordionModule } from 'primeng/accordion';
import { SplitterModule } from 'primeng/splitter';
import { InputNumberModule } from 'primeng/inputnumber';
import { ProgressBarModule } from 'primeng/progressbar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ListboxModule } from 'primeng/listbox';
import { TreeModule } from 'primeng/tree';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { SidebarModule } from 'primeng/sidebar';

import { NgSelectModule } from '@ng-select/ng-select';
import { AngularMyDatePickerModule } from 'angular-mydatepicker';

// import { NgSelectModule } from '@ng-select/ng-select';
// import { BlockUIModule } from 'ng-block-ui';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Modules */

/* Components */
import * as carComponents from './components';

/* Containers */
import * as carContainers from './containers';

/* Guards */
import * as carGuards from './guards';

/* Services */
import * as carServices from './services';
import { SectionEditComponent } from './components/section-edit/section-edit.component';
import { FieldEditComponent } from './components/field-edit/field-edit.component';

@NgModule({
	imports: [
		CommonModule,
		RouterModule,
		ReactiveFormsModule,
		FormsModule,
		AppCommonModule,
		NavigationModule,
		DragDropModule,

		SidebarModule,
		PanelModule,
		InputTextModule,
		TableModule,
		MultiSelectModule,
		InputSwitchModule,
		InputNumberModule,
		ProgressBarModule,
		OverlayPanelModule,
		AutoCompleteModule,
		TreeModule,
		ListboxModule,
		SplitterModule,
		InputMaskModule,
		AccordionModule,
		NgSelectModule,
		AngularMyDatePickerModule
	],
	providers: [...carServices.services, ...carGuards.guards],
	declarations: [...carContainers.containers, ...carComponents.components, SectionEditComponent, FieldEditComponent],
	exports: [...carContainers.containers, ...carComponents.components]
})
export class CarModule {}
