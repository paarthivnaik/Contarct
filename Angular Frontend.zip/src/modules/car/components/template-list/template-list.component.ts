import { Component, OnInit } from '@angular/core';
import { Form } from '@modules/car/models/form';
import { FormService } from '@modules/car/services';

@Component({
	selector: 'app-template-list-component',
	templateUrl: './template-list.component.html',
	styleUrls: ['./template-list.component.scss']
})
export class TemplateListComponent implements OnInit {
	forms: Form[];

	constructor(fs: FormService) {
		fs.getForms(1, 100).subscribe((e) => {
			this.forms = e.results;
		});
	}

	ngOnInit(): void {}
}
