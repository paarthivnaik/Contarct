import { TemplateListComponent } from './template-list/template-list.component';

export const components = [TemplateListComponent];

export * from './template-list/template-list.component';
