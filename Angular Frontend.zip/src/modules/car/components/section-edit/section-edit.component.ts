import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-edit',
  templateUrl: './section-edit.component.html',
  styleUrls: ['./section-edit.component.scss']
})
export class SectionEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
