import {
	CostCenter,
	Position,
	Region,
	Specialty,
	Location
} from '@common/models';
import { Tag } from '@common/models/tag/tag';
import { FormSection } from './form-section';

export class Form {
	id: string;
	name: string;
	description: string;
	organizationId: string;
	formSections: FormSection[];
	active: boolean;
	tags: Tag[];
	locations: Location[];
	regions: Region[];
	costCenters: CostCenter[];
	specialties: Specialty[];
	postions: Position[];
}
