import { Field } from './field';

export class FormSection {
	id: string;
	name: string;
	active: boolean;
	fields: Field[];
}
