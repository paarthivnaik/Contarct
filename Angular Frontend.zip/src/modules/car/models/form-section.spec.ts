import { FormSection } from './form-section';

describe('FormSection', () => {
  it('should create an instance', () => {
    expect(new FormSection()).toBeTruthy();
  });
});
