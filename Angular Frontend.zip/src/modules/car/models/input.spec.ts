import { Input } from './input';

describe('Input', () => {
  it('should create an instance', () => {
    expect(new Input()).toBeTruthy();
  });
});
