import { InputType } from './input-type';

export class Input {
	id: string;
	name: string;
	required: boolean;
	active: boolean;
	organizationId: string;
	inputType: InputType;
	inputTypeId: number;
	minLength: number | null;
	maxLength: number | null;
	masking: string;
	defaultValueString: string;
	minValue: number | null;
	maxValue: number | null;
	defaultValueNumber: number | null;
	minDate: string | null;
	maxDate: string | null;
	defaultDate: string | null;
	minTime: string | null;
	maxTime: string | null;
	defaultValueTime: string | null;
	options: string;
	optionsList: string;
	optionsListQuery: string;
	optionsListSp: string;
	minSelection: number | null;
	maxSelection: number | null;
	defaultValueOption: string;
	displayFormat: string;
	slug: string;
	partOfInputGroup: boolean;
	row: number | null;
	rowWidth: number | null;
	order: number | null;
	size: number;
}
