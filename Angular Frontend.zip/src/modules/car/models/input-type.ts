export class InputType {
	id: number;
	name: string;
	description: string;
	classification: InputTypeClassification;
}

export interface InputTypeClassification {
	id: InputTypeClassificationEnum;
	name: string;
}

export enum InputTypeClassificationEnum {
	Text = 1,
	Number = 2,
	DateTime = 3,
	Option = 4,
	Group = 5
}
