import { InputType } from './input-type';

describe('InputType', () => {
  it('should create an instance', () => {
    expect(new InputType()).toBeTruthy();
  });
});
