import { Input } from '@angular/core';
import { FieldTag } from '@common/models/tag/field-tag';

export class Field {
	id: string;
	name: string;
	description: string;
	helpText: string;
	active: boolean;
	organizationId: string;
	inputs: Input[];
	tags: FieldTag[];
	isInputGroup: boolean;
	row: number | null;
	rowsUsed: number | null;
	rowWidth: number | null;
	order: number | null;
	size: number | null;
}
