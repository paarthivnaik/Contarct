import { Field } from './field';

describe('Field', () => {
  it('should create an instance', () => {
    expect(new Field()).toBeTruthy();
  });
});
