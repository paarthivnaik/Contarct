import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PagedResult } from '@common/models/paged-result';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';
import { Field, Form, InputType } from '../models';

@Injectable({
	providedIn: 'root'
})
export class FormService {
	baseUrl: string;

	constructor(private http: HttpClient) {
		this.baseUrl = environment.endpoints.car;
	}

	getForm(id: string): Observable<Form> {
		const params = new HttpParams(); //.set('id', id);

		return this.http.get<Form>(this.baseUrl + 'Form/' + id, {
			params: params
		});
	}

	getForms(page: number, pageSize: number): Observable<PagedResult<Form>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<Form>>(this.baseUrl + 'Form', {
			params: params
		});
	}

	updateForm(form: Form): Observable<Form> {
		return this.http.put<Form>(this.baseUrl + 'Form/update', form);
	}

	getFields(
		page: number,
		pageSize: number,
		inputGroups: boolean
	): Observable<PagedResult<Field>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString())
			.set('inputGroups', inputGroups.toString());

		return this.http.get<PagedResult<Field>>(this.baseUrl + 'Field', {
			params: params
		});
	}

	getInputTypes(): Observable<InputType[]> {
		return this.http.get<InputType[]>(this.baseUrl + 'Input/input-types');
	}
}
