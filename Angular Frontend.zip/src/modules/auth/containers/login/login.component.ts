import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import {
	FormBuilder,
	FormGroup,
	FormControl,
	Validators
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SelectItem } from '@common/models/SelectItem';
import { UserService } from '../../services';
import {
	LoginResult,
	LoginRequest,
	SelectionOption
} from '@modules/auth/models';
import { AuthService } from '@modules/auth/services';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { X } from 'angular-feather/icons';

@Component({
	selector: 'sb-login',
	templateUrl: './login.component.html',
	styleUrls: ['login.component.scss'],
	animations: []
})
export class LoginComponent {
	availableSelections: SelectionOption[];
	orgs: SelectItem[];

	//org: string;

	roles: SelectItem[];

	//role: string;

	errorMessage: string;

	loggedIn = false;

	failedRefresh = false;

	@BlockUI('form') formBlock: NgBlockUI;

	loginForm: FormGroup = this.fb.group({
		email: ['', [Validators.required, Validators.email]],
		password: ['', [Validators.required, Validators.minLength(8)]],
		orgSelect: ['', []],
		roleSelect: ['', []]
	});

	constructor(
		private route: ActivatedRoute,
		private fb: FormBuilder,
		private router: Router,
		private authService: AuthService,
		private userService: UserService
	) {
		if (this.userService.isUserValid()) {
			this.router.navigate(['/']);
		}

		const res = this.router.getCurrentNavigation()?.extras.state as {
			failedRefresh: boolean;
		};
		console.log(res);
		if (res != null) {
			this.failedRefresh = res.failedRefresh;
		}
	}

	onSubmit(): void {
		if (this.loginForm.status === 'VALID') {
			const loginRequest: LoginRequest = new LoginRequest();
			loginRequest.email = this.loginForm.value.email;
			loginRequest.password = this.loginForm.value.password;
			if (this.loginForm.value.orgSelect !== '') {
				loginRequest.organizationId = this.loginForm.value.orgSelect;
			}
			if (this.loginForm.value.roleSelect !== '') {
				loginRequest.roleId = this.loginForm.value.roleSelect;
			}
			this.formBlock.start();
			this.authService.login(loginRequest).subscribe(
				(data: LoginResult) => {
					this.errorMessage = '';
					switch (data.result) {
						case 1: {
							this.loggedIn = true;
							this.userService.saveLogin(data);
							this.router.navigate(['/']);
							break;
						}
						case 3: {
							//TODO Flow for expired passwords
							break;
						}
						case 6: {
							this.availableSelections = data.selectionOptions;

							this.orgs = data.selectionOptions.map((x) => {
								const i = new SelectItem();
								i.name = x.name;
								i.value = x.value;
								i.selected = x.selected;
								return i;
							});

							const selected = data.selectionOptions.filter(
								(o) => o.selected
							);

							if (selected.length > 0) {
								this.loginForm.patchValue({
									orgSelect: selected[0].value
								});
							}

							this.changeRoleSelectionBasedOnOrg();

							break;
						}
						default: {
							this.returnCorrectErrorMessage(data.result);
							break;
						}
					}
				},
				(data: HttpErrorResponse) => {
					this.formBlock.stop();

					if (data != null) {
						const loginResult = data.error as LoginResult;
						this.returnCorrectErrorMessage(loginResult.result);
					}
				},
				() => {
					this.formBlock.stop();
				}
			);
		}
		for (const key in this.loginForm.controls) {
			const control = this.loginForm.controls[key];
			control.markAllAsTouched();
		}
	}

	changeRoleSelectionBasedOnOrg(): void {
		const selected = this.availableSelections.filter(
			(o) => o.value == this.loginForm.value.orgSelect
		);

		this.roles = selected[0].roles.map((y) => {
			const i = new SelectItem();
			i.name = y.name;
			i.value = y.value;
			i.selected = y.selected;
			return i;
		});

		const selectedRole = selected.filter((o) => o.selected);

		if (selectedRole.length > 0) {
			this.loginForm.patchValue({
				roleSelect: selected[0].roles.filter((r) => r.selected)[0]
					?.value
			});
		}
	}

	returnCorrectErrorMessage(errorCode: number): void {
		switch (errorCode) {
			case 2: {
				this.errorMessage = 'Incorrect email or password.';
				break;
			}
			case 4: {
				this.errorMessage =
					'Account locked. Please contact an Administrator.';
				break;
			}
			case 5: {
				this.errorMessage =
					'Your account is disabled. Please contact an Administrator.';
				break;
			}
			case 6: {
				this.errorMessage =
					'Your account is missing assignments. Please contact an Administrator.';
				break;
			}
			default: {
				this.errorMessage = 'Unknown error occured. Please try again.';
				break;
			}
		}
	}

	get emailControl(): FormControl {
		return this.loginForm.get('email') as FormControl;
	}

	get emailControlValid(): boolean {
		return this.emailControl.touched && !this.emailControlInvalid;
	}

	get emailControlInvalid(): boolean {
		return (
			this.emailControl.touched &&
			(this.emailControl.hasError('required') ||
				this.emailControl.hasError('email'))
		);
	}

	get passwordControl(): FormControl {
		return this.loginForm.get('password') as FormControl;
	}

	get passwordControlValid(): boolean {
		return this.passwordControl.touched && !this.passwordControlInvalid;
	}

	get passwordControlInvalid(): boolean {
		return (
			this.passwordControl.touched &&
			(this.passwordControl.hasError('required') ||
				this.passwordControl.hasError('minlength'))
		);
	}
}
