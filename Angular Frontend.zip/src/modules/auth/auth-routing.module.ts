import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RouteData } from '@modules/navigation/models';

/* Module */
import { AuthModule } from './auth.module';

/* Containers */
import * as authContainers from './containers';

/* Guards */
import { AppCommonGuard as AuthGuard } from '@common/guards/app-common.guard';

/* Routes */
export const ROUTES: Routes = [
	{
		path: '',
		pathMatch: 'full',
		redirectTo: '.'
	},
	{
		path: '.',
		canActivate: [],
		component: authContainers.LoginComponent,
		data: {
			title: 'Login - Contract Management'
		} as RouteData
	},
	{
		path: 'forgot-password',
		canActivate: [],
		component: authContainers.ForgotPasswordComponent,
		data: {
			title: 'Forgot Password - Contract Management'
		} as RouteData
	}
];

@NgModule({
	imports: [AuthModule, RouterModule.forChild(ROUTES)],
	exports: [RouterModule]
})
export class AuthRoutingModule {}
