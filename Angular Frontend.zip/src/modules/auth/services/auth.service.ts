import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

import { LoginResult, LoginRequest, RefreshResult } from '@modules/auth/models';

@Injectable()
export class AuthService {
	baseUrl: string;

	constructor(private http: HttpClient) {
		this.baseUrl = environment.endpoints.authorization;
	}

	login(request: LoginRequest): Observable<LoginResult> {
		return this.http.post<LoginResult>(
			this.baseUrl + 'Account/login',
			request
		);
	}

	refresh(
		token: string | null,
		refreshTokenId: string | null
	): Observable<RefreshResult> {
		const request = {
			RefreshTokenId: refreshTokenId,
			Token: token
		};

		return this.http.post<RefreshResult>(
			this.baseUrl + 'Account/refresh',
			request
		);
	}

	logout(): void {
		this.http.post(this.baseUrl + 'Account/logout', null).subscribe(() => {
			localStorage.removeItem('userToken');
		});
	}
}
