import { TestBed } from '@angular/core/testing';
import { UserServiceStub } from '@testing/stubs';

import { UserService } from './user.service';

describe('UserService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{ provide: UserService, useValue: new UserServiceStub() }
			]
		});
	});
});
