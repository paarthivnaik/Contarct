import { Injectable, ModuleWithProviders } from '@angular/core';
import { Router } from '@angular/router';
import { LoginResult, RefreshResult } from '../models';
import { JwtHelperService } from '@auth0/angular-jwt';
import { throwError, Observable, ReplaySubject } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError, map } from 'rxjs/operators';
import { BlockUIService } from 'ng-block-ui';
import { of } from 'rxjs';
import { ApplicationUser } from '@common/models';

const userSubject: ReplaySubject<ApplicationUser> = new ReplaySubject(1);

@Injectable({
	providedIn: 'root'
})
export class UserService {
	private refreshTokenTimeout: number;

	get userFunctions$(): string[] | null {
		return this.jwtHelper.decodeToken(this.token$ as string).functions;
	}

	set refreshId$(val: string | null) {
		if (val != null) {
			localStorage.setItem('refresh', val);
		} else {
			localStorage.removeItem('token');
		}
	}

	get refreshId$(): string | null {
		return localStorage.getItem('refresh');
	}

	set token$(val: string | null) {
		if (val != null) {
			localStorage.setItem('token', val);
		} else {
			localStorage.removeItem('token');
			this.stopRefreshTokenTimer();
		}
	}
	get token$(): string | null {
		return localStorage.getItem('token');
	}

	set nav$(val: string | null) {
		if (val != null) {
			localStorage.setItem('navigation', val);
		} else {
			localStorage.removeItem('navigation');
		}
	}

	get user$(): Observable<ApplicationUser> {
		return userSubject.asObservable();
	}

	static forRoot(): ModuleWithProviders<UserService> {
		return {
			ngModule: UserService
		};
	}

	constructor(
		private router: Router,
		private jwtHelper: JwtHelperService,
		private authService: AuthService,
		//private toastService: ToastService,
		private uiBlock: BlockUIService
	) {
		const token = this.token$;
		if (
			token != null &&
			this.refreshId$ != null &&
			!this.jwtHelper.isTokenExpired(token)
		) {
			const user: ApplicationUser = new ApplicationUser();
			const tData = this.jwtHelper.decodeToken(token);

			user.id =
				tData[
					'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid'
				];
			user.name =
				tData[
					'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'
				];
			user.email =
				tData[
					'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'
				];

			user.organizationId = tData.organizationid;
			user.organizationName = tData.organizationname;

			user.role =
				tData[
					'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'
				];
			user.roleId = tData.roleid;
			user.roleHierarchy = tData.rolehierarchy;

			user.functions = tData.functions;
			userSubject.next(user);
		}
	}

	hasFunctions(functions: string[]): boolean {
		if (this.isUserValid()) {
			const uf = this.userFunctions$;
			if (functions != null) {
				if (uf != null) {
					return functions.every((i) => uf.includes(i));
				} else {
					return false;
				}
			} else {
				//Requires a login but does not require any permissions
				return true;
			}
		} else {
			return false;
		}
	}

	public refreshToken(): Observable<RefreshResult> {
		//Only one window should be checking if we can refresh, that should not be a window that is not active.
		if (document.hasFocus()) {
			return this.authService.refresh(this.token$, this.refreshId$).pipe(
				map((result) => {
					//TODO if ui block was active, toast and let the user know connection was reestablished.
					this.uiBlock.stop('body');
					this.refreshId$ = result.refreshTokenId;
					this.token$ = result.token;
					this.startRefreshTokenTimer(null);
					return result;
				}),
				catchError((error) => {
					if (error.status === 0) {
						this.startRefreshTokenTimer(10000);
						this.uiBlock.start(
							'body',
							'Could not connect to server, please wait...'
						);
					} else {
						this.clearData();
						this.router.navigate(['/login'], {
							state: { failedRefresh: true }
						});
					}

					return throwError(error);
				})
			);
		} else {
			console.log('Window not active. No refresh.');

			this.startRefreshTokenTimer(null);
			return of(new RefreshResult());
		}
	}

	private startRefreshTokenTimer(fixedTimeout: number | null) {
		const token = this.token$;
		if (token != null) {
			const expires = this.jwtHelper.getTokenExpirationDate(token);
			if (expires != null) {
				let timeout = expires.getTime() - Date.now() - 60 * 1000;

				if (timeout < 60000) {
					timeout = 10000;
				}

				if (fixedTimeout != null) {
					timeout = fixedTimeout;
				}

				this.refreshTokenTimeout = setTimeout(
					() => this.refreshToken().subscribe(),
					timeout
				);
			}
		}
	}

	private stopRefreshTokenTimer() {
		clearTimeout(this.refreshTokenTimeout);
	}

	private clearData() {
		this.refreshId$ = null;
		this.token$ = null;
		this.nav$ = null;
		console.log('logout');
		this.uiBlock.stop('body');
		this.stopRefreshTokenTimer();
		this.authService.logout();
	}

	logOut(): void {
		this.clearData();
		this.router.navigate(['/login']);
	}

	saveLogin(loginResult: LoginResult): void {
		this.token$ = loginResult.accessToken;
		this.refreshId$ = loginResult.refreshToken;
		this.nav$ = JSON.stringify(loginResult.navigationInformation);
		this.startRefreshTokenTimer(null);
	}

	isUserValid(): boolean {
		return (
			this.token$ != null && !this.jwtHelper.isTokenExpired(this.token$)
		);
	}
}
