export class LoginRequest {
	email: string;
	password: string;
	organizationId: string | null;
	roleId: string | null;
}
