import { Organization } from '@common/models/organization/organization';
import { SelectItem } from '@common/models/SelectItem';
import { Role } from '@common/models/user/role';

export interface LoginResult {
	result: number;
	accessToken: string;
	refreshToken: string | null;
	selectionOptions: SelectionOption[];
	organization: Organization;
	role: Role;
	navigationInformation: NavigationInformation;
}

export class RefreshResult {
	refreshTokenId: string;
	token: string;
}

export interface SelectionOption {
	name: string;
	value: string;
	selected: boolean;
	roles: SelectItem[];
}

export interface NavigationInformation {
	sections: Section[];
	baseMenu: { [key: string]: NavigationItem[] };
}

export interface Section {
	text: string;
	items: string[];
}

export interface NavigationItem {
	text: string;
	icon: string;
	link: string;
	navigationItems: NavigationItem[];
}
