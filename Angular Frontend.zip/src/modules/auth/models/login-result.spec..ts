import { LoginResult } from './login-result';

describe('LoginResult', () => {
	it('should create an instance', () => {
		expect(new LoginResult()).toBeTruthy();
	});
});
