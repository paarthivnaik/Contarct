import { LibraryComponent } from './library/library.component';

export const containers = [LibraryComponent];

export * from './library/library.component';
