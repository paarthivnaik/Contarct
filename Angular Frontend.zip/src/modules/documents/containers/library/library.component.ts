import {
	TemplateRef,
	Component,
	OnInit,
	ViewChild,
	ElementRef,
	HostListener
} from '@angular/core';
import { TreeNode } from 'primeng/api';
import { NgbModalOptions, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
	faPlus,
	faCopy,
	faBars,
	faFolderPlus,
	faEdit,
	faGripLines,
	faFont,
	faCalendar,
	faImage,
	faFolderOpen,
	faPhone,
	faClock,
	IconDefinition
} from '@fortawesome/free-solid-svg-icons';
import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';

@Component({
	selector: 'app-templates',
	templateUrl: './library.component.html',
	styleUrls: ['./library.component.scss']
})
export class LibraryComponent implements OnInit {
	public Editor = DecoupledEditor;
	faPlus = faPlus;
	faPhone = faPhone;
	faCopy = faCopy;
	faClock = faClock;
	faBars = faBars;
	faEdit = faEdit;
	faFont = faFont;
	faImage = faImage;
	faFolderOpen = faFolderOpen;
	faCalendar = faCalendar;
	faGripLines = faGripLines;
	faFolderPlus = faFolderPlus;
	manuallToggleState: boolean;
	files: TreeNode[];
	fakeArray: string[] = new Array(27);
	selectMode = false;
	sections: Section[];

	@ViewChild('container') container!: ElementRef;
	@ViewChild('templateSidebar') templateSidebar!: ElementRef;
	@ViewChild('templatesTopBar') templatesTopBar!: ElementRef;
	@ViewChild('templateContainer') templateContainer!: ElementRef;
	selectedFile: TreeNode;
	sampleHTML = '';
	LoadTemplate() {
		console.log('hi');
		this.model.editorData = `<h1 style='margin:0in;text-align:center;font-size:19px;font-family:"Verdana",sans-serif;'><br>&nbsp;Vendor Contract</h1>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>This contract serves as an agreement between [Client] and [Vendor]. It becomes effective on [Date] and involves services provided for [Event], which will be held on [Date of Event] from [Event start time] to [Event end time].</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>The Vendor hereby agrees to provide the following services for the Event in exchange for financial compensation outlined below:</p>
	<div align="center" style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>
		<table data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="border-collapse: collapse; border: none; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-bottom: initial; --darkreader-inline-border-left: initial;">
			<tbody>
				<tr>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 7.65in; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
				</tr>
				<tr>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 7.65in; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
				</tr>
				<tr>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 7.65in; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<h2 style='margin-top:12.0pt;margin-right:0in;margin-bottom:12.0pt;margin-left:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Compensation</h2>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>In exchange for the services described above, the Client agrees to provide the Vendor with a total payment sum of $[______________]. A non-refundable fee of 20% of this amount or $[______________] shall be paid upon the execution of this contract, with the balance due no less than five (5) business days prior to the Event.</p>
	<h2 style='margin-top:12.0pt;margin-right:0in;margin-bottom:12.0pt;margin-left:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Event Logistics</h2>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>The Vendor shall have access to the Event location beginning at [Start time] on [Date] in order to set up the appropriate stations, goods, or other items necessary in order to complete the services described.</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Items that require physical display space must be no larger than [Dimensions] and shall be displayed in a clean and orderly fashion throughout the course of the Event. No goods or services not described above may be sold or distributed during this Event without the Client&rsquo;s express written consent.</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Following the event, the Vendor will have until [End time] to break down all equipment and clear the area of all goods. The Vendor is required to leave the area in a clean and serviceable manner.</p>
	<h2 style='margin-top:12.0pt;margin-right:0in;margin-bottom:12.0pt;margin-left:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Professional Appearance</h2>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>The Vendor will display an appearance and manner appropriate with the mood and theme of the Event being held. The vending station will not in any way interfere with the Event on hand, nor will vending staff leave the station unattended. Any special dress or appearance requirements outside of the accepted norm will be discussed in advance between the Client and the Vendor.</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>By signing below, both the Client and the Vendor indicate that they have read, understand, and agree to all terms and conditions outlined in this contract.</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<div align="center" style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>
		<table data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="border-collapse: collapse; border: none; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-bottom: initial; --darkreader-inline-border-left: initial;">
			<tbody>
				<tr>
					<td style="width: 59.4pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Client:</p>
					</td>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 292.5pt; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.3in; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
					<td style="width: 13.5pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
					<td style="width: 49.5pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Date:</p>
					</td>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 135.9pt; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.3in; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
				</tr>
				<tr>
					<td style="width: 59.4pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Vendor:</p>
					</td>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 292.5pt; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.3in; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
					<td style="width: 13.5pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
					<td style="width: 49.5pt;padding: 0in 5.4pt;height: 0.3in;vertical-align: bottom;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>Date:</p>
					</td>
					<td data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left="" data-darkreader-inline-border-right="" data-darkreader-inline-border-top="" style="width: 135.9pt; border-top: none; border-right: none; border-left: none; border-image: initial; border-bottom: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.3in; vertical-align: bottom; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-left: initial; --darkreader-inline-border-bottom:#8c8273;">
						<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;'>&nbsp;</p>
	<p style='margin:0in;font-size:15px;font-family:"Verdana",sans-serif;margin-bottom:10.0pt;line-height:115%;'>&nbsp;</p>`;
	}

	public model = {
		editorData: '<p>Hello, world!</p>'
	};

	constructor(private modalService: NgbModal) {
		this.sections = [
			{
				name: 'General',
				items: [
					{
						itemName: 'Creation Date',
						description:
							'The date the Contact was merged with a template',
						icon: faCalendar
					},
					{
						itemName: 'Creation Time',
						description:
							'The time the Contact was merged with a template',
						icon: faClock
					}
				]
			},
			{
				name: 'Organization',
				items: [
					{
						itemName: 'Organization Logo',
						description: '',
						icon: faImage
					},
					{
						itemName: 'Organization Name',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization Adress Line 1',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization Adress Line 2',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization City',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization State',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization ZIP',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Organization Phone Number',
						description: '',
						icon: faPhone
					}
				]
			},
			{
				name: 'Provider',
				items: [
					{
						itemName: 'Provider First Name',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider Last Name',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider Adress Line 2',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider City',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider State',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider ZIP',
						description: '',
						icon: faFont
					},
					{
						itemName: 'Provider Phone Number',
						description: '',
						icon: faPhone
					}
				]
			}
		];
	}

	onReady(editor: any): void {
		editor.ui
			.getEditableElement()
			.parentElement.insertBefore(
				editor.ui.view.toolbar.element,
				editor.ui.getEditableElement()
			);
	}

	ngOnInit(): void {
		this.files = [
			{
				expanded: true,
				label: 'Trinity Health Care',
				data: 'Trinity Health Care',
				expandedIcon: 'pi pi-folder-open',
				collapsedIcon: 'pi pi-folder',
				children: [
					{
						label: 'Trinity HC North',
						data: 'Work Folder',
						expandedIcon: 'pi pi-folder-open',
						collapsedIcon: 'pi pi-folder',
						children: [
							{
								label: 'Anesthesiology',
								icon: 'pi pi-file',
								data: 'Anesthesiology'
							},
							{
								label: 'Dermatology',
								icon: 'pi pi-file',
								data: 'Dermatology'
							}
						]
					},
					{
						label: 'Trinity HC North',
						data: 'Trinity HC North',
						expandedIcon: 'pi pi-folder-open',
						collapsedIcon: 'pi pi-folder',
						children: [
							{
								label: 'Pediatrics',
								icon: 'pi pi-file',
								data: 'Pediatrics'
							}
						]
					}
				]
			},
			{
				expanded: true,
				label: 'Hallmark Generic Templates',
				data: 'Hallmark Generic Templates',
				expandedIcon: 'pi pi-folder-open',
				collapsedIcon: 'pi pi-folder',
				children: [
					{
						label: 'Psychiatry',
						icon: 'pi pi-file',
						data: 'Psychiatry'
					},
					{
						label: 'Radiation oncology',
						icon: 'pi pi-file',
						data: 'Radiation oncology'
					},
					{
						label: 'Urology',
						icon: 'pi pi-file',
						data: 'Urology'
					}
				]
			}
		];
	}

	ngAfterViewInit() {
		this.onResize();
	}

	toggleSelectMode() {
		document
			.querySelectorAll('.template-image-space-cover')
			.forEach((e) => {
				e.classList.toggle('select-mode');
			});
		document.querySelectorAll('.btn-select-rename').forEach((e) => {
			if (e.textContent == 'Select') {
				e.textContent = 'Copy';
			} else {
				e.textContent = 'Select';
			}
		});
	}

	@HostListener('window:resize', ['$event'])
	onResize() {
		if (this.manuallToggleState) {
			if (window.innerWidth < 1200) {
				this.collapseSidebar();
			} else {
				this.expandSidebar();
			}
		}

		//If we start messing with contents of the toolbar, we will need to revise this logix.
		//I REALLY feel like theres a way to use flexbox to handle this but idk.

		if (this.templatesTopBar != null) {
			let toolbarHeight = Math.ceil(
				this.templatesTopBar.nativeElement.getBoundingClientRect()
					.height
			);

			console.log(toolbarHeight);

			if (toolbarHeight == 0) {
				if (window.innerWidth < 778) {
					toolbarHeight = 125;
				} else {
					toolbarHeight = 62;
				}

				if (window.innerWidth < 1200) {
					toolbarHeight += 16;
				}
			}

			const height = toolbarHeight + 60;

			this.templateContainer.nativeElement.style.height = `calc(100vh - ${height}px)`;
		}
	}

	collapseSidebar(): void {
		this.templateSidebar.nativeElement.classList.add('collapsed');
		this.container.nativeElement.classList.remove('has-sidebar');
	}

	expandSidebar(): void {
		this.templateSidebar.nativeElement.classList.remove('collapsed');
		this.container.nativeElement.classList.add('has-sidebar');
		this.templateSidebar.nativeElement.classList.remove('hidden');
	}

	hideSideBar() {
		this.templateSidebar.nativeElement.classList.add('hidden');
	}

	toggleSidebar(): void {
		this.manuallToggleState = !this.manuallToggleState;
		this.templateSidebar.nativeElement.classList.toggle('collapsed');
		this.container.nativeElement.classList.toggle('has-sidebar');
		this.templateSidebar.nativeElement.classList.remove('hidden');
	}

	unselect() {
		this.selectMode = false;
		this.onResize();
	}

	open(
		content: TemplateRef<string>,
		modalOptions: NgbModalOptions = {}
	): void {
		this.modalService.open(content, modalOptions).result;
	}
}

export class Section {
	name: string;
	items: SectionItem[];
}

export class SectionItem {
	itemName: string;
	description: string;
	icon: IconDefinition;
}
