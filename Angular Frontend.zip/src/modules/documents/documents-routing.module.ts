import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { DocumentsModule } from './documents.module';

/* Routes */
export const ROUTES: Routes = [];

@NgModule({
	imports: [DocumentsModule, RouterModule.forChild(ROUTES)],
	exports: [RouterModule]
})
export class DocumentsRoutingModule {}
