import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';

import { TableModule } from 'primeng/table';
import { MultiSelectModule } from 'primeng/multiselect';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputMaskModule } from 'primeng/inputmask';
import { AccordionModule } from 'primeng/accordion';
import { SplitterModule } from 'primeng/splitter';
import { InputNumberModule } from 'primeng/inputnumber';
import { ProgressBarModule } from 'primeng/progressbar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ListboxModule } from 'primeng/listbox';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TreeModule } from 'primeng/tree';

import { NgSelectModule } from '@ng-select/ng-select';
import { AngularMyDatePickerModule } from 'angular-mydatepicker';

// import { NgSelectModule } from '@ng-select/ng-select';
// import { BlockUIModule } from 'ng-block-ui';

import { LibraryComponent } from './containers/library/library.component';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Modules */

/* Components */
import * as adminComponents from './components';

/* Containers */
import * as adminContainers from './containers';

/* Guards */
import * as adminGuards from './guards';

/* Services */
import * as adminServices from './services';
@NgModule({
	imports: [
		CommonModule,
		RouterModule,
		ReactiveFormsModule,
		FormsModule,
		AppCommonModule,
		NavigationModule,
		CKEditorModule,

		TableModule,
		MultiSelectModule,
		InputSwitchModule,
		InputNumberModule,
		ProgressBarModule,
		OverlayPanelModule,
		AutoCompleteModule,
		TreeModule,
		ListboxModule,
		SplitterModule,
		InputMaskModule,
		AccordionModule,
		NgSelectModule,
		AngularMyDatePickerModule
	],
	providers: [...adminServices.services, ...adminGuards.guards],
	declarations: [
		...adminContainers.containers,
		...adminComponents.components,
		LibraryComponent
	],
	exports: [...adminContainers.containers, ...adminComponents.components]
})
export class DocumentsModule {}
