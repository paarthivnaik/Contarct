export interface Alert {
    icon: string;
    date: string;
    text: string;
}
