import {
	TemplateRef,
	Component,
	OnInit,
	ChangeDetectorRef
} from '@angular/core';
import { UsersService } from '@modules/admin/services';
import { NgbModalOptions, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { FilterService } from 'primeng/api';
import {
	faUserPlus,
	faTimesCircle,
	faCheckCircle,
	faFileExcel,
	faUpload,
	faTimes,
	faFilter
} from '@fortawesome/free-solid-svg-icons';
import { User } from '@common/models';
@Component({
	selector: 'app-admin-users',
	templateUrl: './users.component.html',
	styleUrls: ['users.component.scss']
})
export class UsersComponent implements OnInit {
	selectedRole: any;
	faUserPlus = faUserPlus;
	faTimesCircle = faTimesCircle;
	faCheckCircle = faCheckCircle;
	faFileExcel = faFileExcel;
	faUpload = faUpload;
	faTimes = faTimes;
	faFilter = faFilter;
	filterItems: string[];
	selectedFilters: Filters[];
	results: string[];
	filters: Filters[];
	users: User[];
	roles: { label: string; value: string }[];

	constructor(
		private cdr: ChangeDetectorRef,
		private usersService: UsersService,
		private filterService: FilterService,
		private modalService: NgbModal
	) {
		this.filterService.register(
			'includes',
			(value: any, filter: any): boolean => {
				console.log(value);
				console.log(filter);
				return value.toString() === filter.toString();
			}
		);
	}

	ngOnInit(): void {
		this.usersService.getUsers(1, 100).subscribe((x) => {
			this.users = x.results;
			for (let i = 0; i < 5; i++) {
				this.users = this.users.concat(this.users);
			}
		});

		this.roles = [
			{
				label: 'System Administrator',
				value: '2efa836e-ce88-4cb8-011a-08d8dd17fbee'
			},
			{
				label: 'Organization Administrator',
				value: '47017fb3-49d9-46ec-011b-08d8dd17fbee'
			}
		];

		this.filters = [
			{
				name: 'ID',
				code: 'id'
			},
			{
				name: 'First Name',
				code: 'firstName'
			},
			{
				name: 'Last Name',
				code: 'lastName'
			},
			{
				name: 'Region',
				code: 'region'
			},
			{
				name: 'Location',
				code: 'location'
			},
			{
				name: 'Cost Center',
				code: 'costCenter'
			},
			{
				name: 'Specialty',
				code: 'specialty'
			},
			{
				name: 'Template',
				code: 'template'
			},
			{
				name: 'Request Type',
				code: 'requestType'
			},
			{
				name: 'Status',
				code: 'status'
			}
		];

		this.selectedFilters = [];
		this.filterItems = [];

		this.cdr.detectChanges();
	}

	showFilter(filterName: string): boolean {
		const selected =
			this.filters.filter((f) => f.code === filterName).length > 0;
		return selected;
	}

	changedFilterSelection(): void {
		this.filterItems = this.selectedFilters.map(({ code }) => code);
		this.cdr.detectChanges();
	}

	removeFilter(filter: string): void {
		this.filterItems = this.filterItems.filter((o) => o !== filter);

		this.selectedFilters = this.selectedFilters.filter(
			(o) => o.code !== filter
		);
	}

	generateList(items: any[]): string {
		let result = '';
		items.forEach((i) => {
			result += `<li class='list-group-item'>${i.name}</li>`;
		});

		return `<ul class='list-group list-group-flush list-group-flush-popover'>${result}</ul>`;
	}

	search(event: any): void {
		console.log(event);
		this.results = ['John', 'Jane', 'Jack'];
	}

	open(
		content: TemplateRef<string>,
		modalOptions: NgbModalOptions = {}
	): void {
		this.modalService.open(content, modalOptions).result;
	}
}

export interface Filters {
	name: string;
	code: string;
}
