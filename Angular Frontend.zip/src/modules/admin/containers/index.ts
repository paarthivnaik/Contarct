import { UsersComponent } from './users/users.component';

export const containers = [UsersComponent];

export * from './users/users.component';
