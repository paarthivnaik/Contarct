import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { AdminModule } from './admin.module';

/* Routes */
export const ROUTES: Routes = [];

@NgModule({
	imports: [AdminModule, RouterModule.forChild(ROUTES)],
	exports: [RouterModule]
})
export class AdminRoutingModule {}
