import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { MultiSelectModule } from 'primeng/multiselect';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputMaskModule } from 'primeng/inputmask';
import { NgSelectModule } from '@ng-select/ng-select';

import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ListboxModule } from 'primeng/listbox';
/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Modules */

/* Components */
import * as adminComponents from './components';

/* Containers */
import * as adminContainers from './containers';

/* Guards */
import * as adminGuards from './guards';

/* Services */
import * as adminServices from './services';

@NgModule({
	imports: [
		CommonModule,
		RouterModule,
		ReactiveFormsModule,
		FormsModule,
		AppCommonModule,
		NavigationModule,

		OverlayPanelModule,
		AutoCompleteModule,
		TableModule,
		MultiSelectModule,
		ListboxModule,
		InputSwitchModule,
		InputMaskModule,
		NgSelectModule
	],
	providers: [...adminServices.services, ...adminGuards.guards],
	declarations: [
		...adminContainers.containers,
		...adminComponents.components
	],
	exports: [...adminContainers.containers, ...adminComponents.components]
})
export class AdminModule {}
