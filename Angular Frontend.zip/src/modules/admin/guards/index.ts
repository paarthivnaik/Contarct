import { AdminGuard } from './admin.guard';

export const guards = [AdminGuard];

export * from './admin.guard';
