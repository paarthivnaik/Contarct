import { UsersService } from './users.service';

export const services = [UsersService];

export * from './users.service';
