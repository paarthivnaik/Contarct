import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { HttpParams } from '@angular/common/http';
import { PagedResult } from '@common/models/paged-result';
import { Observable } from 'rxjs';
import { User } from '@common/models';

@Injectable()
export class UsersService {
	baseUrl: string;
	constructor(private http: HttpClient) {
		this.baseUrl = environment.endpoints.authorization;
	}

	getUsers(page: number, pageSize: number): Observable<PagedResult<User>> {
		return this.genericGetUsers('Users/get-users', page, pageSize);
	}

	getUsersGlobally(
		page: number,
		pageSize: number
	): Observable<PagedResult<User>> {
		return this.genericGetUsers('Users/get-users-globally', page, pageSize);
	}

	createUserGlobally(user: User): Observable<User> {
		return this.genericCreateUsers('Users/create-globally', user);
	}

	createUser(user: User): Observable<User> {
		return this.genericCreateUsers('Users/create', user);
	}

	updateUserGlobally(user: User): Observable<User> {
		return this.genericUpdateUsers('Users/update-globally', user);
	}

	updateUser(user: User): Observable<User> {
		return this.genericUpdateUsers('Users/update', user);
	}

	deleteUser(id: string): Observable<User> {
		const params = new HttpParams().set('id', id.toString());

		return this.http.put<User>(this.baseUrl + 'Users/delete', {
			params: params
		});
	}

	//TODO reset password logic.

	private genericUpdateUsers(url: string, user: User): Observable<User> {
		return this.http.put<User>(this.baseUrl + url, user);
	}

	private genericCreateUsers(url: string, user: User): Observable<User> {
		return this.http.post<User>(this.baseUrl + url, user);
	}

	private genericGetUsers(url: string, page: number, pageSize: number) {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<User>>(this.baseUrl + url, {
			params: params
		});
	}
}
