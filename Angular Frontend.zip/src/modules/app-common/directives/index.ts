// @ts-ignore
export const directives = [];
