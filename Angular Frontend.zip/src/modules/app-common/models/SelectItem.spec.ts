import { SelectItem } from './SelectItem';

describe('SelectItem', () => {
	it('should create an instance', () => {
		expect(new SelectItem()).toBeTruthy();
	});
});
