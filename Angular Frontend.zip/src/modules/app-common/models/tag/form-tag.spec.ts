import { FormTag } from './form-tag';

describe('FormTag', () => {
  it('should create an instance', () => {
    expect(new FormTag()).toBeTruthy();
  });
});
