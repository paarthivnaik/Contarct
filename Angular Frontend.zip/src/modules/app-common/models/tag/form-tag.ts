import { Tag } from './tag';

export class FormTag {
	tag: Tag;
	tagId: string;
}
