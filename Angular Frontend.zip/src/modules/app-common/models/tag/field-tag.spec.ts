import { FieldTag } from './field-tag';

describe('FieldTag', () => {
  it('should create an instance', () => {
    expect(new FieldTag()).toBeTruthy();
  });
});
