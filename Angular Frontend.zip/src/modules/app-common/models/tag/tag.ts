export class Tag {
	id: string;
	name: string;
	type: TagTypeEnum;
	organizationId: string;
}

export enum TagTypeEnum {
	Field = 1,
	Form = 2
}
