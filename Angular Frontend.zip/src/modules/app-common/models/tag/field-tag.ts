import { Tag } from './tag';

export class FieldTag {
	tag: Tag;
	tagId: string;
}
