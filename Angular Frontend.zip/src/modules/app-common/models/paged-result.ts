export interface PagedResultBase {
	currentPage: number;
	pageCount: number;
	pageSize: number;
	totalResults: number;
	firstRowOnPage: number;
	lastRowOnPage: number;
}

export interface PagedResult<T> extends PagedResultBase {
	results: T[];
}
