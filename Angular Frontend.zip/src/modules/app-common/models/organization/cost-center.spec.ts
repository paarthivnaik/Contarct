import { CostCenter } from './cost-center';

describe('CostCenter', () => {
  it('should create an instance', () => {
    expect(new CostCenter()).toBeTruthy();
  });
});
