import { Location } from './location';

export interface Region {
	id: string;
	name: string;
	active: boolean;
	organizationId: string;
	locations: Location[];
}
