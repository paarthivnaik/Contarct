import { Position } from './postion';

export interface Specialty {
	id: string;
	name: string;
	active: boolean;
	organizationId: string;
	positions: Position[];
}
