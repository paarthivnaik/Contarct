export interface CostCenter {
	id: string;
	name: string;
	active: boolean;
	locationId: string;
	locationName: string;
}
