export class Organization {
	id: string;
	name: string;
	address1: string;
	address2: string;
	city: string;
	state: string;
	zip: string;
	contactName: string;
	contactPhone: string;
	contactEmail: string;
	cptMissingEmail: string;
	logoUrl: string;
	active: boolean;
}
