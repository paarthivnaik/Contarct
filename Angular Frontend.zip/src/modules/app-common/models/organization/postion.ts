export interface Position {
	id: string;
	name: string;
	active: boolean;
	specialtyId: string;
	specialtyName: string;
}
