import { Region } from './region';

describe('Region', () => {
  it('should create an instance', () => {
    expect(new Region()).toBeTruthy();
  });
});
