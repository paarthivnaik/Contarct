import { Specialty } from './specialty';

describe('Specialty', () => {
  it('should create an instance', () => {
    expect(new Specialty()).toBeTruthy();
  });
});
