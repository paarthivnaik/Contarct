import { CostCenter } from './cost-center';

export class Location {
	id: string;
	name: string;
	active: boolean;
	regionId: string;
	regionName: string;
	costCenters: CostCenter[];
}
