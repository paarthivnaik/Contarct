import { Postion } from './postion';

describe('Postion', () => {
  it('should create an instance', () => {
    expect(new Postion()).toBeTruthy();
  });
});
