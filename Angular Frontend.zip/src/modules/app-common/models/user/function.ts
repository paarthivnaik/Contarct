export interface UserFunction {
    id: string;
    name: string;
    action: string;
    // application: Application;
    module: Module;
    category: Category;
}
export enum Module {
    Authentication,
}
export enum Category {
    User,
    Role,
}
