export class ApplicationUser {
	id: string;
	email: string;
	name: string;
	givenName: string;
	surname: string;
	roleId: string;
	roleHierarchy: number;
	role: string;
	organizationName: string;
	organizationId: string;
	functions: string[];
}
