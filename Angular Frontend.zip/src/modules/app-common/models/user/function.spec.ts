import { Function } from './function';

describe('Function', () => {
  it('should create an instance', () => {
    expect(new Function()).toBeTruthy();
  });
});
