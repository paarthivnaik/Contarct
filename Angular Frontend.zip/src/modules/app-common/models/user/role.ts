import { UserFunction } from './function';

export interface Role {
    id: string;
    name: string;
    hierarchy: number;
    active: boolean;
    functions: UserFunction[];
}
