import { Role, Organization } from '..';

export interface User {
	id: string;
	email: string;
	firstName: string;
	lastName: string;
	emailConfirmed: boolean;
	phoneNumber: string;
	phoneNumberConfirmed: boolean;
	lockoutEnabled: boolean;
	accessFailedCount: number;
	active: boolean;
	lastLogin: string | null;
	passwordExpiry: string;
	roles: Role[];
	organizations: Organization[];
	//applications: Application[];
}
