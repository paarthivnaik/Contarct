import { PagedResult } from './paged-result';

describe('PagedResult', () => {
  it('should create an instance', () => {
    expect(new PagedResult()).toBeTruthy();
  });
});
