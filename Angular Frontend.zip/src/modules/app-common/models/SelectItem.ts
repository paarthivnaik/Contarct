export class SelectItem {
	name: string;
	value: string;
	selected: boolean;
}
