import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import {
	HttpRequest,
	HttpHandler,
	HttpEvent,
	HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
	constructor(private jwtHelper: JwtHelperService) {}

	intercept(
		request: HttpRequest<unknown>,
		next: HttpHandler
	): Observable<HttpEvent<unknown>> {
		if (this.isUserValid() && this.token$ != null) {
			request = request.clone({
				setHeaders: {
					Authorization: `Bearer ${this.token$}`
				}
			});
		}
		return next.handle(request);
	}

	//Code stolen from user service, can't have a ref to that because DI recursion
	get token$(): string | null {
		return localStorage.getItem('token');
	}

	isUserValid(): boolean {
		return (
			this.token$ != null && !this.jwtHelper.isTokenExpired(this.token$)
		);
	}
}
