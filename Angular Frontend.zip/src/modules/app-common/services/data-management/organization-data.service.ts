import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
	Region,
	Location,
	CostCenter,
	PagedResult,
	Specialty,
	Position
} from '@common/models';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class OrganizationDataService {
	baseUrl: string;
	constructor(private http: HttpClient) {
		this.baseUrl = environment.endpoints.dataManagement;
	}

	getRegions(
		page: number,
		pageSize: number,
		children: boolean
	): Observable<PagedResult<Region>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString())
			.set('includeChildren', children.toString());

		return this.http.get<PagedResult<Region>>(this.baseUrl + 'Region', {
			params: params
		});
	}

	getLocations(
		page: number,
		pageSize: number
	): Observable<PagedResult<Location>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<Location>>(this.baseUrl + 'Location', {
			params: params
		});
	}

	getCostCenters(
		page: number,
		pageSize: number
	): Observable<PagedResult<CostCenter>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<CostCenter>>(
			this.baseUrl + 'CostCenter',
			{
				params: params
			}
		);
	}

	getSpecialties(
		page: number,
		pageSize: number
	): Observable<PagedResult<Specialty>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<Specialty>>(
			this.baseUrl + 'Specialty',
			{
				params: params
			}
		);
	}

	getPositions(
		page: number,
		pageSize: number
	): Observable<PagedResult<Position>> {
		const params = new HttpParams()
			.set('page', page.toString())
			.set('pageSize', pageSize.toString());

		return this.http.get<PagedResult<Position>>(this.baseUrl + 'Position', {
			params: params
		});
	}
}
