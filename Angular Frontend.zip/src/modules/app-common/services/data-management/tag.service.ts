import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tag } from '@common/models/tag/tag';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class TagService {
	baseUrl: string;

	constructor(private http: HttpClient) {
		this.baseUrl = environment.endpoints.dataManagement;
	}

	getTags(search: string, type: number): Observable<Tag[]> {
		const params = new HttpParams()
			.set('search', search)
			.set('type', type.toString());

		return this.http.get<Tag[]>(this.baseUrl + 'Tag', {
			params: params
		});
	}

	addTag(tag: Tag): Observable<Tag> {
		return this.http.post<Tag>(this.baseUrl + 'Tag', tag);
	}
}
