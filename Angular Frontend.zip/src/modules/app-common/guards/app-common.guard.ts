import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { UserService } from '@modules/auth/services';

@Injectable()
export class AppCommonGuard implements CanActivate {
	us: UserService;

	constructor(userService: UserService, private router: Router) {
		this.us = userService;
	}

	canActivate(route: ActivatedRouteSnapshot): Promise<boolean> {
		const functions: string[] =
			route &&
			route.data['functions'] &&
			route.data['functions'].length > 0
				? route.data['functions'].map((xx: string) => xx)
				: null;
		return new Promise<boolean>((resolve) => {
			if (!this.isAuthenticated()) {
				resolve(false);
				this.router.navigate(['login']);
			}

			const hasPermissions = this.us.hasFunctions(functions);
			if (hasPermissions) {
				resolve(true);
				return;
			} else {
				resolve(false);
				this.router.navigate(['login']);
			}
		});
	}

	canActivateChild(route: ActivatedRouteSnapshot): Promise<boolean> {
		const functions: string[] =
			route &&
			route.data['functions'] &&
			route.data['functions'].length > 0
				? route.data['functions'].map((xx: string) => xx)
				: null;

		return new Promise<boolean>((resolve) => {
			if (!this.isAuthenticated()) {
				resolve(false);
				this.router.navigate(['login']);
			}

			const hasPermissions = this.us.hasFunctions(functions);
			if (hasPermissions) {
				resolve(true);
				return;
			} else {
				resolve(false);
				this.router.navigate(['login']);
			}
		});
	}

	isAuthenticated(): boolean {
		return this.us.isUserValid();
	}
}
