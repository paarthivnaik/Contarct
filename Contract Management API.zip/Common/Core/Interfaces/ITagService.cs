using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Core.Interfaces
{
    public interface ITagService
    {
        Task<Tag> GetTag(Guid tagId);
        IQueryable<Tag> GetFormTags(string search);
        IQueryable<Tag> GetFieldTags(string search);
        IQueryable<Tag> GetTags(string search, TagTypeEnum type);
        Task<Tag> AddOrUpdateTag(Tag tag, bool saveNow = true);
        Task<IEnumerable<Tag>> AddOrUpdateTags(IEnumerable<Tag> tags);
        Task CleanupOrphanedTags();
    }
}
