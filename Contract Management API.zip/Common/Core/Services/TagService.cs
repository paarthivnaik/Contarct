using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Core.Interfaces;
using Common.Data;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Core.Services
{
    public class TagService : ITagService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public TagService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _db = db;
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
        }

        public IQueryable<Tag> GetFormTags(string search)
        {
            return TagSearch(search, TagTypeEnum.Form);
        }

        public IQueryable<Tag> GetFieldTags(string search)
        {
            return TagSearch(search, TagTypeEnum.Field);
        }

        public IQueryable<Tag> GetTags(string search, TagTypeEnum type)
        {
            return TagSearch(search, type);
        }

        private IQueryable<Tag> TagSearch(string search, TagTypeEnum type)
        {
            var query = _db.Tags.Where(x => x.OrganizationId == _user.OrganizationId && x.Type == type && x.Active);

            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(x => x.Name.Contains(search));
            }

            return query.OrderBy(x => x.Name);
        }

        public async Task<Tag> AddOrUpdateTag(Tag tag, bool saveNow = true)
        {
            Tag dbTag;
            if (tag.Id != Guid.Empty)
            {
                dbTag = await GetTag(tag.Id);
            }
            else
            {
                //Try to find it if it does not already exist
                dbTag = await _db.Tags.FirstOrDefaultAsync(x =>
                    x.OrganizationId == _user.OrganizationId
                    && x.Name == tag.Name
                    && x.Type == tag.Type);
            }

            if (dbTag != null)
            {
                dbTag.Name = tag.Name;
                dbTag.Type = tag.Type;
                _db.Tags.Update(dbTag);
            }
            else
            {
                dbTag = new Tag
                {
                    Name = tag.Name,
                    Type = tag.Type,
                    OrganizationId = _user.OrganizationId
                };
                await _db.Tags.AddAsync(dbTag);
            }

            if (saveNow)
            {
                await _db.SaveChangesAsync();
            }

            return dbTag;

        }

        public Task<Tag> GetTag(Guid tagId)
        {
            return _db.Tags.FirstOrDefaultAsync(x => x.Id == tagId && x.Active);
        }

        public async Task<IEnumerable<Tag>> AddOrUpdateTags(IEnumerable<Tag> tags)
        {
            if (tags == null)
            {
                return new List<Tag>();
            }
            else
            {
                var result = new List<Tag>();
                foreach (var t in tags)
                {
                    result.Add(await AddOrUpdateTag(t, false));
                }

                await _db.SaveChangesAsync();

                return result;
            }
        }

        public async Task CleanupOrphanedTags()
        {
            foreach (var type in (TagTypeEnum[])Enum.GetValues(typeof(TagTypeEnum)))
            {
                var tags = _db.Tags.Where(x => x.Type == type);
                IQueryable<Tag> tagsToDelete = null;
                switch (type)
                {
                    case TagTypeEnum.Field:
                       tagsToDelete = tags.Include(x => x.Fields).Where(x => x.Fields.Count == 0);
                       break;
                    case TagTypeEnum.Form:
                        tagsToDelete = tags.Include(x => x.Forms).Where(x => x.Forms.Count == 0);
                        break;
                }

                if (tagsToDelete != null)
                {
                    _db.Tags.RemoveRange(tagsToDelete.ToList());
                }
            }

            await _db.SaveChangesAsync();
        }
    }
}
