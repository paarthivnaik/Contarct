using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Common.Models;
using Common.StaticData;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

namespace Common
{
    public static class Extensions
    {
        /// <summary>
        /// Returns current user based on the JWT token provided with the request of the current <see cref="HttpContext"/>.
        /// </summary>
        /// <param name="context">Page context. This method can obviously only be used in </param>
        /// <returns></returns>
        public static async Task<ApplicationUser> GetUser(this HttpContext context)
        {
            var jwtConfig = AppSettingsInstance.Current.Configuration.JwtTokenConfig;
            var token = await context.GetTokenAsync("Bearer", "access_token");

            if (string.IsNullOrWhiteSpace(token))
            {
                throw new SecurityTokenException("Invalid token");
            }
            var principal = new JwtSecurityTokenHandler()
                .ValidateToken(token,
                    new TokenValidationParameters
                    {
                        ValidateIssuer = !string.IsNullOrEmpty(jwtConfig.Issuer),
                        ValidIssuer = jwtConfig.Issuer,
                        ValidAudience = jwtConfig.Audience,
                        ValidateAudience = !string.IsNullOrEmpty(jwtConfig.Audience),
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtConfig.Secret)),
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.FromMinutes(1)
                    },
                    out var validatedToken);

            if (!(validatedToken is JwtSecurityToken jwtToken) || !jwtToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256Signature) || principal.Identity == null)
            {
                throw new SecurityTokenException("Invalid token");
            }

            //Rememeber when pulling out claims, they will need to match what is provided by the GetUserClaims in authorization.
            return new ApplicationUser(principal.Claims);
        }

        /// <summary>
        /// Used in cases when we want either a user or a null value, good for logging. DO NOT USE FOR ID LOOKUPS. USE <see cref="GetUser" /> INSTEAD!
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static ApplicationUser TryGetUser(this HttpContext context)
        {
            ApplicationUser user = null;
            if (context != null)
            {
                try
                {
                    user = context.GetUser().Result;
                }
                catch (Exception)
                {
                    // ignored
                }
            }

            return user;
        }

        #region Paging Logic
        public static async Task<PagedResult<T>> ToPagedAsync<T>(this IQueryable<T> query,
            int page, int pageSize) where T : class
        {
            var result = new PagedResult<T>
            {
                CurrentPage = page,
                PageSize = pageSize,
                TotalResults = query.Count()
            };

            if (pageSize != -1)
            {
                var pageCount = (double)result.TotalResults / pageSize;
                result.PageCount = (int)Math.Ceiling(pageCount);

                var skip = (page - 1) * pageSize;
                result.Results = await query.Skip(skip).Take(pageSize).ToListAsync();
            }
            else
            {
                result.PageCount = 1;
                result.Results = await query.ToListAsync();
            }

            return result;
        }


        #endregion

        public static List<SelectItem> ToSelectItemList(this Dictionary<string, string> dict)
        {
            return dict.Select(x => new SelectItem
            {
                Name = x.Value, 
                Value = x.Key.ToString()
            }).ToList();
        }


        public static IServiceCollection AddFunctionBasedAuthentication(this IServiceCollection services)
        {
            //https://docs.microsoft.com/en-us/aspnet/core/security/authorization/policies?view=aspnetcore-5.0
            foreach (var function in Functions.AllFunctions)
            {
                services.AddAuthorization(options =>
                    options.AddPolicy(function.Name,
                        policy => policy.RequireClaim(CustomClaims.Functions, function.Name)));
            }

            return services;
        }

        /// <summary>
        /// A name that is generally considered safe to use anywhere as special charecters have been stripped (For url or document templates)
        /// </summary>
        /// <param name="phrase">Phrase to be slugified</param>
        /// <returns>Clean string</returns>
        public static string ToSlug(this string phrase)
        {
            string str = phrase.RemoveAccent().ToLower();
            // invalid chars           
            str = Regex.Replace(str, @"[^a-z0-9\s-]", "");
            // convert multiple spaces into one space   
            str = Regex.Replace(str, @"\s+", " ").Trim();
            // cut and trim 
            str = str.Substring(0, str.Length <= 45 ? str.Length : 45).Trim();
            str = Regex.Replace(str, @"\s", "-"); // hyphens   
            return str;
        }

        public static string RemoveAccent(this string txt)
        {
            byte[] bytes = Encoding.GetEncoding("Cyrillic").GetBytes(txt);
            return Encoding.ASCII.GetString(bytes);
        }
    }
}
