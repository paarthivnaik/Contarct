using System;
using System.Collections.Generic;
using System.Linq;
using Common.Models;

namespace Common.StaticData
{
    public static class NavMenuData
    {
        private static NavigationInformation _instance;

        public static NavigationInformation Instance
        {
            get
            {
                if (_instance != null) return _instance;

                _instance = new NavigationInformation
                {
                    Sections =
                        new List<Section>
                        {
                            new Section
                            {
                                //Text = " ",
                                Items = new List<string>
                                {
                                    "dashboard"
                                }
                            },
                            new Section
                            {
                                //Text = " ",
                                Items = new List<string>
                                {
                                    "car"
                                }
                            },
                            new Section
                            {
                                //Text = " ",
                                Items = new List<string>
                                {
                                    "documents"
                                }
                            },
                            new Section
                            {
                                //Text = "ADMINISTRATION",
                                Items = new List<string>
                                {
                                    "orgAdmin",
                                    "systemAdmin",
                                }
                            },
                            //new Section
                            //{
                            //    //Text = " ",
                            //    Items = new List<string>
                            //    {
                            //        "reports"
                            //    }
                            //},
                            //new Section
                            //{
                            //    //Text = "SUPPORT",
                            //    Items = new List<string>
                            //    {
                            //        "support"
                            //    }
                            //}
                        },
                    BaseMenu = new Dictionary<string, Submenu>
                    {
                        {
                            "dashboard",
                            new Submenu
                            {
                                Icon = "activity",
                                Text = "Dashboard",
                                Link = "/",
                                FunctionsRequired = new List<string>(),
                                Order = 0
                            }
                        },
                        {
                            "systemAdmin",
                            new Submenu
                            {
                                Icon = "shield",
                                Text = "System Admin",
                                FunctionsRequired = new List<string>(),
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "user",
                                        Text = "Users",
                                        Link = "/admin/users",
                                        FunctionsRequired = new List<string>
                                        {
                                            Functions.Authorization.Users.CreateAny.Name,
                                            Functions.Authorization.Users.DeleteAny.Name,
                                            Functions.Authorization.Users.EditAny.Name,
                                            Functions.Authorization.Users.ViewAny.Name,
                                        },
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "pocket",
                                        Text = "Roles",
                                        //Link = "/admin/roles",
                                        FunctionsRequired = new List<string>
                                        {
                                            Functions.Authorization.Roles.Create.Name,
                                            Functions.Authorization.Roles.Delete.Name,
                                            Functions.Authorization.Roles.Edit.Name,
                                            Functions.Authorization.Roles.View.Name,
                                        },
                                        Order = 1
                                    }
                                },
                                Order = 0
                            }
                        },
                        {
                            "orgAdmin",
                            new Submenu
                            {
                                Icon = "settings",
                                Text = "Organization Admin",
                                FunctionsRequired = new List<string> (),
                                Order = 0,
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "globe",
                                        Text = "Organization",
                                        //Link = "/admin/organization",
                                        FunctionsRequired = new List<string> (),
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "globe",
                                        Text = "Region",
                                        //Link = "/admin/region",
                                        FunctionsRequired = new List<string> (),
                                        Order = 1
                                    },
                                    new Submenu
                                    {
                                        Icon = "globe",
                                        Text = "Location",
                                        //Link = "/admin/location",
                                        FunctionsRequired = new List<string> (),
                                        Order = 2
                                    },
                                    new Submenu
                                    {
                                        Icon = "briefcase",
                                        Text = "Specialty",
                                        //Link = "/admin/specialty",
                                        FunctionsRequired = new List<string> (),
                                        Order = 3
                                    }
                                }
                            }
                        },
                        {
                            "car",
                            new Submenu
                            {
                                Icon = "list",
                                Text = "Contract Action Request",
                                FunctionsRequired = new List<string>(),
                                Order = 0,
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "list",
                                        Text = "View CARs",
                                        Link = "/car/list",
                                        FunctionsRequired = new List<string>(),
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "file-text",
                                        Text = "Create CAR",
                                        Link = "/car/create",
                                        FunctionsRequired = new List<string>(),
                                        Order = 1
                                    },
                                    new Submenu
                                    {
                                        Icon = "sidebar",
                                        Text = "CAR Templates",
                                        Link = "/car/template",
                                        FunctionsRequired = new List<string>(),
                                        Order = 2
                                    },
                                    new Submenu
                                    {
                                        Icon = "check-square",
                                        Text = "CAR Approval Setup",
                                        //Link = "/car/approval",
                                        FunctionsRequired = new List<string>(),
                                        Order = 3
                                    }
                                }
                            }
                        },
                        {
                            "documents",
                            new Submenu
                            {
                                Icon = "file-text",
                                Text = "Contract Documents",
                                FunctionsRequired = new List<string>(),
                                Order = 0,
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "grid",
                                        Text = "Template Library",
                                        Link = "/documents/library",
                                        FunctionsRequired = new List<string>(),
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "eye",
                                        Text = "View Contract Documents",
                                        //Link = "/documents/view",
                                        FunctionsRequired = new List<string>(),
                                        Order = 1
                                    },
                                    new Submenu
                                    {
                                        Icon = "file-text",
                                        Text = "Executed Contracts",
                                        //Link = "/documents/executed",
                                        FunctionsRequired = new List<string>(),
                                        Order = 2
                                    },
                                    new Submenu
                                    {
                                        Icon = "folder",
                                        Text = "Central Repository",
                                        //Link = "/documents/repository",
                                        FunctionsRequired = new List<string>(),
                                        Order = 3
                                    },
                                    new Submenu
                                    {
                                        Icon = "search",
                                        Text = "Search Contracts",
                                       // Link = "/documents/search",
                                        FunctionsRequired = new List<string>(),
                                        Order = 4
                                    }
                                }
                            }
                        },
                        {
                            "reports",
                            new Submenu
                            {
                                Icon = "database",
                                Text = "Reports",
                                FunctionsRequired = new List<string>(),
                                Order = 0,
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "database",
                                        Text = "Search Contracts",
                                        Link = "/report/car",
                                        FunctionsRequired = new List<string>(),
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "database",
                                        Text = "Upcoming Renewals",
                                        Link = "/report/renewal",
                                        FunctionsRequired = new List<string>(),
                                        Order = 1
                                    },
                                    new Submenu
                                    {
                                        Icon = "database",
                                        Text = "Contracts Expiring",
                                        Link = "/report/expiring",
                                        FunctionsRequired = new List<string>(),
                                        Order = 2
                                    }
                                }
                            }
                        },
                        {
                            "support",
                            new Submenu
                            {
                                Icon = "help-circle",
                                Text = "Support",
                                FunctionsRequired = new List<string>(),
                                Order = 0,
                                Submenus = new List<Submenu>
                                {
                                    new Submenu
                                    {
                                        Icon = "mail",
                                        Text = "Contact Us",
                                        Link = "/support/contact",
                                        FunctionsRequired = new List<string>(),
                                        Order = 0
                                    },
                                    new Submenu
                                    {
                                        Icon = "smile",
                                        Text = "Feedback",
                                        Link = "/support/feedback",
                                        FunctionsRequired = new List<string>(),
                                        Order = 1
                                    }
                                }
                            }
                        }
                    }
                };

                ValidateConfiguration(_instance.Sections, _instance.BaseMenu);

                return _instance;
            }
        }

        private static void ValidateConfiguration(List<Section> instanceSections,
            Dictionary<string, Submenu> instanceBaseMenu)
        {
            var sections = instanceBaseMenu.Select(x => x.Key).Distinct().ToList();
            var requiredSections = instanceSections.SelectMany(x => x.Items).Distinct().ToList();

            var notDeclared = requiredSections.Except(sections).ToList();
            if (notDeclared.Any())
            {
                throw new InvalidOperationException(
                    $"Tried to use Section in that does not exist: {string.Join(',', notDeclared)}");
            }

            //Do this once so we don't have to recalcuate this array on every iteration of a menu item
            var allFunctionNames = Functions.AllFunctions.Select(x => x.Name).ToList();
            foreach (Submenu menuItem in instanceBaseMenu.Values)
            {
                ValidationNavItems(menuItem, allFunctionNames);
            }
        }

        private static void ValidationNavItems(Submenu item, List<string> allFunctionNames)
        {
            if (item.FunctionsRequired == null)
            {
                throw new InvalidOperationException(
                    $"{item.Text} - Did not initalize functions required for menu item. Hint: Init empty list for no perms required.");
            }


            if (!string.IsNullOrEmpty(item.Icon))
            {
                if (!item.Icon.Equals(item.Icon.ToLowerInvariant()))
                {
                    throw new InvalidOperationException(
                        $"{item.Text} - Attempted to use capitalization with an icon name. This is not supported.");
                }
            }

            if (!string.IsNullOrEmpty(item.Link))
            {
                if (item.Submenus != null)
                {
                    throw new InvalidOperationException(
                        $"{item.Text} - Tried to give a submenu to a menu item with a link. Can't have both.");
                }

                if (item.Link.Contains(" "))
                {
                    throw new InvalidOperationException(
                        $"{item.Text} - Link contains spaces. URIs cannot contain spaces.");
                }
            }
            //else
            //{
            //    if (item.Submenus == null)
            //    {
            //        throw new InvalidOperationException(
            //            $"{item.Text} - Didn't give menu item anything to do. (No sub menus and no links).");
            //    }
            //}

            if (item.FunctionsRequired != null && item.FunctionsRequired.Count > 0)
            {
                var notDeclared = item.FunctionsRequired.Except(allFunctionNames).ToList();

                if (notDeclared.Any())
                {
                    throw new InvalidOperationException(
                        $"{item.Text} - Link requires a user function permission that does not exist: {string.Join(',', notDeclared)}");
                }
            }

            if (item.Submenus != null)
            {
                List<int> orderOccurances = new List<int>();

                foreach (var submenu in item.Submenus)
                {
                    ValidationNavItems(submenu, allFunctionNames);

                    if (orderOccurances.Any(x => x == submenu.Order))
                    {
                        throw new InvalidOperationException($"{item.Text} - Tried to add a repeated order value for menu item.");
                    }

                    orderOccurances.Add(submenu.Order);
                }
            }
        }
    }
}
