namespace Common.StaticData
{
    public class CustomClaims
    {
        internal const string ClaimTypeNamespace = "";

        public const string OrganizationId = ClaimTypeNamespace + "organizationid";
        public const string OrganizationName = ClaimTypeNamespace + "organizationname";
        public const string Functions = ClaimTypeNamespace + "functions";
        public const string RoleId = ClaimTypeNamespace + "roleid";
        public const string RoleHierarchy = ClaimTypeNamespace + "rolehierarchy";
    }
}
