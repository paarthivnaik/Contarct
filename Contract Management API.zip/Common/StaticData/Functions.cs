using System;
using System.Collections.Generic;
using Common.Data.Entities.Authorization;

namespace Common.StaticData
{

    //Please add any new functions here. The application will map these to database values accordingly.
    //Do not change the guid of existing ones, as that will break the id mapping and causing a duplicate to be created in the db.
    //Don't forget to do finalize name and add the function to the all functions list!
    public static class Functions
    {
        public static List<Function> AllFunctions = new List<Function>
        {
            Authorization.Users.Create,
            Authorization.Users.Delete,
            Authorization.Users.Edit,
            Authorization.Users.View,

            Authorization.Users.CreateAny,
            Authorization.Users.DeleteAny,
            Authorization.Users.EditAny,
            Authorization.Users.ViewAny,

            Authorization.Roles.Create,
            Authorization.Roles.Delete,
            Authorization.Roles.Edit,
            Authorization.Roles.View,
        };

        public class Authorization
        {
            public static class Users
            {
                public static Function Create = new Function
                {
                    Id = new Guid("2ece8898-931a-427a-b100-0c37a621feb1"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "Create"
                }.FinalizeName();
                public static Function Delete = new Function
                {
                    Id = new Guid("107546f8-2eee-4d46-91d5-4231b7cf4eaf"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "Delete"
                }.FinalizeName();
                public static Function Edit = new Function
                {
                    Id = new Guid("3f574cf5-406c-4312-a1ec-fe0ed96f6a5b"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "Edit"
                }.FinalizeName();
                public static Function View = new Function
                {
                    Id = new Guid("fedabf32-ec32-48dd-a387-3bbb4690411e"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "View"
                }.FinalizeName();

                public static Function CreateAny = new Function
                {
                    Id = new Guid("d2def3c4-15cc-40cf-9ce7-7ae5b831de51"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "CreateAny"
                }.FinalizeName();
                public static Function DeleteAny = new Function
                {
                    Id = new Guid("228c63d0-14a8-442b-bd78-901ce0171ee4"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "DeleteAny"
                }.FinalizeName();
                public static Function EditAny = new Function
                {
                    Id = new Guid("efe6d17f-9423-4e0b-b5f2-d26f38806caa"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "EditAny"
                }.FinalizeName();
                public static Function ViewAny = new Function
                {
                    Id = new Guid("47524ed0-8363-4e45-8308-b958d6ce8b98"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.User,
                    Action = "ViewAny"
                }.FinalizeName();
            }

            public static class Roles
            {
                public static Function View = new Function
                {
                    Id = new Guid("80112b81-42a5-4b14-920a-e000d85201de"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.Role,
                    Action = "View"
                }.FinalizeName();

                public static Function Create = new Function
                {
                    Id = new Guid("7d725338-3067-4706-b7f8-71c6301ba9cc"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.Role,
                    Action = "Create"
                }.FinalizeName();

                public static Function Edit = new Function
                {
                    Id = new Guid("e2464a6c-5695-4154-b4ab-4ba0687d5ba8"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.Role,
                    Action = "Edit"
                }.FinalizeName();

                public static Function Delete = new Function
                {
                    Id = new Guid("cd30df45-e35b-4d9a-ae69-b50d34f672d8"),
                    ModuleId = Enums.ModuleEnum.Authorization,
                    CategoryId = Enums.CategoryEnum.Role,
                    Action = "Delete"
                }.FinalizeName();
            }
        }
    }
}
