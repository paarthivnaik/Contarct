namespace Common.StaticData.Enums
{
    public enum ModuleEnum
    {
        DataManagement = 1,
        Authorization = 2,
        CAR = 3
    }

    public enum CategoryEnum
    {
        User = 1,
        Role = 2,
    }

    public enum InputTypeClassificationEnum
    {
        Text = 1,
        Number = 2,
        DateTime = 3,
        Option = 4,
        Group = 5
    }
}
