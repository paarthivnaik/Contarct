namespace Common.StaticData.Enums
{
    public enum PasswordResetReasonEnum
    {
        Welcome = 1,
        ForgotPassword = 2,
        AdminReset = 3,
    }
}
