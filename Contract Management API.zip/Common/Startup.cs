using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Common.Core.Interfaces;
using Common.Core.Services;
using Common.Data;
using Common.Data.Core.Interfaces;
using Common.Data.Core.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Sinks.MSSqlServer;

namespace Common
{
    public class Startup
    {

        public static void ConfigureCommonServices(IServiceCollection services, IConfiguration configuration, OpenApiInfo apiInfo)
        {
            bool isDebugging;
            #if DEBUG
            isDebugging = true;
            #else
            isDebugging = false;
            #endif

            var pathConfig = configuration.GetSection("Configuration");
            services.Configure<Configuration>(pathConfig);

           
            var config = pathConfig.Get<AppSettings>();

            services.Configure<AppSettings>(options => configuration.GetSection("Configuration").Bind(options));

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = true;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = !string.IsNullOrEmpty(config.JwtTokenConfig.Issuer),
                    ValidIssuer = config.JwtTokenConfig.Issuer,
                    ValidAudience = config.JwtTokenConfig.Audience,
                    ValidateAudience = !string.IsNullOrEmpty(config.JwtTokenConfig.Audience),
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(config.JwtTokenConfig.Secret)),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(1)
                };
            });
            
            services.AddFunctionBasedAuthentication();

            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.AllowTrailingCommas = true;
                options.JsonSerializerOptions.IgnoreNullValues = true;
                options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
            });

            //services.AddControllers().AddNewtonsoftJson(options =>
            //{
            //    options.AllowInputFormatterExceptionMessages = true;

            //    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
            //    //options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
            //});

            services.AddHttpContextAccessor();


            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", apiInfo);
                OpenApiSecurityScheme securityScheme = new OpenApiSecurityScheme
                {
                    Name = "JWT Authentication",
                    Description = "Enter JWT Bearer token **_only_**",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer", // must be lower case
                    BearerFormat = "JWT",
                    Reference = new OpenApiReference
                    {
                        Id = JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };
                c.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        securityScheme,
                        Array.Empty<string>()
                    }
                });
            });

            #region Logging
            var columnOpts = new ColumnOptions();
            columnOpts.Store.Remove(StandardColumn.MessageTemplate);
            columnOpts.TimeStamp.DataType = SqlDbType.DateTimeOffset;
            columnOpts.Properties.AllowNull = true;
            columnOpts.AdditionalColumns = new List<SqlColumn>
            {
                new SqlColumn
                {
                    ColumnName = "UserId",
                    DataType = SqlDbType.UniqueIdentifier,
                    AllowNull = true,
                    NonClusteredIndex = true
                },
                new SqlColumn
                {
                    ColumnName = "OrganizationId",
                    DataType = SqlDbType.UniqueIdentifier,
                    AllowNull = true,
                    NonClusteredIndex = true
                }
            };
            Log.Logger = new LoggerConfiguration()
                .WriteTo
                .MSSqlServer(
                    configuration.GetConnectionString("DefaultDatabase"),
                    new MSSqlServerSinkOptions
                    {
                        TableName = "LogEvents",
                        AutoCreateSqlTable = true
                    },
                    columnOptions: columnOpts
                    )
                .CreateLogger();
            #endregion

            services.AddScoped<IOrganizationService, OrganizationService>();
            services.AddScoped<IRegionSevice, RegionSevice>();
            services.AddScoped<ILocationService, LocationService>();
            services.AddScoped<ICostCenterService, CostCenterService>();
            services.AddScoped<ISpecialtyService, SpecialtyService>();
            services.AddScoped<IPositionService, PositionService>();
            services.AddScoped<ITagService, TagService>();
        }


        public static void ConfigureApplicaiton(IApplicationBuilder app, IWebHostEnvironment env, string name)
        {
            app.UseDefaultFiles(new DefaultFilesOptions
            {
                DefaultFileNames = new
                    List<string> { "index.html" }
            });
            app.UseStaticFiles();

            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", name));


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.SetupAllFunctions();

            if (name == "Authorization")
            {
                app.MigrateAndSeed();
            }
            
            app.UseHttpsRedirection();

            app.UseRouting();

            if (env.IsDevelopment())
            {
                app.UseCors(b => b.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            }

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }


        public class DateTimeConverter : JsonConverter<DateTime>
        {
            //Rememeber when accepting dates, youre going to get the datetimes as the USER'S local time. You then need to convert that to UTC before saving it.
            //Best approach is to avoid getting date/times as much as possible.
            public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
            {
                Debug.Assert(typeToConvert == typeof(DateTime));
                return DateTime.Parse(reader.GetString() ?? string.Empty);
            }

            public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
            {
                writer.WriteStringValue(value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ssZ"));
            }
        }
    }
}
