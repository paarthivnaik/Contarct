using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Common.Models
{
    public class NavigationInformation
    {
        public List<Section> Sections { get; set; } = new List<Section>();
        public Dictionary<string, Submenu> BaseMenu { get; set; } = new Dictionary<string, Submenu>();
    }

    public class Section
    {
        public string Text { get; set; }
        public List<string> Items { get; set; }
    }

    public class Submenu
    {
        public string Text { get; set; }
        public string Icon { get; set; }
        public string Link { get; set; }
        [JsonIgnore]
        public int Order { get; set; }
        [JsonPropertyName("submenu")]
        public List<Submenu> Submenus { get; set; }
        [JsonIgnore]
        public List<string> FunctionsRequired { get; set; }
    }
}
