using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using Common.StaticData;
// ReSharper disable UnusedMember.Global

namespace Common.Models
{
    public class ApplicationUser
    {
        private readonly List<Claim> _userClaims;

        public ApplicationUser(IEnumerable<Claim> userClaims)
        {
            _userClaims = userClaims.ToList();
        }

        //Because I can see this class being used very very often, I decided that the best approach for loading the claims is to do so on request, lazily.
        private Guid? _id;
        public Guid Id => GetClaimGuid(ClaimTypes.Sid, ref _id);

        private string _email;
        public string Email => GetClaimString(ClaimTypes.Email, ref _email);

        private string _name;
        public string Name => GetClaimString(ClaimTypes.Name, ref _name);

        private Guid? _roleId;
        public Guid RoleId => GetClaimGuid(CustomClaims.RoleId, ref _roleId);

        private int? _roleHierachy;
        public int RoleHierarchy => GetClaimInt(CustomClaims.RoleHierarchy, ref _roleHierachy);

        private string _role;
        public string Role => GetClaimString(ClaimTypes.Role, ref _role);

        private string _organizationName;
        public string OrganizationName => GetClaimString(CustomClaims.OrganizationName, ref _organizationName);

        private Guid? _organizationId;
        public Guid OrganizationId => GetClaimGuid(CustomClaims.OrganizationId, ref _organizationId);

        private List<string> _functions;
        public List<string> Functions => GetClaimStrings(CustomClaims.Functions, ref _functions);


        private List<string> GetClaimStrings(string claimName, ref List<string> check)
        {
            if (check == null)
            {
                check = new List<string>();
                var claims = _userClaims.Where(x => x.Type == claimName).ToList();

                if (!claims.Any())
                {
                    throw new Exception("Could not find user");
                }
                else
                {
                    check = claims.Select(x => x.Value).ToList();
                }
            }

            return check;
        }

        #region Claim Helpers

        private Guid GetClaimGuid(string claimName, ref Guid? check)
        {
            if (check == null)
            {
                var claim = _userClaims.FirstOrDefault(x => x.Type == claimName);

                if (claim == null)
                {
                    throw new Exception("Could not find user");
                }
                else
                {
                    check = Guid.Parse(claim.Value);
                }
            }

            return check.Value;
        }

        private string GetClaimString(string claimName, ref string check)
        {
            if (check == null)
            {
                var claim = _userClaims.FirstOrDefault(x => x.Type == claimName);

                if (claim == null)
                {
                    throw new Exception("Could not find user");
                }
                else
                {
                    check = claim.Value;
                }
            }

            return check;
        }

        private int GetClaimInt(string claimName, ref int? check)
        {
            if (check == null)
            {
                var claim = _userClaims.FirstOrDefault(x => x.Type == claimName);

                if (claim == null)
                {
                    throw new Exception("Could not find user");
                }
                else
                {
                    check = int.Parse(claim.Value);
                }
            }

            return check.Value;
        }

        #endregion


    }
}
