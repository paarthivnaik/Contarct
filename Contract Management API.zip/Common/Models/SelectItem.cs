namespace Common.Models
{
    public class SelectItem : ISelectItem
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }
    }

    public interface ISelectItem
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }
    }
}
