using System.IO;
using Microsoft.Extensions.Configuration;

namespace Common
{
    public class AppSettingsInstance
    {
        private static AppSettingsInstance _appSettings;

        /// <summary>
        /// Quick and dirty singleton that will grab the current appconfig settings. Perfect for places that are non injectable.
        /// </summary>
        public AppSettings Configuration { get; set; }

        public AppSettingsInstance(IConfiguration config)
        {
            Configuration = config.Get<AppSettings>();
            _appSettings = this;
        }

        public static AppSettingsInstance Current => _appSettings ??= GetCurrentSettings();

        public static AppSettingsInstance GetCurrentSettings()
        {
            //TODO, switch this to dbc getter with a 10 minute refresh timer 
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            IConfigurationRoot configuration = builder.Build();

            var settings = new AppSettingsInstance(configuration.GetSection("Configuration"));

            return settings;
        }
    }
}
