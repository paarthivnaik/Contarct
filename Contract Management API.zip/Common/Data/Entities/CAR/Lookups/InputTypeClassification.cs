using Common.Data.Interfaces;
using Common.StaticData.Enums;

namespace Common.Data.Entities.CAR.Lookups
{
    public class InputTypeClassification : ILookupTable<InputTypeClassificationEnum>
    {
        public InputTypeClassificationEnum Id { get; set; }
        public string Name { get; set; }
    }
}
