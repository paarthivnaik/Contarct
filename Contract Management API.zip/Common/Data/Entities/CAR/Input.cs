using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.CAR
{
    public class Input
    {
        [Column("InputId"), DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public Guid Id { get; set; }

        [Column("InputName"), MaxLength(512), Required]
        public string Name { get; set; }
        public bool Required { get; set; }
        public bool Active { get; set; }
        [JsonIgnore]
        public virtual Organization Organization { get; set; }
        [JsonIgnore]
        public Guid OrganizationId { get; set; }

        [Required]
        public virtual InputType InputType { get; set; }
        public int InputTypeId { get; set; }
        public int? MinLength { get; set; }
        public int? MaxLength { get; set; }
        public string Masking { get; set; }
        public string DefaultValueString { get; set; }

        public int? MinValue { get; set; }
        public int? MaxValue { get; set; }
        public int? DefaultValueNumber { get; set; }

        public DateTime? MinDate { get; set; }
        public DateTime? MaxDate { get; set; }
        public DateTime? DefaultDate { get; set; }

        public TimeSpan? MinTime { get; set; }
        public TimeSpan? MaxTime { get; set; }
        public TimeSpan? DefaultValueTime { get; set; }

        public string Options { get; set; }
        public string OptionsList { get; set; }
        public string OptionsListQuery { get; set; }
        public string OptionsListSp { get; set; }
        public int? MinSelection { get; set; }
        public int? MaxSelection { get; set; }
        public string DefaultValueOption { get; set; }


        public string DisplayFormat { get; set; }
        [Required, MaxLength(512)]
        public string Slug { get; set; }


        public bool PartOfInputGroup { get; set; } = false;

        //public bool System { get; set; } = false;
        public int? Row { get; set; }
        public int? RowWidth { get; set; }
        public int? Order { get; set; }
        public int Size { get; set; } = 1;
    }
}
