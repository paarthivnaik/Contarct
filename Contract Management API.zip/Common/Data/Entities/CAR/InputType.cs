using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data.Entities.CAR.Lookups;

namespace Common.Data.Entities.CAR
{
    public class InputType
    {
        [Key, Column("InputTypeId")]
        public int Id { get; set; }
        [Column("InputTypeName")]
        public string Name { get; set; }
        public string Description { get; set; }
        public InputTypeClassification Classification { get; set; } 
    }
}
