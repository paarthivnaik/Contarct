using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.CAR
{
    public class Form
    {
        [Column("FormId"), DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public Guid Id { get; set; }

        [Column("FormName"), MaxLength(512), Required]
        public string Name { get; set; }
        public string Description { get; set; }

        [JsonIgnore]
        public virtual Organization Organization { get; set; }
        [JsonIgnore]
        public Guid OrganizationId { get; set; }

        public virtual ICollection<FormSection> FormSections { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<Tag> Tags { get; set; }


        public virtual ICollection<Location> Locations { get; set; }
        public virtual ICollection<Region> Regions { get; set; }
        public virtual ICollection<CostCenter> CostCenters { get; set; }
        public virtual ICollection<Specialty> Specialties { get; set; }
        public virtual ICollection<Position> Postions { get; set; }
    }
}
