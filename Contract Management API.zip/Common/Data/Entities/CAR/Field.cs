using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.CAR
{
    public class Field
    {
        [Column("FieldId"), DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public Guid Id { get; set; }

        [Column("FieldName"), MaxLength(512), Required]
        public string Name { get; set; }
        [MaxLength(2048)]
        public string Description { get; set; }
        [MaxLength(2048)]
        public string HelpText { get; set; }
        public bool Active { get; set; }
        [JsonIgnore]
        public virtual Organization Organization { get; set; }
        [JsonIgnore]
        public Guid OrganizationId { get; set; }
        public virtual ICollection<Input> Inputs { get; set; }

        public bool IsInputGroup { get; set; }
        public int? Row { get; set; }
        public int? RowsUsed { get; set; }
        public int? RowWidth { get; set; }
        public int? Order { get; set; }
        public int? Size { get; set; }

        public virtual ICollection<Tag> Tags { get; set; }

        [JsonIgnore]
        public virtual ICollection<FormSection> FormSections { get; set; }

    }
}
