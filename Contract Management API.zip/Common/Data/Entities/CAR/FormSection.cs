using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.CAR
{
    public class FormSection
    {
        [Column("FormSectionId"), DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public Guid Id { get; set; }

        [Column("FormSectionName"), MaxLength(512), Required]
        public string Name { get; set; }

        public virtual ICollection<Field> Fields { get; set; }

        public bool Active { get; set; }

        [JsonIgnore]
        public virtual Organization Organization { get; set; }
        [JsonIgnore]
        public Guid OrganizationId { get; set; }
        [JsonIgnore]
        public virtual ICollection<Form> Forms { get; set; }
    }
}
