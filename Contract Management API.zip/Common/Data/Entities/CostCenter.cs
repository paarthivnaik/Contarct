using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Common.Data.Entities.CAR;

namespace Common.Data.Entities
{
    public class CostCenter
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("CostCenterId")]
        public Guid Id { get; set; }

        [Column("CostCenterName"), Required, MaxLength(512)]
        public string Name { get; set; }

        public bool Active { get; set; }
        [JsonIgnore]
        public virtual Location Location { get; set; }
        public Guid LocationId { get; set; }

        [JsonIgnore]
        public virtual ICollection<Form> Forms { get; set; }
    }
}
