using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Common.Data.Entities.CAR;

namespace Common.Data.Entities
{
    public class Region
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("RegionId")]
        public Guid Id { get; set; }

        [Column("RegionName"), Required, MaxLength(512)]
        public string Name { get; set; }

        public bool Active { get; set; }
        [JsonIgnore]
        public virtual Organization Organization { get; set; }

        public Guid OrganizationId { get; set; }

        public virtual ICollection<Location> Locations { get; set; }
        [JsonIgnore]
        public virtual ICollection<Form> Forms { get; set; }

    }
}
