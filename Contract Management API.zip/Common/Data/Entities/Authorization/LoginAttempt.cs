using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data.Entities.Authorization.Lookups;
using Common.StaticData.Enums;

namespace Common.Data.Entities.Authorization
{
    public class LoginAttempt
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("LoginAttemptId")]
        public Guid Id { get; set; }
        [MaxLength(128), Required]
        public string Email { get; set; }
        [MaxLength(512)]
        public string UserAgent { get; set; }
        [MaxLength(128)]
        public string IpAddress { get; set; }
        [Required]
        public LoginResult LoginResult { get; set; }
        [Required]
        public LoginResultEnum LoginResultId { get; set; }
        public DateTime AttemptDateTime { get; set; }
    }
}
