using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data.Entities.Authorization.Lookups;

namespace Common.Data.Entities.Authorization
{
    public class PasswordTicket
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("TicketId")]
        public Guid Id { get; set; }
        [MaxLength(32), Required]
        public string Token { get; set; }
        [Required]
        public PasswordResetReason Reason { get; set; }
        [Required]
        public StaticData.Enums.PasswordResetReasonEnum ReasonId { get; set; }
        [MaxLength(128)]
        public string RequesterIp { get; set; }
        [MaxLength(512)]
        public string RequesterUserString { get; set; }
        public DateTime? RequestedAt { get; set; }
        [MaxLength(128)]
        public string ConsumerIp { get; set; }
        [MaxLength(512)]
        public string ConsumerUserString { get; set; }
        public DateTime? ConsumedAt { get; set; }

        public bool UnlockAccountOnUse { get; set; }

        public DateTime Expiry { get; set; }

        public User User { get; set; }
        public string Email { get; set; }
    }
}
