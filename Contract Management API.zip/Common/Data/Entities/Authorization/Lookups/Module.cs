using Common.Data.Interfaces;
using Common.StaticData.Enums;

namespace Common.Data.Entities.Authorization.Lookups
{
    public class Module : ILookupTable<ModuleEnum>
    {
        public ModuleEnum Id { get; set; }
        public string Name { get; set; }
    }
}
