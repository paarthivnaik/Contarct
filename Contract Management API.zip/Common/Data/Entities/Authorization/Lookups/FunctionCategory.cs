using Common.Data.Interfaces;
using Common.StaticData.Enums;

namespace Common.Data.Entities.Authorization.Lookups
{
    public class FunctionCategory : ILookupTable<CategoryEnum>
    {
        public CategoryEnum Id { get; set; }
        public string Name { get; set; }
    }
}
