using Common.Data.Interfaces;
using Common.StaticData.Enums;

namespace Common.Data.Entities.Authorization.Lookups
{
    public class LoginResult : ILookupTable<LoginResultEnum>
    {
        public LoginResultEnum Id { get; set; }
        public string Name { get; set; }
    }
}
