using Common.Data.Interfaces;
using Common.StaticData.Enums;

namespace Common.Data.Entities.Authorization.Lookups
{
    public class PasswordResetReason : ILookupTable<PasswordResetReasonEnum>
    {
        public PasswordResetReasonEnum Id { get; set; }
        public string Name { get; set; }
    }
}
