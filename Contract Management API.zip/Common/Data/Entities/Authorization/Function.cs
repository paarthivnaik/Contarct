using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data.Entities.Authorization.Lookups;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.Authorization
{
    public class Function
    {
        [Key, Column("FunctionId")]
        public Guid Id { get; set; }
        [Column("FunctionName"), Required]
        public string Name { get; set; }
        [MaxLength(512), Required]
        public string Action { get; set; }
        public Application Application { get; set; }
        [Required]
        public Module Module { get; set; }
        [Required]
        public StaticData.Enums.ModuleEnum ModuleId { get; set; }
        [Required]
        public FunctionCategory Category { get; set; }
        [Required]
        public StaticData.Enums.CategoryEnum CategoryId { get; set; }

        [JsonIgnore]
        public virtual ICollection<Role> Roles { get; set; } = new List<Role>();

        public Function FinalizeName()
        {
            Name = $"{Enum.GetName(ModuleId)}.{Enum.GetName(CategoryId)}.{Action}";
            return this;
        }
    }
}
