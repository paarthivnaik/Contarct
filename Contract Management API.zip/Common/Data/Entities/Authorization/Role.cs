#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.Authorization
{
    public class Role
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("RoleId")]
        public Guid Id { get; set; }

        [MaxLength(128), Column("RoleName"), Required]
        public string Name { get; set; }
        /// <summary>
        /// Hiearchy used to dictate which roles can edit other roles. Roles of the same level can edit each other (Assuming they have the ability to edit roles).
        /// </summary>
        public int Hierarchy { get; set; }
        public bool Active { get; set; }
        public virtual ICollection<Function> Functions { get; set; } = new List<Function>();
        [JsonIgnore]
        public virtual Organization? Organization { get; set; }


        [JsonIgnore]
        public virtual ICollection<User> Users { get; set; } = new List<User>();
    }
}
