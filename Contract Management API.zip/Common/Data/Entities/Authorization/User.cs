using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities.Authorization
{
    public class User
    {
        /// <summary>
        /// Gets or sets the primary key for this user.
        /// </summary>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("UserId")]
        public Guid Id { get; set; }
        
        /// <summary>
        /// Gets or sets a salted and hashed representation of the password for this user.
        /// </summary>
        [JsonIgnore]
        public byte[] Password { get; set; }

        /// <summary>
        /// A random value that must change whenever a users credentials change (password changed, login removed)
        /// </summary>
        [JsonIgnore]
        public Guid SecurityStamp { get; set; }

        /// <summary>
        /// Gets or sets the email address for this user.
        /// </summary>
        [MaxLength(128), DataType(DataType.EmailAddress), Required]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the first name for this user.
        /// </summary>
        [MaxLength(128)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name for this user.
        /// </summary>
        [MaxLength(128)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating if a user has confirmed their email address.
        /// </summary>
        /// <value>True if the email address has been confirmed, otherwise false.</value>
        public bool EmailConfirmed { get; set; }

        /// <summary>
        /// Gets or sets a telephone number for the user.
        /// </summary>
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating if a user has confirmed their telephone address.
        /// </summary>
        /// <value>True if the telephone number has been confirmed, otherwise false.</value>
        public bool PhoneNumberConfirmed { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating if the user could be locked out.
        /// </summary>
        /// <value>True if the user could be locked out, otherwise false.</value>
        public bool LockoutEnabled { get; set; }

        /// <summary>
        /// Gets or sets the number of failed login attempts for the current user.
        /// </summary>
        public int AccessFailedCount { get; set; }

        /// <summary>
        /// The active state of the user indicates if the account is marked as "deleted" or not. Accounts should usually never be deleted.
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// When the user has last logged in
        /// </summary>
        public DateTime? LastLogin { get; set; }

        /// <summary>
        /// When the password should expire
        /// </summary>
        public DateTime PasswordExpiry { get; set; }

        /// <summary>
        /// The roles that have been assigned to the user
        /// </summary>
        public virtual ICollection<Role> Roles { get; set; } = new List<Role>();
        public virtual ICollection<Organization> Organizations { get; set; } = new List<Organization>();
        public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

        [JsonIgnore]
        public virtual ICollection<PasswordTicket> PasswordTickets { get; set; } = new List<PasswordTicket>();

        [JsonIgnore]
        public virtual ICollection<JwtRefreshToken> Sessions { get; set; } = new List<JwtRefreshToken>();

    }
}
