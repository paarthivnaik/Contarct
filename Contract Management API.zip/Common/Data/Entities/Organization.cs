using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Common.Data.Entities.Authorization;
using Common.Data.Entities.CAR;

namespace Common.Data.Entities
{
    public class Organization
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("OrganizationId")]
        public Guid Id { get; set; }

        [Column("OrganizationName"), Required, MaxLength(512)]
        public string Name { get; set; }
        [MaxLength(1024)]
        public string Address1 { get; set; }
        [MaxLength(1024)]
        public string Address2 { get; set; }
        public string City { get; set; }
        [MaxLength(2)]
        public string State { get; set; }
        [MaxLength(12)]
        public string Zip { get; set; }

        public Tennant Tennant { get; set; }

        [MaxLength(512)]
        public string ContactName { get; set; }

        [MaxLength(128), DataType(DataType.PhoneNumber)]
        public string ContactPhone { get; set; }

        [MaxLength(128), DataType(DataType.EmailAddress)]
        public string ContactEmail { get; set; }

        [MaxLength(128), DataType(DataType.EmailAddress)]
        public string CptMissingEmail { get; set; }
        [JsonIgnore]
        public string LogoFileName { get; set; }
        public string LogoUrl { get; set; }

        public bool Active { get; set; }

        public virtual ICollection<Region> Regions { get; set; }

        #region Relational Collections
        [JsonIgnore]
        public virtual ICollection<User> Users { get; set; }

        [JsonIgnore]
        public virtual ICollection<Tag> Tags { get; set; }

        [JsonIgnore]
        public virtual ICollection<Input> Inputs { get; set; }

        [JsonIgnore]
        public virtual ICollection<Field> Fields { get; set; }

        [JsonIgnore]
        public virtual ICollection<Form> Forms { get; set; }

        [JsonIgnore]
        public virtual ICollection<Role> Roles { get; set; }

        [JsonIgnore]
        public virtual ICollection<Position> Positions { get; set; }

        [JsonIgnore]
        public virtual ICollection<Specialty> Specialties { get; set; }

        [JsonIgnore]
        public virtual ICollection<FormSection> FormSections { get; set; }

        #endregion

    }
}
