using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Common.Data.Entities.Authorization;

namespace Common.Data.Entities
{
    public class Application
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("ApplicationId")]
        public Guid Id { get; set; }

        [Column("ApplicationName"), Required, MaxLength(512)]
        public string Name { get; set; }
        public string Description { get; set; }
        [JsonIgnore]
        public virtual ICollection<User> Users { get; set; }
    }
}
