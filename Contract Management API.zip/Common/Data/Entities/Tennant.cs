using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Data.Entities
{
    public class Tennant
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key, Column("TennantId")]
        public Guid Id { get; set; }

        [Column("TennantName"), Required, MaxLength(512)]
        public string Name { get; set; }

        [JsonIgnore]
        public virtual ICollection<Organization> Organization { get; set; }
    }
}
