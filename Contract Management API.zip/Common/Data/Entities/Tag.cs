using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Common.Data.Entities.CAR;

namespace Common.Data.Entities
{
    public class Tag
    {
        [Column("TagId"), Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }
        [Column("TagName")]
        public string Name { get; set; }
        public TagTypeEnum Type { get; set; } //TODO Lookup table maybe?

        [JsonIgnore]
        public Organization Organization { get; set; }
        [JsonIgnore]
        public Guid OrganizationId { get; set; }
        [JsonIgnore]
        public virtual ICollection<Form> Forms { get; set; }
        [JsonIgnore]
        public virtual ICollection<Field> Fields { get; set; }
        public bool Active { get; set; }
    }

    public enum TagTypeEnum
    {
        Field = 1,
        Form = 2
    }
}
