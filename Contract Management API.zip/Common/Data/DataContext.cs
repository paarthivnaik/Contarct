using Common.Data.Entities;
using Common.Data.Entities.Authorization;
using Common.Data.Entities.Authorization.Lookups;
using Common.Data.Entities.CAR;
using Common.Data.Entities.CAR.Lookups;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Common.Data
{
    public class DataContext : DbContext
    {
        private readonly DbContextOptions<DataContext> _options;

        #region Authorization
        public DbSet<User> Users { get; set; }
        public DbSet<PasswordTicket> PasswordTickets { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Function> Functions { get; set; }
        public DbSet<LoginAttempt> LoginAttempts { get; set; }
        public DbSet<JwtRefreshToken> Sessions { get; set; }
        #endregion

        #region CAR

        public DbSet<Form> Forms { get; set; }
        public DbSet<Field> Fields { get; set; }
        public DbSet<FormSection> FormSections { get; set; }
        public DbSet<Input> Inputs { get; set; }
        public DbSet<InputType> InputsTypes { get; set; }
        //public DbSet<FieldTag> FieldTags { get; set; }
        //public DbSet<FormTag> FormTags { get; set; }

        #endregion

        #region Lookup Tables
        //Common
        public DbSet<Module> Modules { get; set; }
        //Auth
        public DbSet<LoginResult> LoginResults { get; set; }
        //Auth
        public DbSet<FunctionCategory> FunctionCategories{ get; set; }
        //Auth
        public DbSet<PasswordResetReason> PasswordResetReasons { get; set; }

        //CAR
        public DbSet<InputTypeClassification> InputTypeClassifications { get; set; }
        #endregion

        #region Common
        public DbSet<Organization> Organizations { get; set; }
        public DbSet<Region> Regions { get; set; }
        public DbSet<Location> Locations { get; set; }
        public DbSet<CostCenter> CostCenters{ get; set; }
        public DbSet<Tennant> Tennants { get; set; }
        public DbSet<Specialty> Specialties{ get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<Application> Applications { get; set; }
        public DbSet<Tag> Tags { get; set; }
        #endregion

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
            _options = options;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            #region Authorization
            modelBuilder.Entity<User>().HasIndex(p => p.Email).IsUnique();

            modelBuilder.Entity<Function>().HasIndex(p => p.Name).IsUnique();

            modelBuilder.Entity<Role>().HasIndex(p => p.Name).IsUnique();

            modelBuilder.Entity<Organization>().HasIndex(p => p.Name).IsUnique();

            modelBuilder.Entity<PasswordTicket>()
                .HasOne(p => p.User).WithMany(t => t.PasswordTickets)
                .HasForeignKey(x => x.Email).HasPrincipalKey(x => x.Email);
            #endregion

            #region CAR

            modelBuilder.Entity<FormSection>()
                .HasOne(x => x.Organization)
                .WithMany(x => x.FormSections)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<Form>()
                .HasMany(p => p.Tags)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormTags",
                    j => j
                        .HasOne<Tag>()
                        .WithMany()
                        .HasForeignKey("TagId")
                        .HasConstraintName("FK_FormTags_Tags_TagId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormTags_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));

            modelBuilder.Entity<Field>()
                .HasMany(p => p.Tags)
                .WithMany(p => p.Fields)
                .UsingEntity<Dictionary<string, object>>(
                    "FieldTags",
                    j => j
                        .HasOne<Tag>()
                        .WithMany()
                        .HasForeignKey("TagId")
                        .HasConstraintName("FK_FieldTags_Tags_TagId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Field>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FieldTags_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));


            //modelBuilder.Entity<FieldTag>().HasKey(t => new { t.FieldId, t.TagId });

            //modelBuilder.Entity<FieldTag>()
            //    .HasOne(pt => pt.Field)
            //    .WithMany(p => p.Tags)
            //    .HasForeignKey(pt => pt.FieldId)
            //    .HasPrincipalKey(x => x.Id)
            //    .OnDelete(DeleteBehavior.Restrict);

            //modelBuilder.Entity<FieldTag>()
            //    .HasOne(pt => pt.Tag)
            //    .WithMany(t => t.Fields)
            //    .HasForeignKey(pt => pt.TagId)
            //    .HasPrincipalKey(x => x.Id)
            //    .OnDelete(DeleteBehavior.Cascade);

            //modelBuilder.Entity<FormTag>().HasKey(t => new { t.FormId, t.TagId });

            //modelBuilder.Entity<FormTag>()
            //    .HasOne(pt => pt.Form)
            //    .WithMany(p => p.Tags)
            //    .HasForeignKey(pt => pt.FormId)
            //    .HasPrincipalKey(x => x.Id)
            //    .OnDelete(DeleteBehavior.Restrict);

            //modelBuilder.Entity<FormTag>()
            //    .HasOne(pt => pt.Tag)
            //    .WithMany(t => t.Forms)
            //    .HasForeignKey(pt => pt.TagId)
            //    .HasPrincipalKey(x => x.Id)
            //    .OnDelete(DeleteBehavior.Cascade);


            #region Form Assignments
            modelBuilder.Entity<Form>()
                .HasMany(p => p.Regions)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormRegions",
                    j => j
                        .HasOne<Region>()
                        .WithMany()
                        .HasForeignKey("RegionId")
                        .HasConstraintName("FK_FormRegions_Region_RegionsId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormRegions_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));


            modelBuilder.Entity<Form>()
                .HasMany(p => p.Locations)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormLocations",
                    j => j
                        .HasOne<Location>()
                        .WithMany()
                        .HasForeignKey("LocationId")
                        .HasConstraintName("FK_FormLocations_Location_LocationId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormLocations_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));


            modelBuilder.Entity<Form>()
                .HasMany(p => p.CostCenters)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormCostCenters",
                    j => j
                        .HasOne<CostCenter>()
                        .WithMany()
                        .HasForeignKey("RegionId")
                        .HasConstraintName("FK_FormCostCenters_CostCenter_CostCenterId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormCostCenters_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));

            modelBuilder.Entity<Form>()
                .HasMany(p => p.Specialties)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormSpecialties",
                    j => j
                        .HasOne<Specialty>()
                        .WithMany()
                        .HasForeignKey("SpecialtyId")
                        .HasConstraintName("FK_FormSpecialties_Specialty_SpecialtyId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormSpecialties_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));

            modelBuilder.Entity<Form>()
                .HasMany(p => p.Postions)
                .WithMany(p => p.Forms)
                .UsingEntity<Dictionary<string, object>>(
                    "FormPositions",
                    j => j
                        .HasOne<Position>()
                        .WithMany()
                        .HasForeignKey("PositionId")
                        .HasConstraintName("FK_FormPositions_Position_PositionId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Form>()
                        .WithMany()
                        .HasForeignKey("FormId")
                        .HasConstraintName("FK_FormPositions_Form_FormId")
                        .OnDelete(DeleteBehavior.ClientCascade));


            #endregion

            #endregion
        }
    }
}
