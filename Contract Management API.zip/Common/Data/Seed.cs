using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using Common.Data.Entities;
using Common.Data.Entities.Authorization;
using Common.Data.Entities.Authorization.Lookups;
using Common.Data.Entities.CAR;
using Common.Data.Entities.CAR.Lookups;
using Common.Data.Interfaces;
using Common.StaticData;
using Common.StaticData.Enums;
using Microsoft.EntityFrameworkCore;

namespace Common.Data
{
    public static class Seed
    {
        internal static DataContext AddOrUpdateSeedData(this DataContext dataContext)
        {

            Stopwatch sw = Stopwatch.StartNew();

            #region LookupTables

            SetupLookupTable<InputTypeClassificationEnum, InputTypeClassification>(dataContext.InputTypeClassifications);
            SetupLookupTable<LoginResultEnum, LoginResult>(dataContext.LoginResults);
            SetupLookupTable<PasswordResetReasonEnum, PasswordResetReason>(dataContext.PasswordResetReasons);

            dataContext.SaveChanges();

            #endregion

            #region Organizations
            if (!dataContext.Organizations.Any())
            {
                List<Organization> organizations = new List<Organization>
                {
                    new Organization
                    {
                        Name = "Hallmark HCS",
                        Active = true
                    },
                    new Organization
                    {
                        Name = "Trinidad Health",
                        Active = true,
                        Positions = new List<Position>
                        {
                            new Position
                            {
                                Name = "Medical technologist",
                                Active = true
                            },
                            new Position
                            {
                                Name = "Anesthesiologist",
                                Active = true
                            },
                            new Position
                            {
                                Name = "Surgeon",
                                Active = true
                            },
                            new Position
                            {
                                Name = "Physician Assistant",
                                Active = true
                            },
                            new Position
                            {
                                Name = "Nurse",
                                Active = true
                            },
                            new Position
                            {
                                Name = "Pharmacist",
                                Active = true
                            }
                        },
                        Specialties = new List<Specialty>
                        {
                            new Specialty
                            {
                                Name = "Anesthesiology",
                                Active = true,
                            },
                            new Specialty
                            {
                                Name = "Dermatology",
                                Active = true,
                            },
                            new Specialty
                            {
                                Name = "Diagnostic Radiology",
                                Active = true,
                            }
                        },
                        Regions = new List<Region>
                        {
                            new Region
                            {
                                Name = "TH North",
                                Active = true,
                                Locations = new List<Location>
                                {
                                    new Location
                                    {
                                        Name = "Sebring Medical Center",
                                        Active = true,
                                        CostCenters = new List<CostCenter>
                                        {
                                            new CostCenter
                                            {
                                                Name = "Trauma ICU",
                                                Active = true,
                                            },
                                            new CostCenter
                                            {
                                                Name = "Neonatal ICU",
                                                Active = true,
                                            }
                                        }
                                    },
                                    new Location
                                    {
                                        Name = "Hastings Medical Center",
                                        Active = true,
                                        CostCenters = new List<CostCenter>
                                        {
                                            new CostCenter
                                            {
                                                Name = "Psychiatric",
                                                Active = true,
                                            },
                                            new CostCenter
                                            {
                                                Name = "Pediatric",
                                                Active = true,
                                            }
                                        }
                                    }
                                }
                            },
                            new Region
                            {
                                Name = "TH South",
                                Active = true,
                                Locations = new List<Location>
                                {
                                    new Location
                                    {
                                        Name = "Darwin Medical Center",
                                        Active = true,
                                        CostCenters = new List<CostCenter>
                                        {
                                            new CostCenter
                                            {
                                                Name = "Nursery",
                                                Active = true
                                            },
                                            new CostCenter
                                            {
                                                Name = "Pediatric",
                                                Active = true
                                            }
                                        }
                                    },
                                    new Location
                                    {
                                        Name = "Charles Medical Center",
                                        Active = true,
                                        CostCenters = new List<CostCenter>
                                        {
                                            new CostCenter
                                            {
                                                Name = "Trauma",
                                                Active = true,
                                            },
                                            new CostCenter
                                            {
                                                Name = "Detox",
                                                Active = true,
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                };
                dataContext.Organizations.AddRange(organizations);
                dataContext.SaveChanges();
            }
            #endregion

            #region Roles and Functions

            if (dataContext.Roles.Count() < 2)
            {
                var sysAdminFunctions = new List<Function>
                {
                    Functions.Authorization.Roles.View,
                    Functions.Authorization.Roles.Create,
                    Functions.Authorization.Roles.Delete,
                    Functions.Authorization.Roles.Edit,

                    Functions.Authorization.Users.View,
                    Functions.Authorization.Users.Create,
                    Functions.Authorization.Users.Delete,
                    Functions.Authorization.Users.Edit,

                    Functions.Authorization.Users.ViewAny,
                    Functions.Authorization.Users.CreateAny,
                    Functions.Authorization.Users.DeleteAny,
                    Functions.Authorization.Users.EditAny
                }.Select(x => x.Id);

                var orgAdminF = new List<Function>
                {
                    Functions.Authorization.Users.View,
                    Functions.Authorization.Users.Create,
                    Functions.Authorization.Users.Delete,
                    Functions.Authorization.Users.Edit
                }.Select(x => x.Id);
                

                List<Role> roles = new List<Role> {
                    new Role
                    {
                        Name = "System Administrator", 
                        Functions = dataContext.Functions.Where(x => sysAdminFunctions.Contains(x.Id)).ToList(), 
                        Hierarchy = -1,
                        Active = true
                    },
                    new Role
                    {
                        Name = "Organization Administrator", 
                        Functions =  dataContext.Functions.Where(x => orgAdminF.Contains(x.Id)).ToList(),
                        Hierarchy = 0,
                        Organization = dataContext.Organizations.FirstOrDefault(x => x.Name == "Trinidad Health"),
                        Active = true
                    }
                };
                dataContext.Roles.AddRange(roles);
                dataContext.SaveChanges();
            }
            #endregion

            #region Tennants
            if (!dataContext.Tennants.Any())
            {
                List<Tennant> tennants = new List<Tennant>
                {
                    new Tennant
                    {
                        Name = "Hallmark HCS",
                        Organization = dataContext.Organizations.Where(x => x.Name == "Hallmark HCS").ToList()
                    },
                    new Tennant
                    {
                        Name = "Trinidad Health",
                        Organization = dataContext.Organizations.Where(x => x.Name == "Trinidad Health").ToList()
                    }
                };
                dataContext.Tennants.AddRange(tennants);
                dataContext.SaveChanges();
            }
            #endregion

            #region Applications

            if (!dataContext.Applications.Any())
            {
                List<Application> apps = new List<Application>
                {
                    new Application
                    {
                        Id = Guid.NewGuid(),
                        Name = "Contract Management",
                        Description = "Used to Create, Approve, Send, and Execute Contracts."
                    },
                    new Application
                    {
                        Id = Guid.NewGuid(),
                        Name = "Vendor Management System",
                        Description = "Used to manage Vendor Employees, Timesheets, Assignments, and postings."
                    }
                };
                dataContext.Applications.AddRange(apps);
                dataContext.SaveChanges();
            }
            #endregion

            #region Users

            if (!dataContext.Users.Any())
            {
                //Hardcoding our admins for now.
                List<string[]> users = new List<string[]>
                {
                    new[] {"Super", "Admin", "super@admin.com"},
                    new[] {"Anjith", "Kalisetti", "anjith.kalisetti@hallmarkhcs.com"},
                    new[] {"Rajiv", "Bajaj", "rajiv.bajaj@hallmarkhcs.com"},
                    new[] {"Sreesakthi", "Prasanna", "sreesakthi.prasanna@hallmarkhcs.com"},

                    new[] {"Kaustub", "Katte", "kaustub.katte@hallmarkhcs.com"},
                    new[] {"Tirupathirao", "Dudekula", "tirupathirao.dudekula@hallmarkhcs.com"},
                    new[] {"Amit", "Rathore", "amit.rathore@hallmarkhcs.com"}
                };
                var r = dataContext.Roles.ToList();
                var o = dataContext.Organizations.ToList();
                var a = dataContext.Applications.ToList();

                foreach (var user in users)
                {
                    var sec = Guid.NewGuid();
                    dataContext.Users.Add(new User
                    {
                        FirstName = user[0],
                        LastName = user[1],
                        PhoneNumber = "111-111-1111",
                        Email = user[2],
                        Password = Crypto.GenerateHash("Password123", sec),
                        Roles = r,
                        Organizations = o,
                        SecurityStamp = sec,
                        PasswordExpiry = DateTime.UtcNow.AddYears(100),
                        Applications = a,
                        Active = true
                    });
                }
            }
            #endregion


            SetupFormStuff(dataContext, dataContext.Organizations.Include(x => x.Regions).ThenInclude(x => x.Locations).ThenInclude(x => x.CostCenters).FirstOrDefault(x => x.Name == "Trinidad Health"));

            Debug.WriteLine($"Seeding took: {sw.ElapsedMilliseconds}ms.");
          
            if (Debugger.IsAttached)
            {
              
                var s = dataContext.Forms
                    .Include(x => x.Locations)
                    .Include(x => x.Tags)
                    .Include(x => x.FormSections)
                        .ThenInclude(x => x.Fields)
                        .ThenInclude(x => x.Inputs)
                        .ThenInclude(x => x.InputType)
                    .AsSplitQuery().ToList();

                JsonSerializerOptions options = new JsonSerializerOptions()
                {
                    IgnoreNullValues = true,
                    WriteIndented = true
                };

                File.WriteAllText("C:\\Temp\\Test.json", JsonSerializer.Serialize(s, options));
            }

            
            return dataContext;
        }

        internal static void SetupFormStuff(DataContext dataContext, Organization organization)
        {

            using var transaction = dataContext.Database.BeginTransaction();

            dataContext.Tags.RemoveRange(dataContext.Tags.Include(x => x.Fields).Include(x => x.Forms));

            dataContext.Forms.RemoveRange(dataContext.Forms.Include(x => x.Locations).Include(x => x.Regions).Include(x => x.CostCenters).Include(x => x.Specialties).Include(x => x.Postions));

            dataContext.FormSections.RemoveRange(dataContext.FormSections);

            dataContext.Fields.RemoveRange(dataContext.Fields);

            dataContext.Inputs.RemoveRange(dataContext.Inputs);

            dataContext.InputsTypes.RemoveRange(dataContext.InputsTypes);

            dataContext.SaveChanges();

            dataContext.Tags.AddRange(
                new Tag
                {
                    Name = "New Form",
                    Type = TagTypeEnum.Form,
                    Active = true,
                    Organization = organization
                },
                new Tag
                {
                    Name = "New Field",
                    Type = TagTypeEnum.Field,
                    Active = true,
                    Organization = organization
                });

            dataContext.InputsTypes.AddRange(
                new InputType
                {
                    Name = "Textbox",
                    Description = "Short text/numeric responses",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Text)
                },
                new InputType
                {
                    Name = "TextArea",
                    Description = "Full lines of text",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Text)
                },
                new InputType
                {
                    Name = "Dropdown",
                    Description = "Pick a single response from selection of options",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Option)
                },
                new InputType
                {
                    Name = "MultiSelect Dropdown",
                    Description = "Pick multiple responses from selection of options",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Option)
                },
                new InputType
                {
                    Name = "Radio",
                    Description = "Pick a single response from selection of options",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Option)
                },
                new InputType
                {
                    Name = "Checkbox",
                    Description = "Pick multiple responses from selection of options",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Option)
                },
                new InputType
                {
                    Name = "DateTime Picker",
                    Description = "Respond with a date and time",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.DateTime)
                },
                new InputType
                {
                    Name = "Date Picker",
                    Description = "Respond with a date",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.DateTime)
                },
                new InputType
                {
                    Name = "Time Picker",
                    Description = "Respond with a time",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.DateTime)
                },
                new InputType
                {
                    Name = "Input Group",
                    Description = "Predefined groups of inputs that are related",
                    Classification = dataContext.InputTypeClassifications.Find(InputTypeClassificationEnum.Group)
                }
                );

            dataContext.SaveChanges();

            dataContext.Inputs.AddRange(
                new Input
                {
                    Name = "First Name",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = true,
                    MinLength = 2,
                    MaxLength = 128,
                    Organization = organization,
                    Slug = "firstName"
                }, new Input
                {
                    Name = "Last Name",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = true,
                    MinLength = 2,
                    MaxLength = 128,
                    Organization = organization,
                    Slug = "lastName",
                },
                new Input
                {
                    Name = "Address Line 1",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = true,
                    MinLength = 10,
                    MaxLength = 256,
                    Organization = organization,
                    PartOfInputGroup = true,
                    Slug = "addressLine1",
                    Row = 0,
                    RowWidth = 1,
                    Order = 0,
                    Size = 1
                },
                new Input
                {
                    Name = "Address Line 2",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = false,
                    MaxLength = 256,
                    Organization = organization,
                    PartOfInputGroup = true,
                    Slug = "addressLine2",
                    Row = 1,
                    RowWidth = 1,
                    Order = 0,
                    Size = 1
                },
                new Input
                {
                    Name = "City",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = true,
                    MinLength = 5,
                    MaxLength = 128,
                    Organization = organization,
                    PartOfInputGroup = true,
                    Slug = "city",
                    Row = 2,
                    RowWidth = 3,
                    Order = 0,
                    Size = 1
                },
                new Input
                {
                    Name = "State",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Dropdown"),
                    Active = true,
                    Required = true,
                    MinLength = 2,
                    MaxLength = 2,
                    OptionsList = "States",
                    Organization = organization,
                    PartOfInputGroup = true,
                    Slug = "state",
                    Row = 2,
                    RowWidth = 3,
                    Order = 1,
                    Size = 1
                },
                new Input
                {
                    Name = "Zip",
                    InputType = dataContext.InputsTypes.FirstOrDefault(x => x.Name == "Textbox"),
                    Active = true,
                    Required = true,
                    MinLength = 5,
                    MaxLength = 12,
                    Masking = "99999?-9999",
                    Organization = organization,
                    PartOfInputGroup = true,
                    Slug = "zip",
                    Row = 2,
                    RowWidth = 3,
                    Order = 2,
                    Size = 1
                });

          
            dataContext.SaveChanges();

            List<string> addressFields = new List<string> { "addressLine1", "addressLine2", "city", "state", "zip" };


            dataContext.Fields.AddRange(
                new Field
                {
                    Name = "First Name",
                    Inputs = dataContext.Inputs.Where(x => x.Name == "First Name").ToList(),
                    Description = "First Name of the person",
                    HelpText = "Please enter the First Name of the person.",
                    Organization = organization,
                    Tags = dataContext.Tags.Where(x => x.Name == "New Field").ToList(),
                    Active = true
                },
                new Field
                {
                    Name = "Last Name",
                    Inputs = dataContext.Inputs.Where(x => x.Name == "Last Name").ToList(),
                    Description = "Last Name of the person",
                    HelpText = "Please enter the Last Name of the person.",
                    Organization = organization,
                    Tags = dataContext.Tags.Where(x => x.Name == "New Field").ToList(),
                    Active = true
                },
                new Field
                {
                    Name = "Address",
                    Inputs = dataContext.Inputs.Where(x => addressFields.Contains(x.Slug)).ToList(),
                    Description = "The address of the provider.",
                    HelpText = "Please enter the Address of the person.",
                    Organization = organization,
                    Tags = dataContext.Tags.Where(x => x.Name == "New Field").ToList(),
                    Active = true,
                    IsInputGroup =  true
                });

            dataContext.SaveChanges();

            dataContext.FormSections.Add(new FormSection
            {
                Name = "User Information",
                Active = true,
                Fields = dataContext.Fields.ToList(),
                Organization = organization
            });

            dataContext.SaveChanges();

            dataContext.Forms.AddRange(new Form
            {
                Name = "Neurology",
                Description = "For the hiring of a very smart neurologist.",
                FormSections = dataContext.FormSections.Where(x => x.Name == "User Information").ToList(),
                Organization = organization,
                Regions = organization.Regions.ToList(),
                Locations =  organization.Regions.SelectMany(x => x.Locations).ToList(),
                CostCenters = organization.Regions.SelectMany(x => x.Locations).SelectMany(x => x.CostCenters).ToList(),
                Tags = dataContext.Tags.Where(x => x.Name == "New Form").ToList(),
                Active = true
            });

            dataContext.SaveChanges();

            transaction.Commit();
        }

        internal static void SetupLookupTable<T1, T2>(DbSet<T2> dbc)
            where T1 : Enum
            where T2 : class, ILookupTable<T1>, new()
        {
            var values = Enum.GetValues(typeof(T1))
                .OfType<T1>()
                .Select(x => new T2
                {
                    Id = x,
                    Name = x.ToString()
                })
                .ToArray();

            var allItems = dbc.ToList();

            foreach (var i in values)
            {
                if (allItems.All(x => !Equals(x.Id, i.Id)))
                {
                    dbc.Add(i);
                }
            }
        }

        public static void SetupFunctions(this DataContext dataContext)
        {

            if (!dataContext.Modules.Any())
            {
                SetupLookupTable<ModuleEnum, Module>(dataContext.Modules);
                dataContext.SaveChanges();
            }

            if (!dataContext.FunctionCategories.Any())
            {
                SetupLookupTable<CategoryEnum, FunctionCategory>(dataContext.FunctionCategories);
                dataContext.SaveChanges();
            }

            List<Function> allFunctions = Functions.AllFunctions;

            var groupedById = allFunctions.GroupBy(x => x.Id).Where(x => x.Count() > 1).ToArray();
            if (groupedById.Any())
            {
                string ids = string.Join(',', groupedById.Select(x => x.Key));
                throw new InvalidOperationException(
                    $"Tried to create a duplicate function (same Id): {ids}");
            }

            var groupedByName = allFunctions.GroupBy(x => new {x.ModuleId, x.CategoryId, x.Action}).Where(x => x.Count() > 1).ToArray();
            if (groupedByName.Any())
            {
                string names = string.Join(',', groupedByName.Select(x => x.Key));
                throw new InvalidOperationException(
                    $"Tried to create a duplicate function (same Name): {names}");
            }

            var allModules = dataContext.Modules.ToList();
            var allCategories = dataContext.FunctionCategories.ToList();

            foreach (var function in allFunctions)
            {
                var m = allModules.FirstOrDefault(x => x.Id == function.ModuleId);
                var c = allCategories.FirstOrDefault(x => x.Id == function.CategoryId);

                if (m == null || c == null || string.IsNullOrEmpty(function.Action))
                {
                    throw new InvalidOperationException("Could not validate function name to add.");
                }

                var tryFind = dataContext.Functions.Find(function.Id);

                if (tryFind == null)
                {
                    dataContext.Functions.Add(function);
                }
            }
        }
    }
}
