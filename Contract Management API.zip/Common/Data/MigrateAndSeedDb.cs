using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Common.Data
{
    public static class MigrateAndSeedDb
    {
        public static void MigrateAndSeed(this IApplicationBuilder app)
        {
            using var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
            using var context = serviceScope.ServiceProvider.GetService<DataContext>();
            if (context != null)
            {
                context.AddOrUpdateSeedData();
                context.SaveChanges();
            }
        }

        public static void SetupAllFunctions(this IApplicationBuilder app)
        {
            using var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
            using var context = serviceScope.ServiceProvider.GetService<DataContext>();
            if (context != null)
            {
                context.SetupFunctions();
                context.SaveChanges();
            }
        }
    }
}
