using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface ISpecialtyService
    {
        IQueryable<Specialty> GetSpecialties();
        Task<Specialty> GetSpecialty(Guid id);
    }
}
