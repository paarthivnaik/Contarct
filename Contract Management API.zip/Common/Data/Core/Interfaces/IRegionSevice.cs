using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface IRegionSevice
    {
        IQueryable<Region> GetRegions(bool includeChildren = false);
        Task<Region> GetRegion(Guid id);
    }
}
