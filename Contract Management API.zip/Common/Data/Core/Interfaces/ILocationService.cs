using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface ILocationService
    {
        IQueryable<Location> GetLocations();
        Task<Location> GetLocation(Guid id);
    }
}
