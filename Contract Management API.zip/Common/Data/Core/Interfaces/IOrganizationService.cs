using System;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface IOrganizationService
    {
        Task<Organization> GetCurrentOrganization(bool includeAllChildren = false);
        Task<Organization> GetOrganization(Guid id, bool includeAllChildren = false);
    }
}
