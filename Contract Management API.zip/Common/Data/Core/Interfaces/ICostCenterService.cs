using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface ICostCenterService
    {
        IQueryable<CostCenter> GetCostCenters();
        Task<CostCenter> GetCostCenter(Guid id);
    }
}
