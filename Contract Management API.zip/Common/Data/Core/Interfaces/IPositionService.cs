using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities;

namespace Common.Data.Core.Interfaces
{
    public interface IPositionService
    {
        IQueryable<Position> GetPositions();
        Task<Position> GetPosition(Guid id);
    }
}
