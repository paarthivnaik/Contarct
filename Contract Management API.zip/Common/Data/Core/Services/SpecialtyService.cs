using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Data.Core.Services
{
    class SpecialtyService : ISpecialtyService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public SpecialtyService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<Specialty> GetSpecialties()
        {

            return _db.Specialties
                .Where(x => x.OrganizationId == _user.OrganizationId && x.Active).OrderBy(x => x.Name);
        }

        public Task<Specialty> GetSpecialty(Guid id)
        {
            return _db.Specialties.FirstOrDefaultAsync(x => x.OrganizationId == _user.OrganizationId && x.Id == id && x.Active);
        }

    }
}
