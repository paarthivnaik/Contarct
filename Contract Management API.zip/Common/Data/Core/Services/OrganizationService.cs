using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Data.Core.Services
{
    public class OrganizationService : IOrganizationService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public OrganizationService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public Task<Organization> GetCurrentOrganization(bool includeAllChildren = false)
        {
            return GetOrganizationInternal(_user.OrganizationId, includeAllChildren);
        }

        public Task<Organization> GetOrganization(Guid id, bool includeAllChildren = false)
        {
            return GetOrganizationInternal(id, includeAllChildren);
        }

        private Task<Organization> GetOrganizationInternal(Guid id, bool includeAllChildren = false)
        {
            return includeAllChildren ?
                _db.Organizations
                    .AsSplitQuery()
                    .Include(x => x.Regions.Where(y => y.Active))
                    .ThenInclude(x => x.Locations.Where(y => y.Active))
                    .ThenInclude(x => x.CostCenters.Where(y => y.Active))
                    .FirstOrDefaultAsync(x => x.Id == id && x.Active)
                : _db.Organizations.FirstOrDefaultAsync(x => x.Id == id && x.Active);
        }
    }
}
