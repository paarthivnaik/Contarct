using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Data.Core.Services
{
    class PositionService : IPositionService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public PositionService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<Position> GetPositions()
        {
            return _db.Positions
                .Where(x => x.Active && x.OrganizationId == _user.OrganizationId).OrderBy(x => x.Name);
        }

        public Task<Position> GetPosition(Guid id)
        {
            return _db.Positions
                .FirstOrDefaultAsync(x => x.Active && x.OrganizationId == _user.OrganizationId && x.Id == id);
        }
    }
}
