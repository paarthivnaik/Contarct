using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Data.Core.Services
{
    class LocationService: ILocationService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public LocationService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<Location> GetLocations()
        {
            return _db.Locations
                .AsSplitQuery()
                .Where(x =>
                    x.Active
                    && x.Region.Active
                    && x.Region.OrganizationId == _user.OrganizationId).OrderBy(x => x.Name);
        }

        public Task<Location> GetLocation(Guid id)
        {
            return _db.Locations
                .AsSplitQuery()
                .FirstOrDefaultAsync(x =>
                    x.Active
                    && x.Region.Active
                    && x.Region.OrganizationId == _user.OrganizationId
                    && x.Id == id);
        }
    }
}
