using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Common.Data.Core.Services
{
    class RegionSevice : IRegionSevice
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public RegionSevice(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<Region> GetRegions(bool includeChildren = false)
        {
            if (includeChildren)
            {
                return _db.Regions
                    .Include(x => x.Locations)
                        .ThenInclude(x => x.CostCenters)
                    .AsSplitQuery()
                    .Where(x =>
                        x.Active
                        && x.OrganizationId == _user.OrganizationId).OrderBy(x => x.Name);
            }
            else
            {
                return _db.Regions
                    .AsSplitQuery()
                    .Where(x =>
                        x.Active
                        && x.OrganizationId == _user.OrganizationId).OrderBy(x => x.Name);
            }

        }

        public Task<Region> GetRegion(Guid id)
        {
            return _db.Regions
                .AsSplitQuery()
                .FirstOrDefaultAsync(x =>
                    x.Active
                    && x.OrganizationId == _user.OrganizationId
                    && x.Id == id);
        }
    }
}
