using System;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PositionController : ControllerBase
    {
        private readonly IPositionService _ps;

        public PositionController(IPositionService ps)
        {
            _ps = ps;
        }

        // GET: api/<CostCenterController>
        [HttpGet]
        public Task<PagedResult<Position>> Get(int page, int pageSize)
        {
            return _ps.GetPositions().ToPagedAsync(page, pageSize);
        }

        // GET api/<CostCenterController>/5
        [HttpGet("{id}")]
        public Task<Position> Get(string id)
        {
            return _ps.GetPosition(Guid.Parse(id));
        }
    }
}
