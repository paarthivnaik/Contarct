using System;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegionController : ControllerBase
    {
        private readonly IRegionSevice _rs;

        public RegionController(IRegionSevice rs)
        {
            _rs = rs;
        }

        // GET: api/<CostCenterController>
        [HttpGet]
        public Task<PagedResult<Region>> Get(int page, int pageSize, bool includeChildren)
        {
            return _rs.GetRegions(includeChildren).ToPagedAsync(page, pageSize);
        }

        // GET api/<CostCenterController>/5
        [HttpGet("{id}")]
        public Task<Region> Get(string id)
        {
            return _rs.GetRegion(Guid.Parse(id));
        }

        //// POST api/<RegionController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<RegionController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<RegionController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
