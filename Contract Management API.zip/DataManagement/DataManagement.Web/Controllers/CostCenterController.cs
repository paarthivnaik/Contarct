using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CostCenterController : ControllerBase
    {
        private readonly ICostCenterService _ccs;

        public CostCenterController(ICostCenterService ccs)
        {
            _ccs = ccs;
        }

        // GET: api/<CostCenterController>
        [HttpGet]
        public Task<PagedResult<CostCenter>> Get(int page, int pageSize)
        {
            return _ccs.GetCostCenters().ToPagedAsync(page, pageSize);
        }

        // GET api/<CostCenterController>/5
        [HttpGet("{id}")]
        public Task<CostCenter> Get(string id)
        {
            return _ccs.GetCostCenter(Guid.Parse(id));
        }

        //// POST api/<CostCenterController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<CostCenterController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<CostCenterController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
