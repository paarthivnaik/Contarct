using System;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpecialtyController : ControllerBase
    {
        private readonly ISpecialtyService _ss;

        public SpecialtyController(ISpecialtyService ss)
        {
            _ss = ss;
        }

        // GET: api/<CostCenterController>
        [HttpGet]
        public Task<PagedResult<Specialty>> Get(int page, int pageSize)
        {
            return _ss.GetSpecialties().ToPagedAsync(page, pageSize);
        }

        // GET api/<CostCenterController>/5
        [HttpGet("{id}")]
        public Task<Specialty> Get(string id)
        {
            return _ss.GetSpecialty(Guid.Parse(id));
        }

        //// POST api/<SpecialtyController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<SpecialtyController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<SpecialtyController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
