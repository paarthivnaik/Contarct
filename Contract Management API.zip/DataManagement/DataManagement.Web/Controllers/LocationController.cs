using System;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly ILocationService _lcs;

        public LocationController(ILocationService lcs)
        {
            _lcs = lcs;
        }

        // GET: api/<CostCenterController>
        [HttpGet]
        public Task<PagedResult<Location>> Get(int page, int pageSize)
        {
            return _lcs.GetLocations().ToPagedAsync(page, pageSize);
        }

        // GET api/<CostCenterController>/5
        [HttpGet("{id}")]
        public Task<Location> Get(string id)
        {
            return _lcs.GetLocation(Guid.Parse(id));
        }

        //// POST api/<LocationController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<LocationController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<LocationController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
