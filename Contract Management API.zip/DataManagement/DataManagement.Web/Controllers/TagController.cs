using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Common.Core.Interfaces;
using Common.Data.Entities;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TagController : ControllerBase
    {
        private readonly ITagService _ts;

        public TagController(ITagService ts)
        {
            _ts = ts;
        }

        // GET: api/<TagController>
        [HttpGet]
        public IEnumerable<Tag> Get(string search, TagTypeEnum type)
        {
            return _ts.GetTags(search, type);
        }

        // GET api/<TagController>/5
        [HttpGet("{id}")]
        public Task<Tag> Get(string id)
        {
            return _ts.GetTag(Guid.Parse(id));
        }

        // POST api/<TagController>
        [HttpPost]
        public Task<Tag> Post(Tag tag)
        {
            return _ts.AddOrUpdateTag(tag);
        }

        // PUT api/<TagController>/5
        [HttpPut]
        public Task<Tag> Put(Tag tag)
        {
            return _ts.AddOrUpdateTag(tag);
        }

        //// DELETE api/<TagController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
