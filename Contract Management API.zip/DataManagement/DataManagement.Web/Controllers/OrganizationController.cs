using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController : ControllerBase
    {
        private readonly IOrganizationService _cs;

        public OrganizationController(IOrganizationService cs)
        {
            _cs = cs;
        }

        // GET api/<CostCenterController>/5
        //[HttpGet("{id}")]
        //public Task<Organization> Get(string id)
        //{
        //    return _cs.GetOrganization(Guid.Parse(id));
        //}

        [HttpGet]
        public Task<Organization> Get()
        {
            return _cs.GetCurrentOrganization();
        }

        //// POST api/<OrganizationController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<OrganizationController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<OrganizationController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
