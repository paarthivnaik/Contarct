using System;
using System.Threading.Tasks;
using Common;
using Common.Data.Core.Interfaces;
using Common.Data.Entities;
using Common.Models;
using Microsoft.AspNetCore.Mvc;

namespace DataManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupedDataController : ControllerBase
    {
        //private readonly IGroupDataHandler _gd;

        //public GroupedDataController(IGroupDataHandler gd)
        //{
        //    _gd = gd;
        //}

        //// GET: api/<CostCenterController>
        //[HttpGet]
        //public Task<PagedResult<CostCenter>> Get(int page, int pageSize)
        //{
        //    return _ccs.GetCostCenters().ToPagedAsync(page, pageSize);
        //}

        //// GET api/<CostCenterController>/5
        //[HttpGet("{id}")]
        //public Task<CostCenter> Get(string id)
        //{
        //    return _ccs.GetCostCenter(Guid.Parse(id));
        //}

    }
}
