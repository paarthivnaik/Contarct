using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Common.Data;
using Microsoft.EntityFrameworkCore;
using static Common.Startup;

namespace DataManagement.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {


            var apiInfo = new OpenApiInfo
            {
                Title = "Data Management",
                Description = "This endpoint handles managing general data accross the system."
            };
            var nameSpace = typeof(Startup).Namespace;
            services.AddDbContext<DataContext>(options => {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultDatabase"), x => x.MigrationsAssembly(nameSpace));
                options.EnableSensitiveDataLogging();
            });

            ConfigureCommonServices(services, Configuration, apiInfo);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigureApplicaiton(app, env, "Data Management");
        }
    }
}
