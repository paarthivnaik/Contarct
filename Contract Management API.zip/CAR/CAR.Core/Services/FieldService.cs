using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data;
using Common.Data.Entities.CAR;
using Common.Models;
using Common.StaticData.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CAR.Core.Services
{
    public class FieldService : IFieldService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public FieldService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<Field> GetFields(bool inputGroups)
        {
            return _db.Fields.Where(x => x.Active && x.OrganizationId == _user.OrganizationId && x.Active && x.IsInputGroup == inputGroups).OrderBy(x => x.IsInputGroup);
        }

        public IQueryable<Field> GetFieldsOfType(InputTypeClassificationEnum type)
        {
            return _db.Fields.Include(x => x.Inputs).Where(x =>
                x.Active
                && x.OrganizationId == _user.OrganizationId
                && !x.IsInputGroup
                && x.Inputs.Count == 1
                && x.Inputs.First().InputType.Classification.Id != InputTypeClassificationEnum.Group);
        }

        public IQueryable<Field> GetInputGroupFields()
        {
            return _db.Fields.Where(x => x.Active && x.OrganizationId == _user.OrganizationId && x.Active && x.IsInputGroup);
        }

        public Task<Field> GetField(Guid id)
        {
            return _db.Fields.Include(x => x.Inputs).FirstOrDefaultAsync(x => x.Active && x.OrganizationId == _user.OrganizationId && x.Id == id);
        }

        public Field CopyField(Field field, int row)
        {
            var fieldResult = new Field
            {
                Name = field.Name,
                Description = field.Description,
                HelpText = field.HelpText,
                OrganizationId = _user.OrganizationId,
                Inputs = new List<Input>(),
                Active = field.Active,
                Row = row
            };

            if (fieldResult.IsInputGroup)
            {
                fieldResult.RowsUsed = field.RowsUsed;
                fieldResult.RowWidth = field.RowWidth;
            }
            else
            {
                fieldResult.RowsUsed = 1;
                fieldResult.RowWidth = 1;
            }

            return fieldResult;
        }
    }
}
