using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data;
using Common.Data.Entities.CAR;
using Common.Models;
using Common.StaticData.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CAR.Core.Services
{
    public class InputService : IInputService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public InputService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _db = db;
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
        }

        public ValueTask<Input> GetInput(Guid id)
        {
            return _db.Inputs.FindAsync(id);
        }

        public IQueryable<InputType> GetInputTypes()
        {
            return _db.InputsTypes.Where(x => x.Classification.Id != InputTypeClassificationEnum.Group);
        }

        public Task<InputType> GetInputType(int id)
        {
            return _db.InputsTypes.FirstOrDefaultAsync(x => x.Id == id);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="existingSlugs">To keep track of not yet saved slugs that are going to be added with this form.</param>
        /// <returns></returns>
        public string GenerateSlug(string name, ref List<string> existingSlugs)
        {
            var slugifiedName = name.ToSlug();
            var matchingInputs = _db.Inputs.Where(s => s.OrganizationId == _user.OrganizationId && s.Slug.StartsWith(slugifiedName)).Select(x => x.Slug);

            var max = 0;
            if (matchingInputs.Any())
            {
                foreach (var matchingInput in matchingInputs)
                {
                    var last = 0;
                    if (matchingInput.Contains("_"))
                    {
                        last = int.Parse(matchingInput.Split("_").Last());
                    }

                    if (last > max)
                    {
                        max = last;
                    }
                }
            }

            if (existingSlugs.Any(x => x == $"{slugifiedName}_{max}"))
            {
                max++;
            }

            var result = $"{slugifiedName}_{max}";
            existingSlugs.Add(result);


            return result;
        }

        public async Task<Input> CopyInput(Input sourceInput)
        {
            var newInput = new Input
            {
                Name = sourceInput.Name,
                InputType = await GetInputType(sourceInput.InputTypeId),
                Required = sourceInput.Required,
                DisplayFormat = sourceInput.DisplayFormat,
                OrganizationId = _user.OrganizationId,
                PartOfInputGroup = false,
                Active = true,
                Row = sourceInput.Row,
                RowWidth = sourceInput.RowWidth,
                Order = sourceInput.Order,
                Size = sourceInput.Size
            };

            switch (sourceInput.InputType.Classification.Id)
            {
                case InputTypeClassificationEnum.Text:
                    newInput.Masking = sourceInput.Masking;
                    newInput.MinLength = sourceInput.MinLength;
                    newInput.MaxLength = sourceInput.MaxLength;
                    newInput.DefaultValueString = sourceInput.DefaultValueString;
                    break;
                case InputTypeClassificationEnum.Number:
                    newInput.Masking = sourceInput.Masking;
                    newInput.MinValue = sourceInput.MinValue;
                    newInput.MaxValue = sourceInput.MaxValue;
                    newInput.DefaultValueNumber = sourceInput.DefaultValueNumber;
                    break;
                case InputTypeClassificationEnum.DateTime:
                    newInput.MinDate = sourceInput.MinDate;
                    newInput.MaxDate = sourceInput.MaxDate;
                    newInput.DefaultDate = sourceInput.DefaultDate;

                    newInput.MinTime = sourceInput.MinTime;
                    newInput.MaxTime = sourceInput.MaxTime;
                    newInput.DefaultValueTime = sourceInput.DefaultValueTime;
                    break;
                case InputTypeClassificationEnum.Option:
                    newInput.Options = sourceInput.Options;
                    newInput.OptionsList = sourceInput.OptionsList;
                    newInput.OptionsListSp = sourceInput.OptionsListSp;
                    newInput.OptionsListQuery = sourceInput.OptionsListQuery;
                    newInput.DefaultValueOption = sourceInput.DefaultValueOption;
                    newInput.MinSelection = sourceInput.MinSelection;
                    newInput.MaxSelection = sourceInput.MaxSelection;
                    break;
                case InputTypeClassificationEnum.Group:
                    break;
            }

            return newInput;
        }
    }
}
