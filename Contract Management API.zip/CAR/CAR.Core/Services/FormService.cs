using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data;
using Common.Data.Entities.CAR;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CAR.Core.Services
{
    public class FormService : IFormService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public FormService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _db = db;
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
        }

        public Task<Form> GetForm(Guid formId)
        {
            return _db.Forms
                .Include(x => x.Regions)
                .Include(x => x.Locations)
                .Include(x => x.CostCenters)
                .Include(x => x.Specialties)
                .Include(x => x.Postions)
                .Include(x => x.FormSections)
                    .ThenInclude(x => x.Fields)
                    .ThenInclude(x => x.Inputs)
                    .ThenInclude(x => x.InputType)
                    .ThenInclude(x => x.Classification)
                .AsSplitQuery()
                .FirstOrDefaultAsync(x =>
                x.Id == formId && x.OrganizationId == _user.OrganizationId && x.Active);
        }

        public IQueryable<Form> GetForms()
        {
            return _db.Forms.Where(x => x.OrganizationId == _user.OrganizationId && x.Active).OrderBy(x => x.Name);
        }

        public async Task<Form> SaveForm(Form form)
        {
            var item = await _db.Forms.FindAsync(form.Id);

            if (item == null)
            {
                await _db.Forms.AddAsync(form);
            }
            else
            {
                _db.Forms.Update(form);
            }

            await _db.SaveChangesAsync();
            return form;
        }

        public async Task<bool> DeleteForm(Guid id)
        {
            var form = await GetForm(id);

            foreach (var formFormSection in form.FormSections)
            {
                formFormSection.Active = false;

                foreach (var field in formFormSection.Fields)
                {
                    field.Active = false;

                    foreach (var input in field.Inputs)
                    {
                        input.Active = false;
                    }
                }
            }
            form.Active = false;
            _db.Forms.Update(form);

            await _db.SaveChangesAsync();

            return true;
        }

        public bool ValidateForm(Form form, bool throwExceptions = true)
        {
            List<string> validationErrors = new List<string>();

            if (string.IsNullOrEmpty(form.Name))
            {
                validationErrors.Add("No Name specified for form.");
            }

            if (form.Regions == null || form.Regions.Count == 0)
            {
                validationErrors.Add("No Regions specified for form.");
            }

            if (form.Locations == null || form.Locations.Count == 0)
            {
                validationErrors.Add("No Locations specified for form.");
            }

            if (form.Specialties == null || form.Specialties.Count == 0)
            {
                validationErrors.Add("No Specialties specified for form.");
            }

            if (form.Postions == null || form.Postions.Count == 0)
            {
                validationErrors.Add("No Postions specified for form.");
            }

            if (throwExceptions && validationErrors.Count > 0)
            {
                throw new ValidationException(string.Join(Environment.NewLine, validationErrors));
            }

            return validationErrors.Count == 0;
        }

        public async Task<IEnumerable<Form>> GetFormsBasedOnCritera(Guid regionId, Guid locationId, Guid? costCenterId, Guid specialtyId, Guid postionId)
        {
            return await _db.Forms
                .Where(x => x.Regions.Any(s => s.Id == regionId) ||
                            x.Locations.Any(s => s.Id == locationId) ||
                            x.Specialties.Any(s => s.Id == specialtyId) ||
                            x.Postions.Any(s => s.Id == postionId) ||
                            (costCenterId != null ? x.CostCenters.Any(s => s.Id == costCenterId) : true)
                       ).ToListAsync();
        }
    }
}
