using System;
using System.Linq;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data;
using Common.Data.Entities.CAR;
using Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CAR.Core.Services
{
    public class FormSectionService : IFormSectionService
    {
        private readonly DataContext _db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUser _user;

        public FormSectionService(DataContext db, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
            _db = db;
        }

        public IQueryable<FormSection> GetFormSections()
        {
            return _db.FormSections.Where(f => f.OrganizationId == _user.OrganizationId && f.Active);
        }

        public Task<FormSection> GetFormSection(Guid sectionId)
        {
            return _db.FormSections.FirstOrDefaultAsync(x => x.Id == sectionId && x.Active);
        }
    }
}
