using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.CAR;

namespace CAR.Core.Interfaces
{
    public interface IFormSectionService
    {
        IQueryable<FormSection> GetFormSections();
        Task<FormSection> GetFormSection(Guid sectionId);
    } 
}
