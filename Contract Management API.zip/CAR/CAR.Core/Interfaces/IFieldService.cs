using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.CAR;

namespace CAR.Core.Interfaces
{
    public interface IFieldService
    {
        IQueryable<Field> GetFields(bool inputGroups);
        Task<Field> GetField(Guid id);
        Field CopyField(Field field, int row);
    }
}
