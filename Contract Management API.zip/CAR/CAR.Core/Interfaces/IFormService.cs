using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.CAR;
namespace CAR.Core.Interfaces
{
    public interface IFormService
    {
        Task<Form> GetForm(Guid formId);
        IQueryable<Form> GetForms();
        Task<Form> SaveForm(Form form);
        Task<bool> DeleteForm(Guid id);
        bool ValidateForm(Form form, bool throwExceptions = true);
        Task<IEnumerable<Form>> GetFormsBasedOnCritera(Guid regionId, Guid locationId, Guid? costCenterId, Guid specialtyId, Guid postionId );
    }
}
