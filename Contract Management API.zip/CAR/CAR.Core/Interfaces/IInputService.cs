using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.CAR;

namespace CAR.Core.Interfaces
{
    public interface IInputService
    {
        ValueTask<Input> GetInput(Guid id);
        IQueryable<InputType> GetInputTypes();
        Task<Input> CopyInput(Input sourceInput);
        string GenerateSlug(string name, ref List<string> existingSlugs);
    }
}
