using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.CAR;

namespace CAR.Core.Interfaces
{
    public interface IFormHandler
    {
        IQueryable<Form>GetForms();
        Task<Form> GetForm(Guid formId);
        Task<Form> CreateForm(Form form);
        Task<Form> UpdateForm(Form form);
        Task<bool> DeleteForm(Guid id);
    }
}
