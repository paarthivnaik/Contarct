using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Core.Interfaces;
using Common.Data;
using Common.Data.Core.Interfaces;
using Common.Data.Entities.CAR;
using Common.Models;
using Microsoft.AspNetCore.Http;

namespace CAR.Core.Handlers
{
    public class FormHandler : IFormHandler
    {
        private readonly IFormService _fos;
        private readonly ITagService _ts;
        private readonly IFieldService _fes;
        private readonly IInputService _ips;
        private readonly IFormSectionService _fss;
        private readonly IOrganizationService _os;
        private readonly ISpecialtyService _ss;
        private readonly IPositionService _ps;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly DataContext _db;

        private readonly ApplicationUser _user;

        public FormHandler(DataContext db,
            IFormService fos, ITagService ts, IFieldService fes, IInputService ips, IFormSectionService fss,
            IOrganizationService os, ISpecialtyService ss, IPositionService ps,
            IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _db = db;
            _fos = fos;
            _ts = ts;
            _fes = fes;
            _ips = ips;
            _fss = fss;
            _os = os;
            _ss = ss;
            _ps = ps;
            _user = _httpContextAccessor.HttpContext.GetUser().Result;
        }

        public Task<Form> GetForm(Guid formId)
        {
            return _fos.GetForm(formId);
        }

        public IQueryable<Form> GetForms()
        {
            return _fos.GetForms();
        }

        public async Task<Form> CreateForm(Form form)
        {

            _fos.ValidateForm(form);

            await using var transaction = await _db.Database.BeginTransactionAsync();

            //While it would be very easy to just save the form as is sent from the user, we cannot trust the user's input that much,
            //We still need to validate each input, field, section and the form itself before consider saving
            //A good way to have full control over the object that is saved is to rebuild it from scratch, if we want to save something new.
            //We SHOULD probably have a seperate model for this, but eh.
            Form formSave = new Form
            {
                Name = form.Name,
                Active = form.Active,
                Description = form.Description,
                OrganizationId = _user.OrganizationId,
                Tags = (await _ts.AddOrUpdateTags(form.Tags)).ToList(),
                FormSections = await SetSections(form)
            };

            formSave = await SetAssignments(form, formSave);

            await _fos.SaveForm(formSave);

            await transaction.CommitAsync();

            return formSave;

        }

        public async Task<Form> UpdateForm(Form form)
        {
            _fos.ValidateForm(form);

            await using var transaction = await _db.Database.BeginTransactionAsync();
            
            var formFromDb = await _fos.GetForm(form.Id);

            if (formFromDb == null)
            {
                throw new NullReferenceException("Could not find matching form");
            }

            formFromDb.Name = form.Name;
            formFromDb.Description = form.Description;
            formFromDb.Tags = (await _ts.AddOrUpdateTags(form.Tags)).ToList();

            formFromDb = await SetAssignments(form, formFromDb);

            formFromDb.FormSections = await SetSections(form);

            await _fos.SaveForm(formFromDb);

            await transaction.CommitAsync();

            return formFromDb;

        }

        private async Task<List<FormSection>> SetSections(Form form)
        {
            List<FormSection> saveableSections = new List<FormSection>();
            foreach (var sec in form.FormSections)
            {
                FormSection section;
                if (sec.Id != Guid.Empty)
                {
                    section = await _fss.GetFormSection(sec.Id);
                }
                else
                {
                    section = new FormSection
                    {
                        Name = sec.Name,
                        Active = sec.Active,
                    };
                }

                section.Fields = new List<Field>();

                #region Fields

                var fieldRow = 0;
                List<string> generatedSlugs = new List<string>();

                await SetFields(sec, section, fieldRow, generatedSlugs);

                #endregion

                saveableSections.Add(section);
            }

            return saveableSections;
        }

        private async Task SetFields(FormSection incoming, FormSection resultant, int fieldRow, List<string> generatedSlugs)
        {
            foreach (var field in incoming.Fields)
            {
                Field fieldForSave;

                if (field.Id != Guid.Empty)
                {
                    fieldForSave = await _fes.GetField(field.Id);
                }

                fieldForSave = _fes.CopyField(field, fieldRow++);

                await SetSections(field, fieldForSave, generatedSlugs);

                resultant.Fields.Add(fieldForSave);
            }
        }

        private async Task SetSections(Field field, Field fieldForSave, List<string> generatedSlugs)
        {
            foreach (var inputFromReq in field.Inputs)
            {
                Input inputToSave;
                if (inputFromReq.Id != Guid.Empty)
                {
                    inputToSave = await _ips.GetInput(inputFromReq.Id);
                }

                inputToSave = await _ips.CopyInput(inputFromReq);

                var slug = _ips.GenerateSlug(inputFromReq.Name, ref generatedSlugs);
                inputToSave.Slug = slug;

                fieldForSave.Inputs.Add(inputToSave);
            }
        }

        private async Task<Form> SetAssignments(Form form, Form formSave)
        {
            var thisOrgInfo = await _os.GetCurrentOrganization(true);
            var availableRegions = thisOrgInfo.Regions.ToList();
            var availableLocations = thisOrgInfo.Regions.SelectMany(x => x.Locations).ToList();
            var availableCostCenters = thisOrgInfo.Regions.SelectMany(x => x.Locations.SelectMany(u => u.CostCenters)).ToList();

            formSave.OrganizationId = thisOrgInfo.Id;
            
            formSave.Regions = availableRegions.Where(x => form.Regions.Any(y => y.Id == x.Id)).ToList();
            formSave.Locations = availableLocations.Where(x => form.Locations.Any(y => y.Id == x.Id)).ToList();
            formSave.CostCenters = availableCostCenters.Where(x => form.CostCenters.Any(y => y.Id == x.Id)).ToList();

            var thisOrgSpecialties = _ss.GetSpecialties();
            var availableSpecialties = thisOrgSpecialties.ToList();
            var availablePositions = _ps.GetPositions().ToList();

            formSave.Specialties = availableSpecialties.Where(x => form.Specialties.Any(y => y.Id == x.Id)).ToList();
            formSave.Postions = availablePositions.Where(x => form.Postions.Any(y => y.Id == x.Id)).ToList();

            return formSave;
        }

        public async Task<bool> DeleteForm(Guid id)
        {
            return await _fos.DeleteForm(id);
        }
    }
}
