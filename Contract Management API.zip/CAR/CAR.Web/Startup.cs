using CAR.Core.Handlers;
using CAR.Core.Interfaces;
using CAR.Core.Services;    
using Common.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using static Common.Startup;

namespace CAR.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var apiInfo = new OpenApiInfo
            {
                Title = "Contract Action Request",
                Description = "This endpoint handles CAR template creation and management."
            };
            var nameSpace = typeof(Startup).Namespace;
            services.AddDbContext<DataContext>(options => {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultDatabase"), x => x.MigrationsAssembly(nameSpace));
                options.EnableSensitiveDataLogging();
            });
            ConfigureCommonServices(services, Configuration, apiInfo);


            services.AddScoped<IFieldService, FieldService>();
            services.AddScoped<IFormSectionService, FormSectionService>();
            services.AddScoped<IFormService, FormService>();
            services.AddScoped<IInputService, InputService>();
            services.AddScoped<IFormHandler, FormHandler>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigureApplicaiton(app, env, "CAR");
        }
    }
}
