using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data.Entities.CAR;
using Common.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CAR.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FieldController : ControllerBase
    {
        private readonly IFieldService _fs;

        public FieldController(IFieldService fs)
        {
            _fs = fs;
        }

        // GET: api/<FieldController>
        [HttpGet]
        public Task<PagedResult<Field>> Get(int page, int pageSize, bool inputGroups = false)
        {
            return _fs.GetFields(inputGroups).ToPagedAsync(page, pageSize);
        }

        //// GET api/<FieldController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/<FieldController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<FieldController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<FieldController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
