using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using CAR.Core.Interfaces;
using Common;
using Common.Data.Entities.CAR;
using Common.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;

namespace CAR.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FormController : ControllerBase
    {
        private readonly IFormHandler _fh;
        private readonly IFormService _fs;

        public FormController(IFormHandler fh, IFormService fs)
        {
            _fh = fh;
            _fs = fs;
        }

        [HttpGet]
        public Task<PagedResult<Form>> Get(int page, int pageSize)
        {
            return _fh.GetForms().ToPagedAsync(page, pageSize);
        }

        [HttpGet("get-form-templates")]
        public async Task<IEnumerable<Form>> GetFormTemplates(Guid regionId, Guid locationId, Guid? costCenterId, Guid specialtyId, Guid postionId)
        {
            return await _fs.GetFormsBasedOnCritera(regionId, locationId, costCenterId, specialtyId, postionId);
        }

        [HttpGet("{id}")]
        public Task<Form> Get(string id)
        {
            return _fh.GetForm(Guid.Parse(id));
        }

        [HttpPost("create")]
        public Task<Form> Create(Form form)
        {
            return _fh.CreateForm(form);
        }

        [HttpPut("update")]
        public Task<Form> Update(Form form)
        {
            return _fh.UpdateForm(form);
        }

        [HttpDelete("{id}")]
        public Task<bool> Delete(string id)
        {
            return _fh.DeleteForm(Guid.Parse(id));
        }
    }
}
