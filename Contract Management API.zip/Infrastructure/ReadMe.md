# Infrastructure Layer

This Project is an implicit, non-relational layer that can be consumed by the common layer.

It should never reference any other module as it does not take instanced based data and only provides interfacing with external services.

Note that this layer can provide models to other modules as an easy way to accept parameterized inputs.

---
An **example** of this is providing all endpoints that we will consume for Twilio. 

The layer will accept API keys, send the SMS via their endpoint and not much more.

Exceptions should not be handled at this layer (mainly because it has no way to log or communicate errors) and should be left up to the consumer, which, in such a case be the Common layer.

---

Ideally, this will run as a service bus Queueable interface, but we will see.



### Why not just put this in the Common Layer?
[Separation of Concerns](https://en.wikipedia.org/wiki/Separation_of_concerns)
