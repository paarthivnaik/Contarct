# **Contract Management**



This is the Backend for our core application.



In accordance with [Microservice Architecture](https://microservices.io/patterns/microservices.html), we have structured the application in such as way that each individual feature of the application is broken down into individual Web Applications that work at the HTTP Web level to provide endpoints for our Frontend or whatever else needs to consume. 

The benefit of this is that we get a separation of concerns where a critical failure in one deployment or feature would allow other modules to continue working normally and would help in isolating issues. Another benefit is that from the development end, we can compartmentalize features so that they are easier to find. Plus, it can lessen the chance of multiple Devs working on the same files at the same time, preventing commit conflicts.

Below are the current Modules that exist:

| Module                        | Description                                                  |
| ----------------------------- | ------------------------------------------------------------ |
| Authorization                 | User account management, role and function management. Also handles login and authorization actions that happen on the front end. |
| CAR (Contract Action Request) | For the management of dynamic forms, contract processes, approvals etc. (May be split out as we start working on features.) |
| Data Management               | Used for general data management that are far to generalized to be added to any single module. |

Each module is split into a Core and Web project. The Web project should only be a proxy for the Core application. All the heavy lifting should be done in the Core project while the Web project is intended for Request/Response Models and actual requests themselves. 

The following other Projects are as Follows:

| Project        | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| Common         | This is where we throw logic that is general across all modules. Since we only use one database, the database is also included in this project. |
| Infrastructure | An implicit, non-relational layer that can be consumed by the common layer for things such as consuming other APIs. |

