using System;
using System.Collections.Generic;
using Common.Data.Entities;
using Common.Data.Entities.Authorization;
using Common.Models;
using Common.StaticData.Enums;

namespace Authorization.Core.Entities
{
    public class LoginResult
    {
        public LoginResultEnum Result { get; set; }
        public string AccessToken { get; set; }
        public Guid? RefreshToken { get; set; }
        public List<SelectionOption> SelectionOptions { get; set; }
        public OrganizationResult Organization { get; set; }
        public RoleResult Role { get; set; }
        public NavigationInformation NavigationInformation { get; set; }
    }

    public class RoleResult
    {
        public RoleResult(Role r)
        {
            Id = r.Id;
            Name = r.Name;
            Hierarchy = r.Hierarchy;

            foreach (var f in r.Functions)
            {
                Functions.Add(new FunctionResult
                {
                    Name = f.Name
                });
            }
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<FunctionResult> Functions { get; set; } = new List<FunctionResult>();
        public int Hierarchy { get; set; }
    }

    public class FunctionResult
    {
        public string Name { get; set; }
    }

    public class OrganizationResult
    {
        public OrganizationResult(Organization organization)
        {
            Id = organization.Id;
            Name = organization.Name;
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
    }

    public class RefreshResult
    {
        public Guid RefreshTokenId { get; set; }
        public string Token { get; set; }
    }

    public class SelectionOption : ISelectItem
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }
        public List<SelectItem> Roles { get; set; } = new List<SelectItem>();
    }
}
