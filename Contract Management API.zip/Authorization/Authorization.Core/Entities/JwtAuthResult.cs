using Common.Data.Entities.Authorization;

namespace Authorization.Core.Entities
{
    public class JwtAuthResult
    {
        public string AccessToken { get; set; }
        public JwtRefreshToken RefreshToken { get; set; }
    }
}
