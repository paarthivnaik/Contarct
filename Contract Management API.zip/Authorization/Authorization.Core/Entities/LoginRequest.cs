using System;
using System.ComponentModel.DataAnnotations;

namespace Authorization.Core.Entities
{
    public class LoginRequest
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        public Guid? OrganizationId { get; set; }
        public Guid? RoleId { get; set; }
        //public int Application { get; set; }
    }

    public class RefreshTokenRequest
    {
        public string RefreshTokenId { get; set; }
        public string Token { get; set; }
    }
}
