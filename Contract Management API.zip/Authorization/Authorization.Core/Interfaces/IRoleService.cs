using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.Authorization;
using Common.Models;

namespace Authorization.Core.Interfaces
{
    public interface IRoleService
    {
        Task<Role> GetRoleById(Guid id);
        IQueryable<Role> GetAvailableRoles();
        IQueryable<Role> GetAvailableRolesForUser(ApplicationUser user);
        Task<Role> AddRole(Role role, ApplicationUser user);
        Task<Role> UpdateRole(Role role, ApplicationUser user);
        Task<Role> DeleteRole(Guid roleId, ApplicationUser user);
        Task<Role> AddRoleFunction(Guid roleId, Guid functionId, ApplicationUser aUser);
        Task<Role> RemoveRoleFunction(Guid roleId, Guid functionId, ApplicationUser aUser);
        Task<Role> SetRoleFunctions(Guid roleId, List<Function> functions, ApplicationUser aUser);
        Task<Role> SetRoleFunctionsByIds(Guid roleId, List<Guid> functionIds, ApplicationUser aUser);
    }
}
