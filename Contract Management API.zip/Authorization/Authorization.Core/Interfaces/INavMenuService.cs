using Common.Models;

namespace Authorization.Core.Interfaces
{
    public interface INavMenuService
    {
        NavigationInformation GenerateNavigation();
    } 
}
