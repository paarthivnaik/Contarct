using System;
using System.Security.Claims;
using System.Threading.Tasks;
using JwtAuthResult = Authorization.Core.Entities.JwtAuthResult;

namespace Authorization.Core.Interfaces
{
    public interface IJwtAuthService
    {
        Task<JwtAuthResult> GenerateToken(Guid userId, Claim[] claims, DateTime now);
        Task<JwtAuthResult> Refresh(Guid oldTokenId, string accessToken, DateTime now);
    }
}
