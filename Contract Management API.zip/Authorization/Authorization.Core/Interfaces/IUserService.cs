using System;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.Authorization;
using Common.Models;
using Microsoft.AspNetCore.Http;
using LoginRequest = Authorization.Core.Entities.LoginRequest;
using LoginResult = Authorization.Core.Entities.LoginResult;
using Enums = Common.StaticData.Enums;

namespace Authorization.Core.Interfaces
{
    public interface IUserService
    {
        /// <summary>
        /// Get a user based on their email.
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        Task<User> GetUserFromEmail(string email);
        /// <summary>
        /// Get a specific user based on their id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<User> GetUser(Guid id);
        Task<User> GetCurrentUser();

        /// <summary>
        /// Returns users that are available to the user's currently assigned organization
        /// </summary>
        /// <returns></returns>
        IQueryable<User> GetUsers();

        /// <summary>
        /// Returns all users that are available
        /// </summary>
        /// <returns></returns>
        IQueryable<User> GetAllUsers();

        /// <summary>
        /// Used to create a new user
        /// </summary>
        /// <param name="user"></param>
        /// <param name="allowDifferentOrgs"></param>
        /// <returns></returns>
        Task<User> CreateUser(User user, bool allowDifferentOrgs);
        
        /// <summary>
        /// Used to update the current user. Minor profile things can be edited, nothing major
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        Task<User> UpdateUser(User user);

        /// <summary>
        /// Used to edit other users, as an admin 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="allowOrgChanges"></param>
        /// <returns></returns>
        Task<User> UpdateOtherUser(User user, bool allowOrgChanges);
        Task<User> UpdatePassword(string newPassword, bool checkOld, string oldPassword);


        /// <summary>
        /// Tries to find a valid password reset token
        /// </summary>
        /// <param name="email"></param>
        /// <param name="resetHash"></param>
        /// <returns></returns>
        Task<PasswordTicket> GetValidPasswordChangeToken(string email, string resetHash);
        Task<bool> ChangePasswordUsingToken(string email, string resetToken, string newPassword, HttpRequest request);

        /// <summary>
        /// Used to reset a user's account password either from the forgot password screen or by an admin.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="reason"></param>
        /// <param name="lockAccountUntilPasswordChange"></param>
        /// <returns></returns>
        Task<bool> RequestUserSetPasswordAdmin(Guid userId, Enums.PasswordResetReasonEnum reason, bool lockAccountUntilPasswordChange);
        Task<bool> RequestUserSetPassword(Guid userId, Enums.PasswordResetReasonEnum reason, HttpRequest request);
        Task<User> DeleteUser(Guid id);
        Task LogLoginAttempt(LoginRequest loginRequest, LoginResult result, HttpRequest request);
        Task<Enums.LoginResultEnum> CanUserLogin(string email, string password, bool isLoginAttempt);
    }
}
