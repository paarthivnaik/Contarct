using System;
using System.Threading.Tasks;
using Common.Data.Entities.Authorization;

namespace Authorization.Core.Interfaces
{
    public interface ISessionService
    {
        Task<JwtRefreshToken> AddOrUpdateSession(JwtRefreshToken refreshToken);
        Task<bool> RemoveRefreshTokenByUserId(Guid id);
        Task<bool> RemoveRefreshTokenByTokenId(Guid id);
        Task<JwtRefreshToken> GetToken(Guid refreshTokenId);
        Task DeleteAllOldTokens();
    }
}
