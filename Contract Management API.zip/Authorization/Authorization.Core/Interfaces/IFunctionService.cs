using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Data.Entities.Authorization;
using Common.Models;

namespace Authorization.Core.Interfaces
{
    public interface IFunctionService
    {
        IQueryable<Function> GetFunctions();
        Task<Function> GetFunctionById(Guid id);
        Task<Function> CreateFunction(Function function);
        Task<List<Function>> CreateFunctions(List<Function> functions);
        Task<Function> DeleteFunction(Guid functionId);
        IQueryable<Function> GetUserFunctions(ApplicationUser user);

    }
}
