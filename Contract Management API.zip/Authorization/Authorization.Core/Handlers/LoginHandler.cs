using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Core.Entities;
using Authorization.Core.Interfaces;
using Authorization.Core.Services;
using Common.Data.Entities.Authorization;
using Common.Models;
using LoginRequest = Authorization.Core.Entities.LoginRequest;
using LoginResult = Authorization.Core.Entities.LoginResult;
using SelectionOption = Authorization.Core.Entities.SelectionOption;
using Enums = Common.StaticData.Enums;

namespace Authorization.Core.Handlers
{
    public class LoginHandler
    {
        private readonly IUserService _user;
        private readonly IJwtAuthService _auth;

        public LoginHandler(IJwtAuthService auth, IUserService user)
        {
            _user = user;
            _auth = auth;
        }

        public async Task<LoginResult> DoLogin(LoginRequest login)
        {
            var result = new LoginResult
            {
                //Check if the password is correct
                Result = await _user.CanUserLogin(login.Email, login.Password, true)
            };

            //Anything other than success or an expired password is not acceptable at this point.
            if (result.Result != Enums.LoginResultEnum.Success && result.Result != Enums.LoginResultEnum.Expired)
            {
                return result;
            }

            //Check to see if the user has multiple roles or organization assignments.
            User user = await _user.GetUserFromEmail(login.Email);

            if (!login.RoleId.HasValue || !login.OrganizationId.HasValue)
            {
                //User does not have any roles or organizations set up for them. They therefore cannot log in.
                if (user.Roles.Count == 0 || user.Organizations.Count == 0)
                {
                    result.Result = Enums.LoginResultEnum.MissingRolesOrOrgs;
                    return result;
                }

                //User has many roles or orgs, they need to pick
                if (user.Roles.Count > 1 || user.Organizations.Count > 1)
                {
                    //Give them options that are assigned to them
                    List<SelectionOption> options = new List<SelectionOption>();

                    foreach (var orgs in user.Organizations)
                    {
                        options.Add(new SelectionOption
                        {
                            Roles = new List<SelectItem>(),
                            Name = orgs.Name,
                            Value = orgs.Id.ToString()
                        });
                    }

                    var userRolesOrdered = user.Roles.OrderBy(x => x.Hierarchy).ToList();

                    foreach (var role in userRolesOrdered.Where(x => x.Organization != null))
                    {
                        var orgSelection = options.FirstOrDefault(x => x.Value == role.Organization?.Id.ToString());

                        orgSelection?.Roles.Add(
                            new SelectItem
                            {
                                Name = role.Name,
                                Value = role.Id.ToString()
                            });
                    }

                    //For every non org role, add it to every organization, because an organization-less roles should be accessable across all.
                    foreach (var role in userRolesOrdered.Where(x => x.Organization == null))
                    {
                        foreach (var selectionOption in options)
                        {
                            selectionOption.Roles.Add(new SelectItem
                            {
                                Name = role.Name,
                                Value = role.Id.ToString()
                            });
                        }
                    }

                    foreach (var option in options)
                    {
                        option.Roles = option.Roles.OrderBy(x => x.Name).ToList();
                    }

                    options = options.OrderBy(x => x.Name).ToList();

                    //Select the first by default.
                    if (options.Count > 0)
                    {
                        options[0].Selected = true;
                    }

                    //select the first by default.
                    foreach (var option in options)
                    {
                        if (option.Roles.Count > 0)
                        {
                            option.Roles[0].Selected = true;
                        }
                    }


                    result.SelectionOptions = options;

                    result.Result = Enums.LoginResultEnum.RequiresSelection;
                    return result;
                }

                //User has only one role and organization, we can autopick for them
                if (user.Roles.Count ==  1 && user.Organizations.Count == 1)
                {
                    login.RoleId = user.Roles.FirstOrDefault(x => x.Active)?.Id;
                    login.OrganizationId = user.Organizations.FirstOrDefault(x => x.Active)?.Id;
                }
            }

            //These act as validation lookups. The user object is qualified by database values.
            //We cannot trust the 'login' object as it is provided by the frontend.
            if (login.OrganizationId.HasValue)
            {
                result.Organization = new OrganizationResult(user.Organizations.FirstOrDefault(x => x.Active && x.Id == login.OrganizationId));
            }

            if (login.RoleId.HasValue)
            {
                result.Role = new RoleResult(user.Roles.FirstOrDefault(x => x.Active && x.Id == login.RoleId));
            }

            //This will happen when an invalid selection is made 
            if (result.Role == null || result.Organization == null)
            {
                result.Result = Enums.LoginResultEnum.MissingRolesOrOrgs;
                return result;
            }

            //Everthing looks good! Log the user in! :) We do this by finally providing a valid JWT token.
            var claims = UserService.GetUserClaims(user, result.Role, result.Organization);
            var jwtResult = await _auth.GenerateToken(user.Id, claims.ToArray(), DateTime.UtcNow);
            result.AccessToken = jwtResult.AccessToken;
            result.RefreshToken = jwtResult.RefreshToken.Id;
            result.NavigationInformation = new NavmenuService(result.Role.Functions.Select(x => x.Name).ToList()).GenerateNavigation();
            return result;
        }
    }
}
