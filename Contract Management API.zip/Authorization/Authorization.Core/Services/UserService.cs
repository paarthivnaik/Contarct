using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Authorization.Core.Entities;
using Authorization.Core.Interfaces;
using Common;
using Common.Data;
using Common.Data.Entities.Authorization;
using Common.Models;
using Common.StaticData;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Enums = Common.StaticData.Enums;
using LoginRequest = Authorization.Core.Entities.LoginRequest;
using LoginResult = Authorization.Core.Entities.LoginResult;

namespace Authorization.Core.Services
{
    public class UserService : IUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly AppSettings _configuration;
        private readonly DataContext _data;
        private readonly IRoleService _rs;
        private readonly ISessionService _ss;
        private ApplicationUser _user;

        public UserService(DataContext data, IOptions<AppSettings> configuration, IRoleService rs, ISessionService ss, IHttpContextAccessor httpContextAccessor)
        {
            _ss = ss;
            _httpContextAccessor = httpContextAccessor;
            _rs = rs;
            _configuration = configuration.Value;
            _data = data;
        }
        public Task<User> GetUser(Guid id)
        {
            return _data.Users
                .Include(x => x.Organizations.Where(o => o.Active))
                .Include(x => x.Roles.Where(r => r.Active)).ThenInclude(x => x.Functions).AsSplitQuery()
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public Task<User> GetCurrentUser()
        {
            if (_user == null)
            {
                _user = _httpContextAccessor.HttpContext.GetUser().Result;
            }

            return _data.Users
                .Include(x => x.Organizations.Where(o => o.Active))
                .Include(x => x.Roles.Where(r => r.Active)).ThenInclude(x => x.Functions).AsSplitQuery()
                .FirstOrDefaultAsync(x => x.Id == _user.Id);
        }

        public Task<User> GetUserFromEmail(string email)
        {
            return _data.Users
                .Include(x => x.Organizations.Where(o => o.Active))
                .Include(x => x.Roles.Where(r => r.Active)).ThenInclude(x => x.Functions).AsSplitQuery()
                .FirstOrDefaultAsync(x => x.Email == email.ToLowerInvariant());
        }

        #region Admin Functionality
        public IQueryable<User> GetUsers()
        {

            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            return _data.Users
                .Include(x => x.Organizations.Where(o => o.Active))
                .Include(x => x.Roles.Where(r => r.Active)).ThenInclude(x => x.Functions)
                .Where(x => x.Organizations.Any(y => y.Id == _user.OrganizationId));
        }

        public IQueryable<User> GetAllUsers()
        {

            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            return _data.Users
                .Include(x => x.Organizations.Where(o => o.Active))
                .Include(x => x.Roles.Where(r => r.Active)).ThenInclude(x => x.Functions)
                .Where(x => x.Organizations.Any(y => y.Id == _user.OrganizationId));
        }

        public async Task<User> CreateUser(User user, bool allowDifferentOrgs)
        {
            //We do not want any unnormalized emails added to database
            user.Email = user.Email.ToLowerInvariant();

            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            #region Validation
            if (!CanEditThisUser(user, _user))
                throw new ValidationException("Current user does not have permission to create a user with these permissions.");
            if (user.Organizations.Count == 0)
                throw new ValidationException("The selected organization for this user is not valid.");
            if (!allowDifferentOrgs && _user.OrganizationId != user.Organizations.First().Id)
                throw new ValidationException("The selected organization for this user is not valid.");
            if (user.Roles.Count == 0)
                throw new ValidationException("User does not have any Roles assigned to them.");
            if (await GetUserFromEmail(user.Email) != null)
                throw new ValidationException("User with this email already exists.");
            #endregion

            var rolesToSet = user.Roles.Select(x => x.Id).Distinct();
            user.Roles.Clear();
            foreach (var rId in rolesToSet)
            {
                Role role = await _rs.GetRoleById(rId);
                user.Roles.Add(role);
            }

            var orgsToSet = user.Organizations.Select(x => x.Id).Distinct();
            user.Organizations.Clear();
            foreach (var oId in orgsToSet)
            {
                var org = await _data.Organizations.FindAsync(oId);
                user.Organizations.Add(org);
            }

            var u = await _data.Users.AddAsync(user);

            //TODO generate request for user to add own pass via email

            return u.Entity;
        }

        public async Task<User> UpdateOtherUser(User user, bool canEditOrganizations)
        {
            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            if (!CanEditThisUser(user, _user))
                throw new ValidationException("Current user does not have permission to edit this user.");

            var dbUser = await GetUser(user.Id);
            dbUser.FirstName = user.FirstName;
            dbUser.LastName = user.LastName;
            dbUser.PhoneNumber = user.PhoneNumber;
            dbUser.Email = user.Email.ToLowerInvariant();
            dbUser.LockoutEnabled = user.LockoutEnabled;
            dbUser.AccessFailedCount = user.AccessFailedCount;
            dbUser.PasswordExpiry = user.PasswordExpiry;
            dbUser.Active = user.Active;
            var rolesToSet = user.Roles.Select(x => x.Id).Distinct();
            dbUser.Roles.Clear();

            if (user.Roles.Count == 0)
                throw new ValidationException("User does not have any Roles assigned to them.");

            foreach (var rId in rolesToSet)
            {
                Role role = await _rs.GetRoleById(rId);
                dbUser.Roles.Add(role);
            }

            if (canEditOrganizations)
            {
                if (user.Organizations.Count == 0)
                    throw new ValidationException("User does not have any organizations assigned to them.");
                var orgsToSet = user.Organizations.Select(x => x.Id).Distinct();
                dbUser.Organizations.Clear();
                foreach (var oId in orgsToSet)
                {
                    var org = await _data.Organizations.FindAsync(oId);
                    dbUser.Organizations.Add(org);
                }
            }

            await _data.SaveChangesAsync();

            return dbUser;
        }

        public async Task<bool> RequestUserSetPasswordAdmin(Guid userId, Enums.PasswordResetReasonEnum reason, bool lockAccountUntilPasswordChange)
        {
            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            var user = await GetUser(userId);
            if (!CanEditThisUser(user, _user))
            {
                throw new ValidationException("Current user does not have permission to reset a user's password with these permissions.");
            }

            PasswordTicket ticket = new PasswordTicket
            {
                Email = user.Email,
                Token = Password.GetToken(32),
                UnlockAccountOnUse = lockAccountUntilPasswordChange,
                RequestedAt = DateTime.UtcNow
            };

            switch (reason)
            {
                case Enums.PasswordResetReasonEnum.Welcome:
                    ticket.Expiry = DateTime.UtcNow.AddMonths(1);
                    break;
                case Enums.PasswordResetReasonEnum.AdminReset:
                    ticket.Expiry = DateTime.UtcNow.AddDays(1);
                    break;
            }

            if (lockAccountUntilPasswordChange)
            {
                await _ss.RemoveRefreshTokenByUserId(user.Id);
                user.LockoutEnabled = true;
            }
            
            await _data.PasswordTickets.AddAsync(ticket);
            //TODO Send email as needed at this point.

            await _data.SaveChangesAsync();

            return true;
        }
        public async Task<User> DeleteUser(Guid id)
        {
            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            var user = await GetUser(id);

            if (!CanEditThisUser(user, _user))
            {
                throw new ValidationException("Current user does not have permission to delete a user with these permissions.");
            }

            if (user != null)
            {
                user.Active = false;
                await _data.SaveChangesAsync();
                return user;
            }
            else
            {
                throw new ValidationException("User does not exist.");
            }
        }

        private bool CanEditThisUser(User userToEdit, ApplicationUser userEditing)
        {
            //A user is considered editable as long as they do not have any roles that are hierachally higher than thier own.
            //For example, a org admin should not be able to edit a system admin.
            var maxRoleOfUser = userToEdit.Roles.OrderBy(x => x.Hierarchy).First();

            return maxRoleOfUser.Hierarchy >= userEditing.RoleHierarchy;
        }
        #endregion


        #region Current User Functionality
        public async Task<User> UpdateUser(User user)
        {
            var dbUser = await GetUser(user.Id);

            dbUser.FirstName = user.FirstName;
            dbUser.LastName = user.LastName;
            dbUser.PhoneNumber = user.PhoneNumber;

            if (!string.Equals(user.Email, dbUser.Email, StringComparison.InvariantCultureIgnoreCase))
            {
                dbUser.Email = user.Email.ToLowerInvariant();
                dbUser.EmailConfirmed = false;
            }

            await _data.SaveChangesAsync();

            return dbUser;
        }

        public async Task<User> UpdatePassword(string newPassword, bool verifyOldPassword = true, string oldPassword = null)
        {
            _user ??= _httpContextAccessor.HttpContext.GetUser().Result;
            var user = await GetUser(_user.Id);

            if (verifyOldPassword)
            {
                if (Crypto.Equals(oldPassword, user.SecurityStamp, user.Password))
                {
                    throw new ValidationException("Old password provided was incorrect. Password change failed.");
                }
            }

            user.SecurityStamp = Guid.NewGuid();
            user.Password = Crypto.GenerateHash(newPassword, user.SecurityStamp.ToString());
            user.PasswordExpiry = DateTime.UtcNow.AddDays(_configuration.PasswordConfig.ExpiryInDays);

            await _data.SaveChangesAsync();

            return user;
        }
        #endregion


        public async Task<PasswordTicket> GetValidPasswordChangeToken(string email, string resetHash)
        {
            var token = await _data.PasswordTickets
                .FirstOrDefaultAsync(x =>
                    x.Email == email &&
                    x.Token == resetHash && 
                    x.Expiry > DateTime.UtcNow &&
                    !x.ConsumedAt.HasValue);
            return token;
        }

        public async Task<bool> ChangePasswordUsingToken(string email, string resetToken, string newPassword, HttpRequest request)
        {
            var token = await GetValidPasswordChangeToken(email, resetToken);
            if (token != null)
            {
                var user = await GetUserFromEmail(email);
                var (hash, salt) = Crypto.GenerateHash(newPassword);
                user.SecurityStamp = salt;
                user.Password = hash;
                user.PasswordExpiry = DateTime.UtcNow.AddDays(_configuration.PasswordConfig.ExpiryInDays);

                token.ConsumedAt = DateTime.UtcNow;
                token.ConsumerIp = request.HttpContext.Connection.RemoteIpAddress?.ToString();
                token.ConsumerUserString = request.Headers["User-Agent"];

                if (token.UnlockAccountOnUse && user.LockoutEnabled)
                {
                    user.LockoutEnabled = false;
                }

                if (token.ReasonId == Enums.PasswordResetReasonEnum.Welcome)
                {
                    user.EmailConfirmed = true;
                }

                await _data.SaveChangesAsync();
                return true;
            }
            else
            {
                return false;
            }
        }


        public async Task<bool> RequestUserSetPassword(Guid userId, Enums.PasswordResetReasonEnum reason, HttpRequest request)
        {
            var user = await GetUser(userId);

            PasswordTicket ticket = new PasswordTicket
            {
                Email = user.Email,
                Token = Password.GetToken(32),

                RequesterIp = request.HttpContext.Connection.RemoteIpAddress?.ToString(),
                RequesterUserString = request.Headers["User-Agent"],
                RequestedAt = DateTime.UtcNow
            };

            switch (reason)
            {
                case Enums.PasswordResetReasonEnum.ForgotPassword:
                    ticket.Expiry = DateTime.UtcNow.AddHours(1);
                    break;
            }

            await _data.PasswordTickets.AddAsync(ticket);

            //TODO Send email as needed at this point.

            return true;
        }

        public async Task LogLoginAttempt(LoginRequest loginRequest, LoginResult result, HttpRequest request)
        {
            await _data.LoginAttempts.AddAsync(new LoginAttempt
            {
                Email = loginRequest.Email,
                UserAgent = request.Headers["User-Agent"],
                IpAddress = request.HttpContext.Connection.RemoteIpAddress?.ToString(),
                LoginResultId = result.Result,
                AttemptDateTime = DateTime.UtcNow
            });

            await _data.SaveChangesAsync();
        }

        public async Task<Enums.LoginResultEnum> CanUserLogin(string email, string password, bool countAsLogin = false)
        {
            email = email.ToLowerInvariant();

            User matchingUser = await GetUserFromEmail(email);
            //Does user actually exist?
            if (matchingUser != null)
            {
                //Is the user deleted or not?
                if (!matchingUser.Active)
                {
                    return Enums.LoginResultEnum.Deleted;
                }

                //Is the user locked out?
                if (matchingUser.LockoutEnabled || matchingUser.AccessFailedCount > 10)
                {
                    return Enums.LoginResultEnum.Locked;
                }

                //Then lets try logging in
                if (Crypto.Equals(password, matchingUser.SecurityStamp, matchingUser.Password))
                {
                    //If the user has failed logins in the past, wipe the failed login counter since they just logged in.
                    matchingUser.LastLogin = DateTime.UtcNow;
                    matchingUser.AccessFailedCount = 0;
                    await _data.SaveChangesAsync();

                    //Password expired
                    if (matchingUser.PasswordExpiry < DateTimeOffset.Now)
                    {
                        return Enums.LoginResultEnum.Expired;
                    }
                    else
                    {
                        return Enums.LoginResultEnum.Success;
                    }
                }
                else
                {
                    //+1, the password they provided is not correct.
                    if (countAsLogin)
                    {
                        matchingUser.AccessFailedCount++;
                        await _data.SaveChangesAsync();
                    }
                }
            }

            return Enums.LoginResultEnum.Failed;
        }


        #region Static methods

        /// <summary>
        /// Used to convert user object into a jwt claim set for the frontend to understand as well as claim based permissions
        /// </summary>
        /// <param name="user">The current active user</param>
        /// <param name="activeRole">The user's selected role. Built this way since it is possible for users to have multiple roles.</param>
        /// <param name="activeOrganization">The user's selected org. Users can also have multiple orgs.</param>
        /// <returns></returns>
        public static List<Claim> GetUserClaims(User user, RoleResult activeRole, OrganizationResult activeOrganization)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Sid, user.Id.ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),

                new Claim(ClaimTypes.Role, activeRole.Name),
                new Claim(CustomClaims.RoleId, activeRole.Id.ToString()),
                new Claim(CustomClaims.RoleHierarchy, activeRole.Hierarchy.ToString()),

                new Claim(CustomClaims.OrganizationName, activeOrganization.Name),
                new Claim(CustomClaims.OrganizationId, activeOrganization.Id.ToString()),
            };
            claims.AddRange(activeRole.Functions.Select(function => new Claim(CustomClaims.Functions, function.Name)));

            return claims;
        }


        #endregion
    }


}
