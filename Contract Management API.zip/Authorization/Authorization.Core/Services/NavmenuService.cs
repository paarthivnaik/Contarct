using System.Collections.Generic;
using System.Linq;
using Authorization.Core.Interfaces;
using Common.Models;
using Common.StaticData;

namespace Authorization.Core.Services
{
    public class NavmenuService : INavMenuService
    {
        private readonly List<string> _functions;

        public NavmenuService(List<string> functions)
        {
            _functions = functions;
        }

        public NavigationInformation GenerateNavigation()
        {
            NavigationInformation information = new NavigationInformation();

            foreach (var kvp in NavMenuData.Instance.BaseMenu)
            {
                var availableItems = GetValidMenuItemsForUser(kvp.Value);

                if (availableItems != null && (!string.IsNullOrEmpty(availableItems.Link) || availableItems.Submenus.Count > 0))
                {
                    information.BaseMenu.Add(kvp.Key, availableItems);
                }
            }

            var availableSections = information.BaseMenu.Select(x => x.Key).Distinct().ToList();

            foreach (var section in NavMenuData.Instance.Sections)
            {
                var sectionItems = section.Items.Intersect(availableSections).ToList();

                if (sectionItems.Any())
                {
                    information.Sections.Add(new Section 
                    {
                        Text = section.Text,
                        Items = sectionItems
                    });
                }
            }

            return information;
        }

        private Submenu GetValidMenuItemsForUser(Submenu navigationItem)
        {
            Submenu resultingNav = null;

            bool canAdd;

            if (navigationItem.FunctionsRequired.Count > 0)
            {
                canAdd = _functions.Intersect(navigationItem.FunctionsRequired).Count() == navigationItem.FunctionsRequired.Count;
            }
            else
            {
                canAdd = true;
            }

            if (canAdd)
            {
                resultingNav = new Submenu();

                if (navigationItem.Submenus != null)
                {
                    resultingNav.Submenus = GetValidMenuItemsForUser(navigationItem.Submenus);
                }

                //To Prevent adding menu items that possibly are empty because the user does not have persmission to see the child menu items
                //if ((navigationItem.Submenus != null && navigationItem.Submenus.Count > 0) || !string.IsNullOrEmpty(navigationItem.Link))
                {
                    resultingNav.Text = navigationItem.Text;
                    resultingNav.Icon = navigationItem.Icon;
                    resultingNav.Link = navigationItem.Link;

                    resultingNav.Order = navigationItem.Order;
                    resultingNav.FunctionsRequired = navigationItem.FunctionsRequired;
                }

            }

            return resultingNav;
        }

        private List<Submenu> GetValidMenuItemsForUser(List<Submenu> kvpValue)
        {
            List<Submenu> result = new List<Submenu>();

            foreach (var navigationItem in kvpValue)
            {
                bool canAdd;

                if (navigationItem.FunctionsRequired.Count > 0)
                {
                    canAdd = _functions.Intersect(navigationItem.FunctionsRequired).Count() == navigationItem.FunctionsRequired.Count;
                }
                else
                {
                    canAdd = true;
                }

                if (canAdd)
                {
                    if (navigationItem.Submenus != null)
                    {
                        navigationItem.Submenus = GetValidMenuItemsForUser(navigationItem.Submenus);
                    }

                    //To Prevent adding menu items that possibly are empty because the user does not have persmission to see the child menu items
                    //if ((navigationItem.Submenus != null && navigationItem.Submenus.Count > 0) || !string.IsNullOrEmpty(navigationItem.Link))
                    {
                        result.Add(navigationItem);
                    }
                }
            }

            return result.OrderBy(x => x.Order).ToList();
        }
    }
}
