using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common.Data;
using Common.Data.Entities.Authorization;
using Common.Models;

namespace Authorization.Core.Services
{
    public class FunctionService : IFunctionService
    {
        private readonly DataContext _data;

        public FunctionService(DataContext data)
        {
            _data = data;
        }

        public IQueryable<Function> GetFunctions()
        {
            return _data.Functions;
        }

        public async Task<Function> GetFunctionById(Guid id)
        {
            return await _data.Functions.FindAsync(id);
        }

        public async Task<Function> CreateFunction(Function function)
        {
            if (function.Id != Guid.Empty) 
                throw new ValidationException("Function has ID. Not acceptable when creating a new function.");
            
            await _data.AddAsync(function);
            await _data.SaveChangesAsync();

            return function;
        }

        public async Task<List<Function>> CreateFunctions(List<Function> functions)
        {
            if (functions.Any(x => x.Id == Guid.Empty))
                throw new ValidationException("Function has ID. Not acceptable when creating a new function.");

            await _data.AddRangeAsync(functions);
            await _data.SaveChangesAsync();

            return functions;
        }

        public async Task<Function> DeleteFunction(Guid functionId)
        {
            var function = await GetFunctionById(functionId);
            _data.Functions.Remove(function);
            await _data.SaveChangesAsync();
            return function;
        }

        public IQueryable<Function> GetUserFunctions(ApplicationUser user)
        {
            return _data.Functions.Where(x => user.Functions.Contains(x.Name));
        }
    }
}
