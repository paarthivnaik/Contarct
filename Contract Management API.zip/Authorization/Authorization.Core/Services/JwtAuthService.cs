using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common;
using Common.Data.Entities.Authorization;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using JwtAuthResult = Authorization.Core.Entities.JwtAuthResult;

namespace Authorization.Core.Services
{
    public class JwtAuthService : IJwtAuthService
    {
        private readonly JwtTokenConfig _jwtTokenConfig;
        private readonly byte[] _secret;
        private readonly ISessionService _ss;
        private readonly IUserService _us;

        public JwtAuthService(IOptions<AppSettings> config, ISessionService ss, IUserService us)
        {
            _us = us;
            _ss = ss;
            _jwtTokenConfig = config.Value.JwtTokenConfig;
            _secret = Encoding.ASCII.GetBytes(config.Value.JwtTokenConfig.Secret);
        }

        public async Task<JwtAuthResult> GenerateToken(Guid userId, Claim[] claims, DateTime now)
        {
            var shouldAddAudienceClaim = string.IsNullOrWhiteSpace(claims?.FirstOrDefault(x => x.Type == JwtRegisteredClaimNames.Aud)?.Value);
            var jwtToken = new JwtSecurityToken(
                issuer: _jwtTokenConfig.Issuer, 
                audience: shouldAddAudienceClaim ? _jwtTokenConfig.Audience : string.Empty,
                claims,
                expires: now.AddMinutes(_jwtTokenConfig.AccessTokenExpiration),
                signingCredentials: new SigningCredentials(new SymmetricSecurityKey(_secret), SecurityAlgorithms.HmacSha256Signature));
            var accessToken = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            var refreshToken = new JwtRefreshToken
            {
                Id = Guid.NewGuid(),
                User = await _us.GetUser(userId),
                Expires = now.AddMinutes(_jwtTokenConfig.RefreshTokenExpiration)
            };

            //Updates the db so we can lookup the token to refresh the user's session later
            await _ss.AddOrUpdateSession(refreshToken);

            return new JwtAuthResult
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken
            };
        }

        public async Task<JwtAuthResult> Refresh(Guid refreshTokenId, string accessToken, DateTime now)
        {
            var (principal, jwtToken) = DecodeJwtToken(accessToken, true);
            if (jwtToken == null || !jwtToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256Signature) || principal.Identity == null)
            {
                throw new SecurityTokenException("Invalid token");
            }

            var token = await _ss.GetToken(refreshTokenId);

            if (token == null)
            {
                throw new SecurityTokenException("Invalid token");
            }

            if (token.IsExpired)
            {
                throw new SecurityTokenException("Invalid token");
            }

            var user = await _us.GetUser(token.UserId);
            var email = (principal.Identity as ClaimsIdentity)?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Email)?.Value;

            if (user.LockoutEnabled || user.AccessFailedCount > 10)
            {
                throw new SecurityTokenException("Invalid token");
            }

            if (!string.Equals(email, user.Email))
            {
                throw new SecurityTokenException("Invalid token");
            }

            //Remove old token
            await _ss.RemoveRefreshTokenByTokenId(refreshTokenId);

            //Generate a new one!
            return await GenerateToken(user.Id, principal.Claims.ToArray(), DateTime.UtcNow);
        }

        private (ClaimsPrincipal, JwtSecurityToken) DecodeJwtToken(string token, bool isForRefresh)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new SecurityTokenException("Invalid token");
            }
            var principal = new JwtSecurityTokenHandler()
                .ValidateToken(token,
                    new TokenValidationParameters
                    {
                        ValidateIssuer = !string.IsNullOrEmpty(_jwtTokenConfig.Issuer),
                        ValidIssuer = _jwtTokenConfig.Issuer,
                        ValidAudience = _jwtTokenConfig.Audience,
                        ValidateAudience = !string.IsNullOrEmpty(_jwtTokenConfig.Audience),
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_jwtTokenConfig.Secret)),
                        ValidateLifetime = !isForRefresh,
                        ClockSkew = TimeSpan.FromMinutes(1)
                    },
                    out var validatedToken);
            return (principal, validatedToken as JwtSecurityToken);
        }

    }
}
