using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common.Data;
using Common.Data.Entities.Authorization;
using Common.Models;
using Microsoft.EntityFrameworkCore;

namespace Authorization.Core.Services
{
    public class RoleService : IRoleService
    {
        private readonly DataContext _data;
        private readonly IFunctionService _fs;

        public RoleService(DataContext data, IFunctionService fs)
        {
            _fs = fs;
            _data = data;
        }

        public Task<Role> GetRoleById(Guid id)
        {
            return _data.Roles.Include(x => x.Functions).FirstOrDefaultAsync(x => x.Id == id);
        }

        public IQueryable<Role> GetAvailableRoles()
        {
            return _data.Roles.Include(x => x.Functions).Where(x => x.Active);
        }

        public IQueryable<Role> GetAvailableRolesForUser(ApplicationUser user)
        {
            return _data.Roles.Include(x => x.Functions).Where(x => x.Active && x.Hierarchy > user.RoleHierarchy);
        }

        public async Task<Role> AddRole(Role role, ApplicationUser aUser)
        {
            if (!CanUserCanEditRole(role, aUser))
                throw new ValidationException("User cannot create a role of Hierarchy higher than their own.");
            if (role.Hierarchy <= 0)
                throw new ValidationException("Roles cannot be given a negative heiarchy value.");
            if (role.Id != Guid.Empty) 
                throw new ValidationException("Role has ID. Not acceptable when creating a new role.");
            if (_data.Roles.Any(x => x.Name.ToLowerInvariant() == role.Name.ToLowerInvariant())) 
                throw new ValidationException("Role with this name already exists.");
            await _data.Roles.AddAsync(role);
            await _data.SaveChangesAsync();
            return role;
        }

        public async Task<Role> UpdateRole(Role role, ApplicationUser aUser)
        {
            var dbRole = await GetRoleById(role.Id);
            if (!CanUserCanEditRole(dbRole, aUser))
                throw new ValidationException("User cannot edit this role.");

            dbRole.Active = role.Active;
            dbRole.Name = role.Name;
            await _data.SaveChangesAsync();

            return dbRole;
        }

        public async Task<Role> DeleteRole(Guid roleId, ApplicationUser aUser)
        {
            var dbRole = await GetRoleById(roleId); 
            if (!CanUserCanEditRole(dbRole, aUser))
                throw new ValidationException("User cannot edit this role.");

            dbRole.Active = false;
            await _data.SaveChangesAsync();
            return dbRole;
        }

        public async Task<Role> AddRoleFunction(Guid roleId, Guid functionId, ApplicationUser aUser)
        {
            var dbRole = await GetRoleById(roleId);
            if (!CanUserCanEditRole(dbRole, aUser))
                throw new ValidationException("User cannot edit this role.");
            if (roleId == Guid.Empty || functionId == Guid.Empty) 
                throw new ValidationException("ID is missing.");
            if (dbRole.Functions.Any(x => x.Id == functionId)) 
                throw new ValidationException("Role already has this function.");

            var dbFunction = await _fs.GetFunctionById(functionId);
            dbRole.Functions.Add(dbFunction);
            await _data.SaveChangesAsync();

            return dbRole;
        }

        public async Task<Role> RemoveRoleFunction(Guid roleId, Guid functionId, ApplicationUser aUser)
        {
            var dbRole = await GetRoleById(roleId);
            if (!CanUserCanEditRole(dbRole, aUser))
                throw new ValidationException("User cannot edit this role.");
            if (roleId == Guid.Empty || functionId == Guid.Empty) 
                throw new ValidationException("ID is missing.");
            if (dbRole.Functions.All(x => x.Id != functionId)) 
                throw new ValidationException("This function does not belong to this role.");

            var dbFunction = await _fs.GetFunctionById(functionId);
            dbRole.Functions.Remove(dbFunction);
            await _data.SaveChangesAsync();

            return dbRole;

        }

        public async Task<Role> SetRoleFunctions(Guid roleId, List<Function> functions, ApplicationUser aUser)
        {
            var functionIds = functions.Select(y => y.Id).ToList();
            return await SetRoleFunctionsByIds(roleId, functionIds, aUser);
        }

        public async Task<Role> SetRoleFunctionsByIds(Guid roleId, List<Guid> functionIds, ApplicationUser aUser)
        {
            var dbRole = await GetRoleById(roleId);

            if (!CanUserCanEditRole(dbRole, aUser))
                throw new ValidationException("User cannot edit this role.");
            var functionsFromDb = _data.Functions.Where(x => functionIds.Contains(x.Id));

            if (functionsFromDb.Count() != functionIds.Count) 
                throw new ValidationException("Some or all functions are not valid.");

            dbRole.Functions = await functionsFromDb.ToListAsync();
            await _data.SaveChangesAsync();

            return dbRole;
        }

        private bool CanUserCanEditRole(Role role, ApplicationUser user)
        {
            if (role.Organization != null)
            {
                //Users should only be allowed to edit roles they are currently more "powerful" than.
                //For example, a Org Admin (0) should not be able to edit a System admin (-1).
                return user.OrganizationId == role.Organization.Id && role.Hierarchy > user.RoleHierarchy;
            }
            else
            {
                //The only role who can edit non-organization roles is sys admins, which is the only role that has -1.
                return user.RoleHierarchy == -1;
            }
        }
    }
}
