using System;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common.Data;
using Common.Data.Entities.Authorization;
using Microsoft.EntityFrameworkCore;

namespace Authorization.Core.Services
{
    public class SessionService : ISessionService
    {
        private readonly DataContext _data;
        public SessionService(DataContext data)
        {
            _data = data;
        }

        public async Task<JwtRefreshToken> AddOrUpdateSession(JwtRefreshToken refreshToken)
        {
            var dbSession = await _data.Sessions.FindAsync(refreshToken.Id);

            if (dbSession == null)
            {
                await _data.Sessions.AddAsync(refreshToken);
                await _data.SaveChangesAsync();
            }
            else
            {
                dbSession = refreshToken;
            }

            return dbSession;
        }

        public async Task<bool> RemoveRefreshTokenByUserId(Guid userId)
        {
            var sessionsToRemove = _data.Sessions.Include(x => x.User).Where(x => x.User.Id == userId);
            _data.Sessions.RemoveRange(sessionsToRemove);
            await _data.SaveChangesAsync();
            //Note that this will log off users from ALL session across all their systems
            return true;
        }

        public async Task<bool> RemoveRefreshTokenByTokenId(Guid refreshTokenId)
        {
            var sessionsToRemove = _data.Sessions.Where(x => x.Id == refreshTokenId);

            if (sessionsToRemove.Count() != 0)
            {
                _data.Sessions.RemoveRange(sessionsToRemove);
                await _data.SaveChangesAsync();
            }

            //Note that this will log off users for only the matching refresh tokens, good for only logging out one system at a time.
            return true;
        }

        public async Task<JwtRefreshToken> GetToken(Guid refreshTokenId)
        {
            return await _data.Sessions.FindAsync(refreshTokenId);
        }

        public async Task DeleteAllOldTokens()
        {
            _data.Sessions.RemoveRange(_data.Sessions.Where(x => x.Expires <= DateTime.UtcNow.AddDays(-1)));

            await _data.SaveChangesAsync();
        }
    }
}
