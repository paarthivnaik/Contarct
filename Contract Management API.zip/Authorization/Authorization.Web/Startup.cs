using System;
using Authorization.Core.Interfaces;
using Authorization.Core.Services;
using Common.Data;
using Common.StaticData;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using static Common.Startup;

namespace Authorization.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            var apiInfo = new OpenApiInfo
            {
                Title = "Authorization",
                Description = "This endpoint handles user accounts, roles, functions and authentication actions."
            };
            var nameSpace = typeof(Startup).Namespace;
            services.AddDbContext<DataContext>(options => {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultDatabase"), x => x.MigrationsAssembly(nameSpace));
                options.EnableSensitiveDataLogging();
            });

            ConfigureCommonServices(services, Configuration, apiInfo);

            
            //DI Scopes go here
            services.AddScoped<IRoleService, RoleService>();
            services.AddScoped<ISessionService, SessionService>();
            services.AddScoped<IFunctionService, FunctionService>();
            services.AddScoped<IJwtAuthService, JwtAuthService>();
            services.AddScoped<IUserService, UserService>();

            if (NavMenuData.Instance.BaseMenu == null) throw new Exception("Missing Navmenu");
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigureApplicaiton(app, env, "Authorization");
        }
    }
}
