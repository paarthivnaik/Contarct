using Common.Data.Entities.Authorization;

namespace Authorization.Web.ApiModels
{
    public class JwtAuthResult
    {
        public string AccessToken { get; set; }
        public JwtRefreshToken RefreshToken { get; set; }
    }
}
