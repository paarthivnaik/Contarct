using System;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common;
using Common.Data.Entities.Authorization;
using Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Enums = Common.StaticData.Enums;

namespace Authorization.Web.Controllers
{
    /// <summary>
    /// Endpoint only to be used to manage other users. 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }
        
        /// <summary>
        /// Used by org admins to administrate users across their organization.
        /// </summary>
        /// <returns></returns>
        [HttpGet("get-users")]
        [Authorize(Policy = "Authentication.User.View")]
        public async Task<PagedResult<User>> GetUsers(int page, int pageSize)
        {
            return await _userService.GetUsers().ToPagedAsync(page, pageSize);
        }

        /// <summary>
        /// Used by System admins to get users across all organizations.
        /// </summary>
        /// <returns></returns>
        [HttpGet("get-users-globally")]
        [Authorize(Policy = "Authentication.User.ViewAny")]
        public async Task<PagedResult<User>> GetUsersGlobally(int page, int pageSize)
        {
            return await _userService.GetAllUsers().ToPagedAsync(page, pageSize);
        }

        /// <summary>
        /// Used to create an account for the current organization. Used by org admins
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("create")]
        [Authorize(Policy = "Authentication.User.Create")]
        public async Task<ActionResult> Create(User user)
        {
            return Ok(await _userService.CreateUser(user, false));
        }

        /// <summary>
        /// Used to create a user for an account outside of the current organization. Used by sys admins.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("create-globally")]
        [Authorize(Policy = "Authentication.User.CreateAny")]
        public async Task<ActionResult> CreateGlobally(User user)
        {
            return Ok(await _userService.CreateUser(user, true));
        }

        // POST api/User
        [HttpPut("update")]
        [Authorize(Policy = "Authentication.User.Edit")]
        public async Task<ActionResult> Update(User user)
        {
            ApplicationUser aUser = await HttpContext.GetUser();

            if (aUser.Id == user.Id)
            {
                return Forbid("You cannot edit the current user.");
            }
            else
            {
                return Ok(await _userService.UpdateOtherUser(user, false));
            }
        }

        [HttpPut("update-globally")]
        [Authorize(Policy = "Authentication.User.EditAny")]
        public async Task<ActionResult> UpdateGlobally(User user)
        {
            ApplicationUser aUser = await HttpContext.GetUser();

            if (aUser.Id == user.Id)
            {
                return Forbid("You cannot edit the current user.");
            }
            else
            {
                return Ok(await _userService.UpdateOtherUser(user, true));
            }
        }

        [HttpDelete("delete")]
        [Authorize(Policy = "Authentication.User.Delete")]
        public async Task<ActionResult> Delete(string id)
        {
            ApplicationUser aUser = await HttpContext.GetUser();

            var guid = Guid.Parse(id);
            if (aUser.Id == guid)
            {
                return Forbid("You cannot delete the current user.");
            }
            else
            {
                return Ok(await _userService.DeleteUser(guid));
            }
        }

        [HttpPut("reset-password-globally")]
        [Authorize(Policy = "Authentication.User.EditAny")]
        public async Task<ActionResult> ResetPasswordGlobally(string id, bool lockUntilChange)
        {
            var guid = Guid.Parse(id);
            ApplicationUser aUser = await HttpContext.GetUser();
            var user = await _userService.GetUser(guid);
            if (aUser.Id == user.Id)
            {
                return Forbid("You cannot edit the current user.");
            }
            else
            {
                return Ok(await _userService.RequestUserSetPasswordAdmin(guid, Enums.PasswordResetReasonEnum.AdminReset, lockUntilChange));
            }
        }


        [HttpPut("reset-password")]
        [Authorize(Policy = "Authentication.User.Edit")]
        public async Task<ActionResult> ResetPassword(string id, bool lockUntilChange)
        {
            var guid = Guid.Parse(id);
            ApplicationUser aUser = await HttpContext.GetUser();
            var user = await _userService.GetUser(guid);

            if (aUser.Id == user.Id)
            {
                return Forbid("You cannot edit the current user.");
            }
            else if (user.Organizations.Any(x => x.Id == aUser.OrganizationId))
            {
                return Ok(await _userService.RequestUserSetPasswordAdmin(guid, Enums.PasswordResetReasonEnum.AdminReset, lockUntilChange));
            }
            else
            {
                return Forbid("Cannot reset the password for this user");
            }
        }
    }
}
