using System;
using System.Threading.Tasks;
using Authorization.Core.Entities;
using Authorization.Core.Handlers;
using Authorization.Core.Interfaces;
using Common;
using Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using Enums = Common.StaticData.Enums;

namespace Authorization.Web.Controllers
{
    /// <summary>
    /// Endpoint for doing session and user login related things.
    /// </summary>
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IJwtAuthService _jwtAuthService;
        private readonly ISessionService _sessions;
        private readonly ILogger _logger;

        public AccountController(IUserService userService, IJwtAuthService jwtAuthService, ISessionService sessions)
        {
            var u = HttpContext.TryGetUser();
            _logger = Log.ForContext("UserId", u?.Id).ForContext("OrganizationId", u?.OrganizationId);
            _sessions = sessions;
            _userService = userService;
            _jwtAuthService = jwtAuthService;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }

                LoginResult response = await new LoginHandler(_jwtAuthService, _userService).DoLogin(request);

                await _userService.LogLoginAttempt(request, response, Request);

                if (response.Result == Enums.LoginResultEnum.Success || //All okay
                    response.Result == Enums.LoginResultEnum.RequiresSelection || //Return options for user to select and reauth
                    response.Result == Enums.LoginResultEnum.Expired) //All okay, but the user should be forced to change their password 
                {
                    return Ok(response);
                }
                else
                {
                    return Unauthorized(response);
                }
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [AllowAnonymous]
        [HttpPost("current-user")]
        public async Task<ApplicationUser> CurrentUser()
        {
            return await HttpContext.GetUser();
        }

        [AllowAnonymous]
        [HttpPost("clear-old-sessions")]
        public async Task ClearOldSessions()
        {
            try
            {
                await _sessions.DeleteAllOldTokens();
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        

        [AllowAnonymous]
        [HttpPost("refresh")]
        public async Task<ActionResult> Refresh([FromBody] RefreshTokenRequest request)
        {
            try
            {
                var refreshTokenIdResult = Guid.Parse(request.RefreshTokenId);

                var jwtResult = await _jwtAuthService.Refresh(refreshTokenIdResult, request.Token, DateTime.UtcNow);

                RefreshResult result = new RefreshResult
                {
                    RefreshTokenId = jwtResult.RefreshToken.Id,
                    Token = jwtResult.AccessToken
                };

                return Ok(result);
            }
            catch (SecurityTokenException)
            {
                return Unauthorized("Failed to refresh token."); // return 401 so that the client side can redirect the user to login page
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }


        [HttpPost("logout")]
        public async Task<ActionResult> Logout(string refreshTokenId = null)
        {
            try
            {
                if (User.Identity != null)
                {
                    if (string.IsNullOrEmpty(refreshTokenId))
                    {
                        var user = await HttpContext.GetUser();
                        await _sessions.RemoveRefreshTokenByUserId(user.Id);
                    }
                    else
                    {
                        await _sessions.RemoveRefreshTokenByTokenId(Guid.Parse(refreshTokenId));
                    }
                }

                return Ok();
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpPost("reset-password")]
        [AllowAnonymous]
        public async Task<bool> ResetPassword(string email)
        {
            try
            {
                var user = await _userService.GetUserFromEmail(email);
                return await _userService.RequestUserSetPassword(user.Id, Enums.PasswordResetReasonEnum.ForgotPassword, HttpContext.Request);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpPost("reset-password-token-check")]
        [AllowAnonymous]
        public async Task<bool> ResetTokenCheck(string token, string email)
        {
            try
            {
                return await _userService.GetValidPasswordChangeToken(email, token) != null;
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpPost("reset-password-with-token")]
        [AllowAnonymous]
        public async Task<bool> ResetPasswordWithToken(string newPassword, string token, string email)
        {
            try
            {
                return await _userService.ChangePasswordUsingToken(email, token, newPassword, HttpContext.Request);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }
    }
}
