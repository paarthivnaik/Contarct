using System;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common;
using Common.Data.Entities.Authorization;
using Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace Authorization.Web.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleService _roleService;
        private readonly ILogger _logger;

        public RoleController(IRoleService roleService)
        {
            var u = HttpContext.TryGetUser();
            _logger = Log.ForContext("UserId", u?.Id).ForContext("OrganizationId", u?.OrganizationId);
            _roleService = roleService;
        }
        
        // GET api/User/5
        [HttpGet("{id}")]
        [Authorize(Policy = "Authentication.Role.View")]
        public async Task<Role> Get(string id)
        {
            try
            {
                var guid = Guid.Parse(id);
                return await _roleService.GetRoleById(guid);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpGet]
        [Authorize(Policy = "Authentication.Role.View")]
        public async Task<PagedResult<Role>> Get(int page, int pageSize)
        {
            try
            {
                ApplicationUser aUser = await HttpContext.GetUser();
                return await _roleService.GetAvailableRolesForUser(aUser).ToPagedAsync(page, pageSize);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        // POST api/User
        [HttpPut("update")]
        [Authorize(Policy = "Authentication.Role.Edit")]
        public async Task<Role> Update(Role role)
        {
            try
            {
                ApplicationUser aUser = await HttpContext.GetUser();
                return await _roleService.UpdateRole(role, aUser);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        // POST api/User/Add
        [HttpPost("add")]
        [Authorize(Policy = "Authentication.Role.Create")]
        public async Task<Role> Add(Role role)
        {
            try
            {
                ApplicationUser aUser = await HttpContext.GetUser();
                return await _roleService.AddRole(role, aUser);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        // DELETE api/User/5
        [HttpDelete("{id}")]
        [Authorize(Policy = "Authentication.Role.Delete")]
        public async Task<Role> Delete(string id)
        {
            try
            {
                var guid =  Guid.Parse(id);
                ApplicationUser aUser = await HttpContext.GetUser();
                return await _roleService.DeleteRole(guid, aUser);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }
    }
}
