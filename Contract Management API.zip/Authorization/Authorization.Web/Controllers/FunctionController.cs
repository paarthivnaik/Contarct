using System;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common;
using Common.Data.Entities.Authorization;
using Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace Authorization.Web.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class FunctionController : ControllerBase
    {
        private readonly IFunctionService _functionService;
        private readonly ILogger _logger;

        public FunctionController(IFunctionService functionService)
        {
            var u = HttpContext.TryGetUser();
            _logger = Log.ForContext("UserId", u?.Id).ForContext("OrganizationId", u?.OrganizationId);
            _functionService = functionService;
        }

        [HttpGet]
        public async Task<PagedResult<Function>> Get(int page, int pageSize)
        {
            try
            {
                return await _functionService.GetFunctions().ToPagedAsync(page, pageSize);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<Function> Get(string id)
        {
            try
            {
                var guid = Guid.Parse(id);
                return await _functionService.GetFunctionById(guid);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }
    }
}
