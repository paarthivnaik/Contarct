using System;
using System.Threading.Tasks;
using Authorization.Core.Interfaces;
using Common;
using Common.Data.Entities.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace Authorization.Web.Controllers
{
    /// <summary>
    /// Endpoint only to be used to manage the current user.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogger _logger;

        public UserController(IUserService userService)
        {
            var u = HttpContext.TryGetUser();
            _logger = Log.ForContext("UserId", u?.Id).ForContext("OrganizationId", u?.OrganizationId);
            _userService = userService;
        }
        
        [HttpGet]
        public async Task<User> Get()
        {
            try
            {
                return await _userService.GetCurrentUser();
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        [HttpPut("update")]
        public async Task<ActionResult> Update(User user)
        {
            try
            {
                var userId = (await HttpContext.GetUser()).Id;

                if (userId == user.Id)
                {
                    return Ok(await _userService.UpdateUser(user));
                }
                else
                {
                    return Forbid("You can only edit the current user");
                }
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }

        /// <summary>
        /// Used to update the current user's password. Requires the user to provide the old password as well.
        /// </summary>
        /// <param name="newPassword"></param>
        /// <param name="oldPassword"></param>
        /// <returns></returns>
        [HttpPatch("update-password")]
        public async Task<ActionResult> UpdatePassword(string newPassword, string oldPassword)
        {
            try
            {
                var userResult = await _userService.UpdatePassword(newPassword, true, oldPassword);
                return Ok(userResult);
            }
            catch (Exception e)
            {
                _logger.Error(e, e.Message);
                throw;
            }
        }
    }
}
